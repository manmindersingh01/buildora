import React from 'react';
import { TodoStats as TodoStatsType } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Circle, AlertTriangle, BarChart3 } from 'lucide-react';

interface TodoStatsProps {
  stats: TodoStatsType;
}

const TodoStats: React.FC<TodoStatsProps> = ({ stats }) => {
  const statItems = [
    {
      icon: BarChart3,
      label: 'Total',
      value: stats.total,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      icon: Circle,
      label: 'Active',
      value: stats.active,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200'
    },
    {
      icon: CheckCircle,
      label: 'Completed',
      value: stats.completed,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    },
    {
      icon: AlertTriangle,
      label: 'Overdue',
      value: stats.overdue,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      {statItems.map((item) => {
        const Icon = item.icon;
        return (
          <Card key={item.label} className={`${item.borderColor} ${item.bgColor}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{item.label}</p>
                  <p className={`text-2xl font-bold ${item.color}`}>{item.value}</p>
                </div>
                <Icon className={`w-8 h-8 ${item.color}`} />
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default TodoStats;