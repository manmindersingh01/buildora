import { useState, useEffect } from 'react';
import { Todo, TodoFilter, TodoStats } from '@/types';
import axios from 'axios';

export const useTodos = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Mock API functions - replace with real API calls
  const fetchTodos = async () => {
    setLoading(true);
    setError(null);
    try {
      // Mock data for demonstration
      const mockTodos: Todo[] = [
        {
          id: '1',
          title: 'Complete project proposal',
          description: 'Finish the Q4 project proposal document',
          completed: false,
          priority: 'high',
          category: 'Work',
          dueDate: '2024-01-15',
          createdAt: '2024-01-01T10:00:00Z',
          updatedAt: '2024-01-01T10:00:00Z'
        },
        {
          id: '2',
          title: 'Buy groceries',
          description: 'Milk, bread, eggs, vegetables',
          completed: true,
          priority: 'medium',
          category: 'Personal',
          dueDate: '2024-01-10',
          createdAt: '2024-01-08T09:00:00Z',
          updatedAt: '2024-01-09T14:30:00Z'
        },
        {
          id: '3',
          title: 'Schedule dentist appointment',
          completed: false,
          priority: 'low',
          category: 'Health',
          createdAt: '2024-01-05T16:00:00Z',
          updatedAt: '2024-01-05T16:00:00Z'
        }
      ];
      setTodos(mockTodos);
    } catch (err) {
      setError('Failed to fetch todos');
      console.error('Error fetching todos:', err);
    } finally {
      setLoading(false);
    }
  };

  const addTodo = async (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newTodo: Todo = {
        ...todoData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      setTodos(prev => [newTodo, ...prev]);
      return newTodo;
    } catch (err) {
      setError('Failed to add todo');
      throw err;
    }
  };

  const updateTodo = async (id: string, updates: Partial<Todo>) => {
    try {
      setTodos(prev => prev.map(todo => 
        todo.id === id 
          ? { ...todo, ...updates, updatedAt: new Date().toISOString() }
          : todo
      ));
    } catch (err) {
      setError('Failed to update todo');
      throw err;
    }
  };

  const deleteTodo = async (id: string) => {
    try {
      setTodos(prev => prev.filter(todo => todo.id !== id));
    } catch (err) {
      setError('Failed to delete todo');
      throw err;
    }
  };

  const toggleComplete = async (id: string) => {
    const todo = todos.find(t => t.id === id);
    if (todo) {
      await updateTodo(id, { completed: !todo.completed });
    }
  };

  const filterTodos = (filter: TodoFilter): Todo[] => {
    return todos.filter(todo => {
      if (filter.status === 'active' && todo.completed) return false;
      if (filter.status === 'completed' && !todo.completed) return false;
      if (filter.priority && todo.priority !== filter.priority) return false;
      if (filter.category && todo.category !== filter.category) return false;
      if (filter.search && !todo.title.toLowerCase().includes(filter.search.toLowerCase())) return false;
      return true;
    });
  };

  const getTodoStats = (): TodoStats => {
    const total = todos.length;
    const completed = todos.filter(t => t.completed).length;
    const active = total - completed;
    const overdue = todos.filter(t => 
      !t.completed && t.dueDate && new Date(t.dueDate) < new Date()
    ).length;

    return { total, completed, active, overdue };
  };

  useEffect(() => {
    fetchTodos();
  }, []);

  return {
    todos,
    loading,
    error,
    addTodo,
    updateTodo,
    deleteTodo,
    toggleComplete,
    filterTodos,
    getTodoStats,
    refetch: fetchTodos
  };
};