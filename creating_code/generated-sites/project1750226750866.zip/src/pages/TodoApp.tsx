import React, { useState } from 'react';
import { TodoFilter } from '@/types';
import { useTodos } from '@/hooks/useTodos';
import AddTodoForm from '@/components/AddTodoForm';
import TodoItem from '@/components/TodoItem';
import TodoFilters from '@/components/TodoFilters';
import TodoStats from '@/components/TodoStats';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckSquare, AlertCircle } from 'lucide-react';

const TodoApp: React.FC = () => {
  const { 
    todos, 
    loading, 
    error, 
    addTodo, 
    updateTodo, 
    deleteTodo, 
    toggleComplete, 
    filterTodos, 
    getTodoStats 
  } = useTodos();

  const [filter, setFilter] = useState<TodoFilter>({
    status: 'all'
  });

  const filteredTodos = filterTodos(filter);
  const stats = getTodoStats();
  const categories = Array.from(new Set(todos.map(todo => todo.category))).filter(Boolean);

  const handleAddTodo = async (todoData: Parameters<typeof addTodo>[0]) => {
    try {
      await addTodo(todoData);
    } catch (error) {
      console.error('Failed to add todo:', error);
    }
  };

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
        <div className="max-w-4xl mx-auto pt-8">
          <Alert className="border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              {error}
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="max-w-4xl mx-auto p-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg">
              <CheckSquare className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Todo Master
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Organize your tasks and boost your productivity
          </p>
        </div>

        {/* Stats */}
        <TodoStats stats={stats} />

        {/* Add Todo Form */}
        <AddTodoForm onAdd={handleAddTodo} />

        {/* Filters */}
        <TodoFilters 
          filter={filter} 
          onFilterChange={setFilter} 
          categories={categories}
        />

        {/* Todo List */}
        <div className="space-y-3">
          {loading ? (
            // Loading skeleton
            <div className="space-y-3">
              {[...Array(3)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg p-4 shadow-sm border">
                  <div className="flex items-start gap-3">
                    <Skeleton className="w-5 h-5 mt-1" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-5 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                      <div className="flex gap-2">
                        <Skeleton className="h-6 w-16" />
                        <Skeleton className="h-6 w-20" />
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Skeleton className="w-8 h-8" />
                      <Skeleton className="w-8 h-8" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredTodos.length > 0 ? (
            filteredTodos.map((todo) => (
              <TodoItem
                key={todo.id}
                todo={todo}
                onToggle={toggleComplete}
                onUpdate={updateTodo}
                onDelete={deleteTodo}
              />
            ))
          ) : (
            <div className="text-center py-12">
              <div className="mb-4">
                <CheckSquare className="w-16 h-16 text-gray-300 mx-auto" />
              </div>
              <h3 className="text-xl font-medium text-gray-600 mb-2">
                {filter.status === 'all' ? 'No todos yet' : 
                 filter.status === 'completed' ? 'No completed todos' : 
                 'No active todos'}
              </h3>
              <p className="text-gray-500">
                {filter.status === 'all' ? 'Create your first todo to get started!' : 
                 filter.status === 'completed' ? 'Complete some todos to see them here.' :
                 'All your todos are completed!'}
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-16 text-center text-gray-500 text-sm">
          <p>Stay organized, stay productive! 🚀</p>
        </div>
      </div>
    </div>
  );
};

export default TodoApp;