export interface Pizza {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: 'classic' | 'specialty' | 'vegetarian' | 'vegan';
  ingredients: string[];
  size: 'small' | 'medium' | 'large';
  popular?: boolean;
}

export interface CartItem {
  pizza: Pizza;
  quantity: number;
  selectedSize: 'small' | 'medium' | 'large';
  totalPrice: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  customerInfo: {
    name: string;
    phone: string;
    email: string;
    address: string;
  };
  totalAmount: number;
  status: 'pending' | 'preparing' | 'ready' | 'delivered';
  orderTime: Date;
}

export interface Testimonial {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
}