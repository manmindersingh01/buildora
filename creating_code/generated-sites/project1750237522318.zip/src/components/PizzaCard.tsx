import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Plus } from 'lucide-react';
import { Pizza } from '@/types';

interface PizzaCardProps {
  pizza: Pizza;
}

export const PizzaCard: React.FC<PizzaCardProps> = ({ pizza }) => {
  const getSizePrice = (basePrice: number, size: string) => {
    switch (size) {
      case 'small':
        return basePrice;
      case 'medium':
        return basePrice + 3;
      case 'large':
        return basePrice + 6;
      default:
        return basePrice;
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 border-orange-100 group">
      <div className="relative overflow-hidden">
        <img
          src={pizza.image}
          alt={pizza.name}
          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          {pizza.popular && (
            <Badge className="bg-red-600 text-white">
              Popular
            </Badge>
          )}
          <Badge variant="secondary" className="bg-white/90 text-gray-700 capitalize">
            {pizza.category}
          </Badge>
        </div>
        <button className="absolute top-4 right-4 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors">
          <Heart className="w-5 h-5 text-gray-600 hover:text-red-500" />
        </button>
      </div>
      
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl font-bold text-gray-900">{pizza.name}</CardTitle>
            <CardDescription className="text-gray-600 mt-1">
              {pizza.description}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="mb-4">
          <p className="text-sm text-gray-500 mb-2">Ingredients:</p>
          <div className="flex flex-wrap gap-1">
            {pizza.ingredients.slice(0, 4).map((ingredient, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {ingredient}
              </Badge>
            ))}
            {pizza.ingredients.length > 4 && (
              <Badge variant="outline" className="text-xs">
                +{pizza.ingredients.length - 4} more
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-red-600">
              ${getSizePrice(pizza.price, pizza.size)}
            </span>
            <span className="text-sm text-gray-500 capitalize">
              {pizza.size} size
            </span>
          </div>
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <Plus className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};