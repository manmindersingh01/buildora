import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Phone, MapPin, Clock, Pizza as PizzaIcon, Users, Award, Heart } from 'lucide-react';
import { Pizza, Testimonial } from '@/types';
import { PizzaCard } from '@/components/PizzaCard';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { usePizzas } from '@/hooks/usePizzas';
import { useTestimonials } from '@/hooks/useTestimonials';

const Home: React.FC = () => {
  const { pizzas, loading: pizzasLoading } = usePizzas();
  const { testimonials, loading: testimonialsLoading } = useTestimonials();
  const [featuredPizzas, setFeaturedPizzas] = useState<Pizza[]>([]);

  useEffect(() => {
    if (pizzas.length > 0) {
      setFeaturedPizzas(pizzas.filter(pizza => pizza.popular).slice(0, 3));
    }
  }, [pizzas]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-yellow-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-orange-500 opacity-10"></div>
        <div className="container mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-red-100 text-red-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <PizzaIcon className="w-4 h-4" />
            Authentic Italian Pizzas
          </div>
          <h1 className="text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Welcome to <span className="text-red-600">Pizzera</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Discover the perfect blend of traditional Italian flavors and modern culinary artistry. 
            Each pizza is crafted with love, using the finest ingredients.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 text-lg">
              Order Now
            </Button>
            <Button size="lg" variant="outline" className="border-red-600 text-red-600 hover:bg-red-50 px-8 py-3 text-lg">
              View Menu
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Pizzas */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Popular Pizzas</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Handpicked favorites that keep our customers coming back for more
            </p>
          </div>
          
          {pizzasLoading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 h-64 rounded-lg mb-4"></div>
                  <div className="bg-gray-200 h-4 rounded mb-2"></div>
                  <div className="bg-gray-200 h-3 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8">
              {featuredPizzas.length > 0 && featuredPizzas.map((pizza) => (
                <PizzaCard key={pizza.id} pizza={pizza} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 px-4 bg-white/50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Pizzera?</h2>
            <p className="text-lg text-gray-600">What makes us the best pizza place in town</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow border-orange-100">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-red-600" />
              </div>
              <CardHeader>
                <CardTitle className="text-xl">Premium Quality</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We use only the finest Italian ingredients, imported directly from Italy to ensure authentic taste.
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6 hover:shadow-lg transition-shadow border-orange-100">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
              <CardHeader>
                <CardTitle className="text-xl">Fast Delivery</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Hot, fresh pizzas delivered to your door in 30 minutes or less, guaranteed fresh and delicious.
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6 hover:shadow-lg transition-shadow border-orange-100">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-yellow-600" />
              </div>
              <CardHeader>
                <CardTitle className="text-xl">Family Owned</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  A family business serving the community for over 15 years with recipes passed down through generations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
            <p className="text-lg text-gray-600">Real reviews from real pizza lovers</p>
          </div>
          
          {testimonialsLoading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 h-32 rounded-lg"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.length > 0 && testimonials.slice(0, 3).map((testimonial) => (
                <Card key={testimonial.id} className="p-6 hover:shadow-lg transition-shadow border-red-100">
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < testimonial.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-gray-600 mb-4 italic">"{testimonial.comment}"</p>
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3">
                        <span className="text-red-600 font-bold">{testimonial.name.charAt(0)}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{testimonial.name}</p>
                        <p className="text-sm text-gray-500">{testimonial.date}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 px-4 bg-gradient-to-r from-red-600 to-orange-500 text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8">Visit Us Today!</h2>
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div className="flex flex-col items-center">
              <MapPin className="w-8 h-8 mb-2" />
              <h3 className="text-xl font-semibold mb-2">Location</h3>
              <p>123 Pizza Street, Downtown</p>
              <p>Food District, City 12345</p>
            </div>
            <div className="flex flex-col items-center">
              <Phone className="w-8 h-8 mb-2" />
              <h3 className="text-xl font-semibold mb-2">Call Us</h3>
              <p>(555) 123-PIZZA</p>
              <p>Open 24/7</p>
            </div>
            <div className="flex flex-col items-center">
              <Clock className="w-8 h-8 mb-2" />
              <h3 className="text-xl font-semibold mb-2">Hours</h3>
              <p>Mon-Thu: 11AM - 11PM</p>
              <p>Fri-Sun: 11AM - 12AM</p>
            </div>
          </div>
          <Button size="lg" variant="secondary" className="text-red-600 bg-white hover:bg-gray-100">
            Order Online Now
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;