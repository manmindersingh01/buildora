## REACT BASE TEMP

### This is a template for a react project with the following features
