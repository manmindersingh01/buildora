import { Card, CardContent } from '@/components/ui/card';
import { Star, Quote } from 'lucide-react';
import { Testimonial } from '@/types';

const Testimonials = () => {
  const testimonials: Testimonial[] = [
    {
      id: '1',
      name: 'Priya Sharma',
      rating: 5,
      comment: 'Absolutely magical! She made me feel like a princess on my wedding day. The makeup was flawless and lasted the entire celebration.',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b167?w=100&h=100&fit=crop&crop=face',
      weddingDate: 'December 2023'
    },
    {
      id: '2',
      name: 'Sneha Patel',
      rating: 5,
      comment: 'I was so nervous about my makeup, but she understood exactly what I wanted. The result was beyond my expectations!',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
      weddingDate: 'November 2023'
    },
    {
      id: '3',
      name: 'Kavya Reddy',
      rating: 5,
      comment: 'Professional, talented, and so sweet! She made my entire wedding party look stunning. Highly recommend!',
      image: 'https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?w=100&h=100&fit=crop&crop=face',
      weddingDate: 'October 2023'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-rose-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-rose-600 to-purple-600 bg-clip-text text-transparent">
              Happy Brides
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Don't just take our word for it. Here's what our beautiful brides have to say 
            about their experience with us.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card 
              key={testimonial.id} 
              className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-rose-50"
            >
              <CardContent className="p-8 relative">
                {/* Quote Icon */}
                <div className="absolute top-6 right-6 text-rose-200">
                  <Quote className="w-8 h-8" />
                </div>
                
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-500 fill-current" />
                  ))}
                </div>
                
                {/* Comment */}
                <p className="text-gray-700 leading-relaxed mb-6 text-lg italic">
                  "{testimonial.comment}"
                </p>
                
                {/* Author Info */}
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full object-cover border-4 border-white shadow-lg"
                    />
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-rose-500 rounded-full flex items-center justify-center">
                      <Star className="w-3 h-3 text-white fill-current" />
                    </div>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-lg">{testimonial.name}</h4>
                    <p className="text-gray-600 text-sm">{testimonial.weddingDate}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-rose-500 to-purple-500 text-white p-8 rounded-3xl shadow-2xl max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">Ready to be our next happy bride?</h3>
            <p className="text-rose-100 mb-6">Join hundreds of satisfied brides who trusted us with their special day</p>
            <div className="flex items-center justify-center gap-4">
              <div className="flex -space-x-2">
                {testimonials.map((testimonial) => (
                  <img 
                    key={testimonial.id}
                    src={testimonial.image} 
                    alt={testimonial.name}
                    className="w-10 h-10 rounded-full border-2 border-white object-cover"
                  />
                )}
              </div>
              <span className="text-white font-medium">500+ Happy Brides</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;