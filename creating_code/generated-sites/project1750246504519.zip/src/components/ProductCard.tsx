import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingBag, Star } from 'lucide-react';
import { Product } from '@/types';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Card className="group cursor-pointer transform hover:scale-105 transition-all duration-300 bg-white/90 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl overflow-hidden">
      <div className="relative overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {product.isNew && (
            <Badge className="bg-gradient-to-r from-green-400 to-emerald-500 text-white font-bold px-3 py-1">
              ✨ NEW
            </Badge>
          )}
          {product.isTrending && (
            <Badge className="bg-gradient-to-r from-orange-400 to-red-500 text-white font-bold px-3 py-1">
              🔥 TRENDING
            </Badge>
          )}
        </div>
        <div className="absolute top-4 right-4">
          <Button 
            size="sm" 
            variant="outline" 
            className="bg-white/80 backdrop-blur-sm border-0 hover:bg-white hover:scale-110 transition-all duration-200 rounded-full p-2"
          >
            <Heart className="w-4 h-4 text-pink-500" />
          </Button>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold rounded-full px-6">
            <ShoppingBag className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-bold text-lg text-gray-800 group-hover:text-purple-600 transition-colors">
            {product.name}
          </h3>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-medium text-gray-600">4.9</span>
          </div>
        </div>
        <p className="text-gray-600 text-sm mb-3">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-black text-purple-600">${product.price}</span>
          <div className="flex gap-1">
            {product.colors.slice(0, 3).map((color, index) => (
              <div 
                key={index}
                className="w-6 h-6 rounded-full border-2 border-white shadow-md"
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}