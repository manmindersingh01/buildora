import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Heart, Calendar, ArrowRight, Phone, Mail, MapPin, User, Palette, Sparkles } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { ServiceCard } from '@/components/ServiceCard';
import { TestimonialCard } from '@/components/TestimonialCard';
import { ContactForm } from '@/components/ContactForm';
import { Service, Testimonial, GalleryImage } from '@/types';
import axios from 'axios';

const Home: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [galleryImages, setGalleryImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Mock data for services
      const mockServices: Service[] = [
        {
          id: '1',
          name: 'Bridal Glam Makeup',
          description: 'Complete bridal makeup with HD finish, contouring, and long-lasting wear perfect for your special day.',
          price: 299,
          duration: '2.5 hours',
          image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&h=400&fit=crop',
          features: ['HD Makeup', 'Contouring', 'False Eyelashes', 'Touch-up Kit']
        },
        {
          id: '2',
          name: 'Pre-Wedding Shoot',
          description: 'Elegant makeup for your pre-wedding photoshoot with natural glow and camera-ready finish.',
          price: 199,
          duration: '1.5 hours',
          image: 'https://images.unsplash.com/photo-1594736797933-d0200ba5e829?w=500&h=400&fit=crop',
          features: ['Natural Glow', 'Photo-Ready', 'Waterproof', 'Touch-ups']
        },
        {
          id: '3',
          name: 'Reception Makeup',
          description: 'Glamorous evening makeup for your reception with bold colors and dramatic effects.',
          price: 249,
          duration: '2 hours',
          image: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=500&h=400&fit=crop',
          features: ['Bold Colors', 'Shimmer Effects', 'Long-lasting', 'Evening Glam']
        }
      ];

      const mockTestimonials: Testimonial[] = [
        {
          id: '1',
          name: 'Sarah Johnson',
          service: 'Bridal Glam Makeup',
          rating: 5,
          comment: 'Absolutely stunning work! My makeup looked flawless throughout the entire wedding day. Highly recommend!',
          image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=80&h=80&fit=crop&crop=face',
          date: '2024-01-15'
        },
        {
          id: '2',
          name: 'Emily Chen',
          service: 'Pre-Wedding Shoot',
          rating: 5,
          comment: 'The natural look was perfect for our outdoor shoot. The makeup artist understood exactly what I wanted.',
          image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop&crop=face',
          date: '2024-01-20'
        },
        {
          id: '3',
          name: 'Rachel Martinez',
          service: 'Reception Makeup',
          rating: 5,
          comment: 'The evening glam look was incredible! I felt like a movie star at my reception.',
          image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop&crop=face',
          date: '2024-01-25'
        }
      ];

      const mockGallery: GalleryImage[] = [
        {
          id: '1',
          url: 'https://images.unsplash.com/photo-1560869713-bf9b90b48c81?w=400&h=500&fit=crop',
          alt: 'Bridal makeup look 1',
          category: 'bridal'
        },
        {
          id: '2',
          url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400&h=500&fit=crop',
          alt: 'Bridal makeup look 2',
          category: 'bridal'
        },
        {
          id: '3',
          url: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=400&h=500&fit=crop',
          alt: 'Evening makeup look',
          category: 'evening'
        },
        {
          id: '4',
          url: 'https://images.unsplash.com/photo-1594736797933-d0200ba5e829?w=400&h=500&fit=crop',
          alt: 'Natural makeup look',
          category: 'natural'
        }
      ];

      setServices(mockServices);
      setTestimonials(mockTestimonials);
      setGalleryImages(mockGallery);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-pink-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-600/10 to-rose-600/10"></div>
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-pink-100 text-pink-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            Professional Bridal Makeup Artist
          </div>
          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent mb-6">
            Your Perfect
            <br />Wedding Look
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Transform your special day with stunning bridal makeup that captures your unique beauty and creates lasting memories.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white px-8 py-3">
              <Calendar className="w-5 h-5 mr-2" />
              Book Consultation
            </Button>
            <Button size="lg" variant="outline" className="border-pink-600 text-pink-600 hover:bg-pink-50 px-8 py-3">
              View Portfolio
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Signature Services</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From intimate ceremonies to grand celebrations, we offer personalized makeup services for every moment of your wedding journey.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {services.length > 0 && services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-pink-50 to-rose-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Work</h2>
            <p className="text-lg text-gray-600">Discover the artistry behind every look</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {galleryImages.length > 0 && galleryImages.map((image) => (
              <div key={image.id} className="group relative overflow-hidden rounded-2xl aspect-[3/4] bg-white shadow-lg hover:shadow-xl transition-all duration-300">
                <img 
                  src={image.url} 
                  alt={image.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Meet Your Artist</h2>
            <p className="text-lg text-gray-600 mb-6">
              With over 8 years of experience in bridal makeup artistry, I specialize in creating timeless, elegant looks that enhance your natural beauty. Every bride deserves to feel confident and radiant on her special day.
            </p>
            <div className="grid sm:grid-cols-2 gap-6 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-pink-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">500+ Brides</h3>
                  <p className="text-gray-600 text-sm">Happy clients</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
                  <Palette className="w-6 h-6 text-pink-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">8+ Years</h3>
                  <p className="text-gray-600 text-sm">Experience</p>
                </div>
              </div>
            </div>
            <Button className="bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white">
              Learn More About Me
            </Button>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-400 to-rose-400 rounded-3xl transform rotate-6"></div>
            <img 
              src="https://images.unsplash.com/photo-1560869713-bf9b90b48c81?w=600&h=700&fit=crop" 
              alt="Makeup Artist" 
              className="relative w-full h-96 lg:h-[500px] object-cover rounded-3xl shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-pink-50 to-rose-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What Brides Say</h2>
            <p className="text-lg text-gray-600">Real stories from real brides</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.length > 0 && testimonials.map((testimonial) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Let's Create Magic Together</h2>
            <p className="text-lg text-gray-600 mb-8">
              Ready to book your bridal makeup consultation? Let's discuss your vision and create the perfect look for your special day.
            </p>
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
                  <Phone className="w-6 h-6 text-pink-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Call Us</p>
                  <p className="text-gray-600">(555) 123-4567</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
                  <Mail className="w-6 h-6 text-pink-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Email Us</p>
                  <p className="text-gray-600">hello@bridalmakeup.com</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-pink-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Visit Us</p>
                  <p className="text-gray-600">123 Beauty Lane, City, State 12345</p>
                </div>
              </div>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;