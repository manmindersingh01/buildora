import { useState, useEffect } from 'react';
import { Todo, TodoFilters } from '@/types';
import { todoApi } from '@/lib/api';

export const useTodos = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch todos from API
  const fetchTodos = async () => {
    try {
      setLoading(true);
      const response = await todoApi.getTodos();
      if (response.success) {
        setTodos(response.data);
      }
      setError(null);
    } catch (err) {
      setError('Failed to fetch todos');
      console.error('Error fetching todos:', err);
    } finally {
      setLoading(false);
    }
  };

  // Add new todo
  const addTodo = async (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const response = await todoApi.createTodo(todoData);
      if (response.success) {
        setTodos(prev => [response.data, ...prev]);
      }
    } catch (err) {
      setError('Failed to create todo');
      console.error('Error creating todo:', err);
    }
  };

  // Update todo
  const updateTodo = async (id: string, updates: Partial<Todo>) => {
    try {
      const response = await todoApi.updateTodo(id, updates);
      if (response.success) {
        setTodos(prev => prev.map(todo => 
          todo.id === id ? { ...todo, ...updates } : todo
        ));
      }
    } catch (err) {
      setError('Failed to update todo');
      console.error('Error updating todo:', err);
    }
  };

  // Delete todo
  const deleteTodo = async (id: string) => {
    try {
      const response = await todoApi.deleteTodo(id);
      if (response.success) {
        setTodos(prev => prev.filter(todo => todo.id !== id));
      }
    } catch (err) {
      setError('Failed to delete todo');
      console.error('Error deleting todo:', err);
    }
  };

  // Toggle todo completion
  const toggleTodo = async (id: string) => {
    try {
      const response = await todoApi.toggleTodo(id);
      if (response.success) {
        setTodos(prev => prev.map(todo => 
          todo.id === id ? { ...todo, completed: !todo.completed } : todo
        ));
      }
    } catch (err) {
      setError('Failed to toggle todo');
      console.error('Error toggling todo:', err);
    }
  };

  useEffect(() => {
    fetchTodos();
  }, []);

  return {
    todos,
    loading,
    error,
    addTodo,
    updateTodo,
    deleteTodo,
    toggleTodo,
    refetch: fetchTodos
  };
};