import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { TodoForm } from '@/components/TodoForm';
import { TodoItem } from '@/components/TodoItem';
import { TodoStats } from '@/components/TodoStats';
import { TodoFilters } from '@/components/TodoFilters';
import { useTodos } from '@/hooks/useTodos';
import { Todo, TodoFilters as TodoFiltersType } from '@/types';
import { plus, loader, alert-circle, check-circle } from 'lucide-react';

export const TodoApp: React.FC = () => {
  const { todos, loading, error, addTodo, updateTodo, deleteTodo, toggleTodo } = useTodos();
  const [showForm, setShowForm] = useState(false);
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);
  const [filters, setFilters] = useState<TodoFiltersType>({
    category: 'all',
    priority: 'all',
    status: 'all',
    search: ''
  });

  // Filter and sort todos
  const filteredTodos = useMemo(() => {
    let filtered = todos.filter(todo => {
      // Search filter
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        if (!todo.title.toLowerCase().includes(searchLower) && 
            !todo.description?.toLowerCase().includes(searchLower)) {
          return false;
        }
      }
      
      // Category filter
      if (filters.category !== 'all' && todo.category !== filters.category) {
        return false;
      }
      
      // Priority filter
      if (filters.priority !== 'all' && todo.priority !== filters.priority) {
        return false;
      }
      
      // Status filter
      if (filters.status === 'completed' && !todo.completed) {
        return false;
      }
      if (filters.status === 'pending' && todo.completed) {
        return false;
      }
      
      return true;
    });
    
    // Sort by: incomplete first, then by priority (high to low), then by due date
    return filtered.sort((a, b) => {
      // Completed todos go to bottom
      if (a.completed !== b.completed) {
        return a.completed ? 1 : -1;
      }
      
      // Sort by priority
      const priorityOrder = { high: 3, medium: 2, low: 1 };
      const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
      if (priorityDiff !== 0) return priorityDiff;
      
      // Sort by due date (earliest first)
      if (a.dueDate && b.dueDate) {
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      if (a.dueDate) return -1;
      if (b.dueDate) return 1;
      
      // Finally, sort by creation date (newest first)
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [todos, filters]);

  const handleAddTodo = async (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    await addTodo(todoData);
    setShowForm(false);
  };

  const handleEditTodo = async (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingTodo) {
      await updateTodo(editingTodo.id, todoData);
      setEditingTodo(null);
    }
  };

  const handleClearFilters = () => {
    setFilters({
      category: 'all',
      priority: 'all',
      status: 'all',
      search: ''
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="flex items-center gap-3 text-gray-600">
          <loader className="h-6 w-6 animate-spin" />
          <span className="text-lg">Loading your todos...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            My <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Todo</span> App
          </h1>
          <p className="text-gray-600">Stay organized and get things done efficiently</p>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <alert-circle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Stats */}
        <TodoStats todos={todos} />

        {/* Add Todo Button */}
        <div className="flex justify-center mb-6">
          <Button 
            onClick={() => setShowForm(!showForm)}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg"
            size="lg"
          >
            <plus className="h-5 w-5 mr-2" />
            Add New Todo
          </Button>
        </div>

        {/* Todo Form */}
        {(showForm || editingTodo) && (
          <div className="mb-8">
            <TodoForm
              onSubmit={editingTodo ? handleEditTodo : handleAddTodo}
              initialData={editingTodo || undefined}
              onCancel={() => {
                setShowForm(false);
                setEditingTodo(null);
              }}
            />
          </div>
        )}

        {/* Filters */}
        <TodoFilters 
          filters={filters}
          onFiltersChange={setFilters}
          onClearFilters={handleClearFilters}
        />

        {/* Todo List */}
        <div className="space-y-4">
          {filteredTodos.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <div className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                    <check-circle className="h-8 w-8 text-gray-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-1">
                      {todos.length === 0 ? 'No todos yet' : 'No todos match your filters'}
                    </h3>
                    <p className="text-gray-500">
                      {todos.length === 0 
                        ? 'Create your first todo to get started!' 
                        : 'Try adjusting your search or filter criteria.'}
                    </p>
                  </div>
                  {todos.length === 0 && (
                    <Button 
                      onClick={() => setShowForm(true)}
                      className="mt-2"
                    >
                      <plus className="h-4 w-4 mr-2" />
                      Add Your First Todo
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {filteredTodos.map(todo => (
                <TodoItem
                  key={todo.id}
                  todo={todo}
                  onToggle={toggleTodo}
                  onEdit={setEditingTodo}
                  onDelete={deleteTodo}
                />
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-12 pt-8 border-t border-gray-200">
          <p className="text-gray-500 text-sm">
            Built with React, TypeScript & Tailwind CSS
          </p>
        </div>
      </div>
    </div>
  );
};