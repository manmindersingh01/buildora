export interface Pizza {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: 'classic' | 'premium' | 'specialty';
  ingredients: string[];
  size: 'small' | 'medium' | 'large';
  isVegetarian: boolean;
  isPopular?: boolean;
}

export interface CartItem {
  pizza: Pizza;
  quantity: number;
  size: 'small' | 'medium' | 'large';
  totalPrice: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface Order {
  id: string;
  customer: Customer;
  items: CartItem[];
  totalAmount: number;
  status: 'pending' | 'preparing' | 'ready' | 'delivered';
  orderDate: string;
  estimatedDelivery: string;
}

export interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  pizzaName?: string;
}