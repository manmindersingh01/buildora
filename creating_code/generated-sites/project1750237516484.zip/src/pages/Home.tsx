import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Pizza, Review } from '@/types';
import { Star, Phone, MapPin, Clock, ArrowRight } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { PizzaCard } from '@/components/PizzaCard';
import axios from 'axios';

export default function Home() {
  const [featuredPizzas, setFeaturedPizzas] = useState<Pizza[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeaturedPizzas();
    fetchReviews();
  }, []);

  const fetchFeaturedPizzas = async () => {
    try {
      const response = await axios.get('/api/pizzas/featured');
      if (response.data.success) {
        setFeaturedPizzas(response.data.data);
      }
    } catch (error) {
      // Fallback data for demo
      setFeaturedPizzas([
        {
          id: '1',
          name: 'Margherita Supreme',
          description: 'Fresh mozzarella, tomato sauce, basil, and premium olive oil',
          price: 16.99,
          image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400',
          category: 'classic',
          ingredients: ['Mozzarella', 'Tomato Sauce', 'Fresh Basil', 'Olive Oil'],
          size: 'medium',
          isVegetarian: true,
          isPopular: true
        },
        {
          id: '2',
          name: 'Pepperoni Deluxe',
          description: 'Premium pepperoni, mozzarella cheese, and our signature sauce',
          price: 19.99,
          image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400',
          category: 'classic',
          ingredients: ['Pepperoni', 'Mozzarella', 'Tomato Sauce'],
          size: 'medium',
          isVegetarian: false,
          isPopular: true
        },
        {
          id: '3',
          name: 'BBQ Chicken Ranch',
          description: 'Grilled chicken, BBQ sauce, red onions, and ranch dressing',
          price: 22.99,
          image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400',
          category: 'specialty',
          ingredients: ['Grilled Chicken', 'BBQ Sauce', 'Red Onions', 'Ranch', 'Mozzarella'],
          size: 'medium',
          isVegetarian: false,
          isPopular: true
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async () => {
    try {
      const response = await axios.get('/api/reviews');
      if (response.data.success) {
        setReviews(response.data.data);
      }
    } catch (error) {
      // Fallback data for demo
      setReviews([
        {
          id: '1',
          customerName: 'Sarah Johnson',
          rating: 5,
          comment: 'Best pizza in town! The Margherita Supreme is absolutely delicious.',
          date: '2024-01-15',
          pizzaName: 'Margherita Supreme'
        },
        {
          id: '2',
          customerName: 'Mike Chen',
          rating: 5,
          comment: 'Fast delivery and amazing taste. Will definitely order again!',
          date: '2024-01-12',
          pizzaName: 'Pepperoni Deluxe'
        }
      ]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-red-600 to-orange-600 text-white py-20">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-yellow-200 to-orange-200 bg-clip-text text-transparent">
              Welcome to Pizzera
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-orange-100">
              Authentic Italian pizzas made with love, fresh ingredients, and traditional recipes
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-8 py-4 text-lg">
                Order Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-red-600 px-8 py-4 text-lg">
                View Menu
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Info */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>
              <p className="text-gray-600">30 minutes or less guaranteed</p>
            </div>
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Easy Ordering</h3>
              <p className="text-gray-600">Call, click, or visit us</p>
            </div>
            <div className="text-center">
              <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-yellow-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Local Favorite</h3>
              <p className="text-gray-600">Serving the community since 2010</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Pizzas */}
      <section className="py-16 bg-gradient-to-br from-orange-50 to-red-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Signature Pizzas</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Handcrafted with the finest ingredients and baked to perfection in our traditional stone oven
            </p>
          </div>
          
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading delicious pizzas...</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredPizzas.length > 0 && featuredPizzas.map((pizza) => (
                <PizzaCard key={pizza.id} pizza={pizza} />
              ))}
            </div>
          )}
          
          <div className="text-center mt-12">
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
              View Full Menu
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">The Pizzera Story</h2>
              <p className="text-lg text-gray-600 mb-6">
                Founded in 2010 by the Rossi family, Pizzera brings authentic Italian flavors to your neighborhood. 
                Our secret? Fresh ingredients, traditional recipes passed down through generations, and a wood-fired 
                oven that gives every pizza that perfect crispy crust.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                From our classic Margherita to our innovative specialty pizzas, every bite tells a story of 
                passion, quality, and love for great food.
              </p>
              <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                Learn More About Us
              </Button>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1571407970349-bc81e7e96d47?w=600" 
                alt="Pizza chef at work" 
                className="rounded-lg shadow-2xl w-full h-96 object-cover"
              />
              <div className="absolute -bottom-6 -right-6 bg-red-600 text-white p-6 rounded-lg shadow-lg">
                <p className="text-2xl font-bold">14+</p>
                <p className="text-sm">Years of Excellence</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="py-16 bg-gradient-to-br from-red-50 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">What Our Customers Say</h2>
            <p className="text-xl text-gray-600">Don't just take our word for it</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {reviews.length > 0 && reviews.slice(0, 2).map((review) => (
              <Card key={review.id} className="bg-white shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{review.comment}"</p>
                  <div className="flex justify-between items-center">
                    <p className="font-semibold text-gray-800">{review.customerName}</p>
                    {review.pizzaName && (
                      <Badge variant="secondary" className="bg-red-100 text-red-700">
                        {review.pizzaName}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Visit Us Today</h2>
            <p className="text-xl text-gray-300">Experience the taste of authentic Italian pizza</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <Phone className="h-12 w-12 text-red-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Call Us</h3>
              <p className="text-gray-300">(555) 123-PIZZA</p>
              <p className="text-gray-300">(555) 123-7492</p>
            </div>
            <div>
              <MapPin className="h-12 w-12 text-orange-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Visit Us</h3>
              <p className="text-gray-300">123 Pizza Street</p>
              <p className="text-gray-300">Foodie City, FC 12345</p>
            </div>
            <div>
              <Clock className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Hours</h3>
              <p className="text-gray-300">Mon-Thu: 11AM - 10PM</p>
              <p className="text-gray-300">Fri-Sun: 11AM - 11PM</p>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
              Order Online Now
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}