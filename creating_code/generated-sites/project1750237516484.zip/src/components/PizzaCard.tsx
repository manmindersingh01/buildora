import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Pizza } from '@/types';
import { Star, Heart, ShoppingCart } from 'lucide-react';
import { useState } from 'react';

interface PizzaCardProps {
  pizza: Pizza;
}

export function PizzaCard({ pizza }: PizzaCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  return (
    <Card className="group hover:shadow-xl transition-all duration-300 overflow-hidden bg-white">
      <div className="relative overflow-hidden">
        <img 
          src={pizza.image} 
          alt={pizza.name}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-3 left-3 flex gap-2">
          {pizza.isPopular && (
            <Badge className="bg-red-600 text-white hover:bg-red-700">
              <Star className="h-3 w-3 mr-1 fill-current" />
              Popular
            </Badge>
          )}
          {pizza.isVegetarian && (
            <Badge className="bg-green-600 text-white hover:bg-green-700">
              Vegetarian
            </Badge>
          )}
        </div>
        <button 
          onClick={toggleFavorite}
          className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-sm rounded-full hover:bg-white transition-colors"
        >
          <Heart 
            className={`h-5 w-5 transition-colors ${
              isFavorite ? 'text-red-500 fill-current' : 'text-gray-600'
            }`} 
          />
        </button>
        <div className="absolute bottom-3 right-3">
          <Badge className="bg-black/70 text-white backdrop-blur-sm">
            {pizza.category.charAt(0).toUpperCase() + pizza.category.slice(1)}
          </Badge>
        </div>
      </div>
      
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl font-bold text-gray-800 group-hover:text-red-600 transition-colors">
            {pizza.name}
          </CardTitle>
          <div className="text-right">
            <p className="text-2xl font-bold text-red-600">${pizza.price}</p>
            <p className="text-sm text-gray-500 capitalize">{pizza.size}</p>
          </div>
        </div>
        <CardDescription className="text-gray-600 line-clamp-2">
          {pizza.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="mb-4">
          <p className="text-sm font-medium text-gray-700 mb-2">Ingredients:</p>
          <div className="flex flex-wrap gap-1">
            {pizza.ingredients.slice(0, 4).map((ingredient, index) => (
              <Badge key={index} variant="secondary" className="text-xs bg-gray-100 text-gray-700">
                {ingredient}
              </Badge>
            ))}
            {pizza.ingredients.length > 4 && (
              <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-700">
                +{pizza.ingredients.length - 4} more
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button 
            className="flex-1 bg-red-600 hover:bg-red-700 text-white transition-colors"
            size="sm"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Add to Cart
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            className="border-red-600 text-red-600 hover:bg-red-50"
          >
            Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}