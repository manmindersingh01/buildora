import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Heart, Phone, Calendar, ArrowRight, Eye, Palette, Users } from 'lucide-react';
import { Service, Testimonial, GalleryImage } from '@/types';
import axios from 'axios';
import { ServiceCard } from '@/components/ServiceCard';
import { TestimonialCard } from '@/components/TestimonialCard';
import { GallerySection } from '@/components/GallerySection';
import { ContactForm } from '@/components/ContactForm';

const Home: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [galleryImages, setGalleryImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Mock data for demonstration
        const mockServices: Service[] = [
          {
            id: '1',
            name: 'Bridal Makeup Package',
            description: 'Complete bridal transformation with HD makeup, hairstyling, and touch-up kit',
            price: 25000,
            duration: '4-5 hours',
            image: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=400',
            category: 'bridal',
            features: ['HD Makeup', 'Hair Styling', 'Draping Assistance', 'Touch-up Kit', 'Trial Session']
          },
          {
            id: '2',
            name: 'Engagement Makeup',
            description: 'Elegant and sophisticated look for your special engagement ceremony',
            price: 15000,
            duration: '2-3 hours',
            image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400',
            category: 'party',
            features: ['Professional Makeup', 'Hair Styling', 'Jewelry Consultation', 'Photo Touch-ups']
          },
          {
            id: '3',
            name: 'Reception Glam',
            description: 'Glamorous evening look perfect for wedding receptions and parties',
            price: 18000,
            duration: '3 hours',
            image: 'https://images.unsplash.com/photo-1594736797933-d0279ba2e9a8?w=400',
            category: 'party',
            features: ['Evening Makeup', 'Hair Styling', 'Outfit Coordination', 'Long-lasting Formula']
          }
        ];

        const mockTestimonials: Testimonial[] = [
          {
            id: '1',
            name: 'Priya Sharma',
            rating: 5,
            comment: 'Absolutely stunning work! Made my wedding day so much more special. The makeup lasted the entire day.',
            image: 'https://images.unsplash.com/photo-1494790108755-2616c90e6f41?w=80',
            event: 'Wedding',
            date: '2024-01-15'
          },
          {
            id: '2',
            name: 'Anjali Patel',
            rating: 5,
            comment: 'Professional service and gorgeous results. I felt like a princess on my engagement day!',
            image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80',
            event: 'Engagement',
            date: '2024-02-10'
          },
          {
            id: '3',
            name: 'Kavya Reddy',
            rating: 5,
            comment: 'Exceeded all expectations! The attention to detail and personalized service was amazing.',
            image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80',
            event: 'Reception',
            date: '2024-01-28'
          }
        ];

        const mockGallery: GalleryImage[] = [
          {
            id: '1',
            url: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=600',
            alt: 'Bridal Makeup Look',
            category: 'bridal',
            description: 'Traditional bridal look with bold eyes'
          },
          {
            id: '2',
            url: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=600',
            alt: 'Engagement Makeup',
            category: 'engagement',
            description: 'Soft glam for engagement ceremony'
          },
          {
            id: '3',
            url: 'https://images.unsplash.com/photo-1594736797933-d0279ba2e9a8?w=600',
            alt: 'Party Makeup',
            category: 'party',
            description: 'Glamorous evening party look'
          },
          {
            id: '4',
            url: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600',
            alt: 'Bridal Eyes',
            category: 'bridal',
            description: 'Dramatic bridal eye makeup'
          }
        ];

        setServices(mockServices);
        setTestimonials(mockTestimonials);
        setGalleryImages(mockGallery);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-pink-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-lg sticky top-0 z-50 border-b border-pink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-2 rounded-full">
                <Palette className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                Bella Bridal
              </h1>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#home" className="text-gray-700 hover:text-pink-600 transition-colors">Home</a>
              <a href="#services" className="text-gray-700 hover:text-pink-600 transition-colors">Services</a>
              <a href="#gallery" className="text-gray-700 hover:text-pink-600 transition-colors">Gallery</a>
              <a href="#testimonials" className="text-gray-700 hover:text-pink-600 transition-colors">Reviews</a>
              <a href="#contact" className="text-gray-700 hover:text-pink-600 transition-colors">Contact</a>
            </div>
            <Button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
              <Phone className="h-4 w-4 mr-2" />
              Book Now
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-pink-100/50 via-purple-100/50 to-rose-100/50 backdrop-blur-sm"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2 text-sm">
                ✨ Premium Bridal Makeup Services
              </Badge>
              <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-rose-600 bg-clip-text text-transparent leading-tight">
                Your Dream
                <br />
                <span className="text-pink-500">Wedding Look</span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Transform into the most beautiful version of yourself with our expert bridal makeup artistry. 
                Making your special day absolutely magical.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button size="lg" className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-lg px-8 py-4 h-auto">
                <Calendar className="h-5 w-5 mr-2" />
                Book Consultation
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
              <Button size="lg" variant="outline" className="border-pink-300 text-pink-600 hover:bg-pink-50 text-lg px-8 py-4 h-auto">
                <Eye className="h-5 w-5 mr-2" />
                View Gallery
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto mt-16">
              <div className="text-center space-y-2">
                <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 rounded-full w-16 h-16 mx-auto flex items-center justify-center">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800">500+</h3>
                <p className="text-gray-600">Happy Brides</p>
              </div>
              <div className="text-center space-y-2">
                <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 rounded-full w-16 h-16 mx-auto flex items-center justify-center">
                  <Star className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800">5.0</h3>
                <p className="text-gray-600">Average Rating</p>
              </div>
              <div className="text-center space-y-2">
                <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 rounded-full w-16 h-16 mx-auto flex items-center justify-center">
                  <Heart className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800">5+</h3>
                <p className="text-gray-600">Years Experience</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2">
              Our Services
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Bridal Beauty Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From traditional to contemporary, we create stunning looks that reflect your unique style
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.length > 0 && services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <GallerySection images={galleryImages} />

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-gradient-to-br from-pink-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2">
              Client Reviews
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              What Brides Say
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Don't just take our word for it - hear from our beautiful brides
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.length > 0 && testimonials.map((testimonial) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <ContactForm />

      {/* Footer */}
      <footer className="bg-gradient-to-r from-pink-600 to-purple-700 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="bg-white p-2 rounded-full">
                  <Palette className="h-6 w-6 text-pink-600" />
                </div>
                <h3 className="text-2xl font-bold">Bella Bridal</h3>
              </div>
              <p className="text-pink-100">
                Creating beautiful bridal looks that make your special day unforgettable.
              </p>
            </div>
            
            <div className="space-y-4">
              <h4 className="text-lg font-semibold">Services</h4>
              <ul className="space-y-2 text-pink-100">
                <li>Bridal Makeup</li>
                <li>Engagement Makeup</li>
                <li>Reception Glam</li>
                <li>Hair Styling</li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="text-lg font-semibold">Quick Links</h4>
              <ul className="space-y-2 text-pink-100">
                <li><a href="#home" className="hover:text-white transition-colors">Home</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Services</a></li>
                <li><a href="#gallery" className="hover:text-white transition-colors">Gallery</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="text-lg font-semibold">Contact Info</h4>
              <div className="space-y-2 text-pink-100">
                <p className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  +91 98765 43210
                </p>
                <p className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  hello@bellabridal.com
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-pink-500 mt-12 pt-8 text-center text-pink-100">
            <p>&copy; 2024 Bella Bridal. All rights reserved. Made with ❤️ for beautiful brides.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;