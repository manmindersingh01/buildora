import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, Star, Check } from 'lucide-react';
import { Service } from '@/types';

const Services = () => {
  const services: Service[] = [
    {
      id: '1',
      name: 'Bridal Makeup',
      description: 'Complete bridal transformation with traditional and contemporary techniques',
      price: '$299',
      duration: '3-4 hours',
      image: 'https://images.unsplash.com/photo-1594736797933-d0d79ba7ac61?w=400&h=300&fit=crop&crop=face',
      features: ['HD Makeup', 'False Lashes', 'Airbrush Foundation', 'Touch-up Kit']
    },
    {
      id: '2',
      name: 'Engagement Glam',
      description: 'Elegant and sophisticated look for your engagement ceremony',
      price: '$199',
      duration: '2-3 hours',
      image: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=400&h=300&fit=crop&crop=face',
      features: ['Glow Makeup', 'Contouring', 'Eye Enhancement', 'Lip Color']
    },
    {
      id: '3',
      name: 'Reception Ready',
      description: 'Glamorous evening look that photographs beautifully',
      price: '$249',
      duration: '2.5-3 hours',
      image: 'https://images.unsplash.com/photo-1606170033648-5d55a3eaca8b?w=400&h=300&fit=crop&crop=face',
      features: ['Smokey Eyes', 'Highlighting', 'Long-lasting', 'Photo-ready']
    },
    {
      id: '4',
      name: 'Mehendi Ceremony',
      description: 'Fresh and vibrant look perfect for pre-wedding celebrations',
      price: '$149',
      duration: '1.5-2 hours',
      image: 'https://images.unsplash.com/photo-1592106680408-e80885e3d381?w=400&h=300&fit=crop&crop=face',
      features: ['Natural Glow', 'Colorful Accents', 'Comfortable Wear', 'Quick Application']
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-rose-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-rose-600 to-purple-600 bg-clip-text text-transparent">
              Our Signature Services
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Each service is carefully crafted to enhance your natural beauty and make you feel 
            absolutely radiant on your special day.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card 
              key={service.id} 
              className={`group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 ${
                index % 2 === 0 ? 'bg-gradient-to-br from-white to-rose-50' : 'bg-gradient-to-br from-white to-purple-50'
              }`}
            >
              <div className="relative overflow-hidden rounded-t-lg">
                <img 
                  src={service.image} 
                  alt={service.name}
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm font-medium">5.0</span>
                  </div>
                </div>
              </div>
              
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2 text-gray-800">{service.name}</h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">{service.description}</p>
                
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-bold text-rose-600">{service.price}</span>
                  <div className="flex items-center gap-1 text-gray-500">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">{service.duration}</span>
                  </div>
                </div>
                
                <div className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <Button 
                  className="w-full bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white rounded-full transition-all duration-300 transform hover:scale-105"
                >
                  Book Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;