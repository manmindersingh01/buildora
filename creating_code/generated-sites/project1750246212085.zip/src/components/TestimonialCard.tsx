import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Quote } from 'lucide-react';
import { Testimonial } from '@/types';

interface TestimonialCardProps {
  testimonial: Testimonial;
}

export const TestimonialCard: React.FC<TestimonialCardProps> = ({ testimonial }) => {
  return (
    <Card className="group hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm border border-pink-100 overflow-hidden">
      <CardContent className="p-6 space-y-4">
        <div className="flex items-center space-x-4">
          <img 
            src={testimonial.image} 
            alt={testimonial.name}
            className="w-16 h-16 rounded-full object-cover border-2 border-pink-200"
          />
          <div className="flex-1">
            <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
            <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white text-xs">
              {testimonial.event}
            </Badge>
          </div>
          <div className="text-pink-400">
            <Quote className="h-8 w-8" />
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          {[...Array(testimonial.rating)].map((_, index) => (
            <Star key={index} className="h-4 w-4 fill-current text-yellow-400" />
          ))}
        </div>
        
        <p className="text-gray-600 leading-relaxed italic">
          "{testimonial.comment}"
        </p>
        
        <div className="text-sm text-gray-500">
          {new Date(testimonial.date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}
        </div>
      </CardContent>
    </Card>
  );
};