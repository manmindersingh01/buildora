import React from 'react';
import { Heart, Phone, Mail, MapPin, Clock } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-gray-900 via-purple-900 to-indigo-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-gradient-to-r from-pink-500 to-purple-500 p-2 rounded-lg">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Bella Bridal
              </span>
            </div>
            <p className="text-gray-300 mb-4">
              Making brides feel beautiful and confident on their most special day with professional makeup artistry.
            </p>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-pink-300">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-pink-300 transition-colors">Home</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-pink-300 transition-colors">Services</a></li>
              <li><a href="#gallery" className="text-gray-300 hover:text-pink-300 transition-colors">Gallery</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-pink-300 transition-colors">About Us</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-pink-300 transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Services */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-purple-300">Services</h3>
            <ul className="space-y-2">
              <li className="text-gray-300">Bridal Makeup</li>
              <li className="text-gray-300">Engagement Makeup</li>
              <li className="text-gray-300">Reception Glam</li>
              <li className="text-gray-300">Hair Styling</li>
              <li className="text-gray-300">Pre-wedding Trials</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-indigo-300">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-center text-gray-300">
                <Phone className="h-4 w-4 mr-3 text-pink-400" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center text-gray-300">
                <Mail className="h-4 w-4 mr-3 text-purple-400" />
                <span>hello@bellabridal.com</span>
              </div>
              <div className="flex items-center text-gray-300">
                <MapPin className="h-4 w-4 mr-3 text-indigo-400" />
                <span>123 Beauty Street, Mumbai, India</span>
              </div>
              <div className="flex items-center text-gray-300">
                <Clock className="h-4 w-4 mr-3 text-pink-400" />
                <span>Mon-Sun: 9:00 AM - 8:00 PM</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Bella Bridal Makeup. All rights reserved. Made with{' '}
            <Heart className="h-4 w-4 inline text-pink-400" /> for beautiful brides.
          </p>
        </div>
      </div>
    </footer>
  );
};