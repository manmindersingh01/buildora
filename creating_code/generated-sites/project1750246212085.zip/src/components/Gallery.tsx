import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Eye, Heart } from 'lucide-react';
import { GalleryImage } from '@/types';

const Gallery = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  
  const categories = [
    { id: 'all', name: 'All Work' },
    { id: 'bridal', name: 'Bridal' },
    { id: 'engagement', name: 'Engagement' },
    { id: 'reception', name: 'Reception' },
    { id: 'mehendi', name: 'Mehendi' }
  ];

  const galleryImages: GalleryImage[] = [
    {
      id: '1',
      url: 'https://images.unsplash.com/photo-1594736797933-d0d79ba7ac61?w=500&h=600&fit=crop&crop=face',
      alt: 'Traditional Bridal Makeup',
      category: 'bridal'
    },
    {
      id: '2',
      url: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=500&h=600&fit=crop&crop=face',
      alt: 'Engagement Glam Look',
      category: 'engagement'
    },
    {
      id: '3',
      url: 'https://images.unsplash.com/photo-1606170033648-5d55a3eaca8b?w=500&h=600&fit=crop&crop=face',
      alt: 'Reception Evening Look',
      category: 'reception'
    },
    {
      id: '4',
      url: 'https://images.unsplash.com/photo-1592106680408-e80885e3d381?w=500&h=600&fit=crop&crop=face',
      alt: 'Mehendi Ceremony Makeup',
      category: 'mehendi'
    },
    {
      id: '5',
      url: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500&h=600&fit=crop&crop=face',
      alt: 'Classic Bridal Look',
      category: 'bridal'
    },
    {
      id: '6',
      url: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500&h=600&fit=crop&crop=face',
      alt: 'Modern Engagement Style',
      category: 'engagement'
    },
    {
      id: '7',
      url: 'https://images.unsplash.com/photo-1605462863863-10d9e47e15ee?w=500&h=600&fit=crop&crop=face',
      alt: 'Glamorous Reception',
      category: 'reception'
    },
    {
      id: '8',
      url: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=600&fit=crop&crop=face',
      alt: 'Colorful Mehendi Look',
      category: 'mehendi'
    },
    {
      id: '9',
      url: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=500&h=600&fit=crop&crop=face',
      alt: 'Royal Bridal Makeup',
      category: 'bridal'
    }
  ];

  const filteredImages = activeCategory === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  return (
    <section className="py-20 bg-gradient-to-b from-rose-50 to-purple-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-purple-600 to-rose-600 bg-clip-text text-transparent">
              Our Beautiful Work
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Every bride deserves to feel like royalty. Browse through our portfolio 
            of stunning transformations.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? "default" : "outline"}
              onClick={() => setActiveCategory(category.id)}
              className={`rounded-full px-6 py-2 transition-all duration-300 ${
                activeCategory === category.id
                  ? 'bg-gradient-to-r from-rose-500 to-purple-500 text-white shadow-lg transform scale-105'
                  : 'border-rose-300 text-rose-600 hover:bg-rose-50'
              }`}
            >
              {category.name}
            </Button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredImages.map((image, index) => (
            <Card 
              key={image.id} 
              className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-white"
            >
              <div className="relative overflow-hidden">
                <img 
                  src={image.url} 
                  alt={image.alt}
                  className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300">
                  <div className="absolute bottom-6 left-6 right-6">
                    <h3 className="text-white font-semibold text-lg mb-2">{image.alt}</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-white/80 text-sm capitalize">{image.category}</span>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="border-white/50 text-white hover:bg-white/20">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="border-white/50 text-white hover:bg-white/20">
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Category Badge */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                  <span className="text-sm font-medium text-gray-700 capitalize">{image.category}</span>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            size="lg"
            className="bg-gradient-to-r from-purple-500 to-rose-500 hover:from-purple-600 hover:to-rose-600 text-white px-8 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
          >
            View Complete Portfolio
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Gallery;