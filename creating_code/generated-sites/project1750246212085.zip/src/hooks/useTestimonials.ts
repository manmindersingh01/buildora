import { useState, useEffect } from 'react';
import axios from 'axios';
import { Testimonial } from '@/types';

export const useTestimonials = () => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTestimonials = async () => {
      try {
        setLoading(true);
        // Simulating API call with mock data
        const mockTestimonials: Testimonial[] = [
          {
            id: '1',
            name: 'Sarah Johnson',
            rating: 5,
            comment: 'Absolutely amazing! The Margherita pizza was perfect, just like in Italy. The crust was crispy and the ingredients were so fresh.',
            date: '2 weeks ago'
          },
          {
            id: '2',
            name: 'Mike Chen',
            rating: 5,
            comment: 'Best pizza delivery in town! Always hot, always on time. The BBQ chicken pizza is my favorite - highly recommend!',
            date: '1 month ago'
          },
          {
            id: '3',
            name: 'Emily Rodriguez',
            rating: 4,
            comment: 'Great family business with authentic flavors. The staff is friendly and the atmosphere is cozy. Will definitely come back!',
            date: '3 weeks ago'
          },
          {
            id: '4',
            name: 'David Thompson',
            rating: 5,
            comment: 'Outstanding quality and service. The Quattro Stagioni is a masterpiece. You can taste the quality in every bite.',
            date: '1 week ago'
          }
        ];
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 800));
        
        setTestimonials(mockTestimonials);
        setError(null);
      } catch (err) {
        setError('Failed to fetch testimonials');
        console.error('Error fetching testimonials:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchTestimonials();
  }, []);

  return { testimonials, loading, error };
};