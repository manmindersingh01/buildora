import React from 'react';
import { Todo } from '@/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Edit, Delete, Clock, Tag } from 'lucide-react';

interface TodoItemProps {
  todo: Todo;
  onToggleComplete: (id: string) => void;
  onEdit: (todo: Todo) => void;
  onDelete: (id: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({
  todo,
  onToggleComplete,
  onEdit,
  onDelete
}) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return '🔴';
      case 'medium': return '🟡';
      case 'low': return '🟢';
      default: return '⚪';
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card className={`p-4 transition-all duration-200 hover:shadow-md border-l-4 ${
      todo.completed 
        ? 'border-l-green-500 bg-green-50/50' 
        : 'border-l-blue-500 bg-white hover:bg-blue-50/30'
    }`}>
      <div className="flex items-start space-x-4">
        <div className="flex items-center pt-1">
          <Checkbox
            id={`todo-${todo.id}`}
            checked={todo.completed}
            onCheckedChange={() => onToggleComplete(todo.id)}
            className="data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500"
          />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className={`text-base font-medium transition-all ${
                todo.completed 
                  ? 'text-gray-500 line-through' 
                  : 'text-gray-900'
              }`}>
                {todo.title}
              </h3>
              
              {todo.description && (
                <p className={`text-sm mt-1 transition-all ${
                  todo.completed 
                    ? 'text-gray-400 line-through' 
                    : 'text-gray-600'
                }`}>
                  {todo.description}
                </p>
              )}
            </div>

            <div className="flex items-center space-x-2 ml-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onEdit(todo)}
                className="text-gray-500 hover:text-blue-600 hover:bg-blue-50"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onDelete(todo.id)}
                className="text-gray-500 hover:text-red-600 hover:bg-red-50"
              >
                <Delete className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between mt-3">
            <div className="flex items-center space-x-3">
              <Badge 
                variant="outline" 
                className={`text-xs ${getPriorityColor(todo.priority)}`}
              >
                <span className="mr-1">{getPriorityIcon(todo.priority)}</span>
                {todo.priority.charAt(0).toUpperCase() + todo.priority.slice(1)}
              </Badge>
              
              {todo.category && (
                <Badge variant="outline" className="text-xs bg-blue-50 text-blue-600 border-blue-200">
                  <Tag className="w-3 h-3 mr-1" />
                  {todo.category}
                </Badge>
              )}
            </div>

            <div className="flex items-center text-xs text-gray-400">
              <Clock className="w-3 h-3 mr-1" />
              <span>{formatDate(todo.createdAt)}</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};