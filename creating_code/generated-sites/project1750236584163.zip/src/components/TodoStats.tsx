import React from 'react';
import { TodoStats as TodoStatsType } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Circle, BarChart, Target } from 'lucide-react';

interface TodoStatsProps {
  stats: TodoStatsType;
}

export const TodoStats: React.FC<TodoStatsProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Total Tasks */}
      <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-600 mb-1">Total Tasks</p>
              <p className="text-3xl font-bold text-blue-900">{stats.total}</p>
            </div>
            <div className="bg-blue-500 p-3 rounded-full">
              <BarChart className="w-6 h-6 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Tasks */}
      <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-orange-600 mb-1">Active Tasks</p>
              <p className="text-3xl font-bold text-orange-900">{stats.active}</p>
            </div>
            <div className="bg-orange-500 p-3 rounded-full">
              <Circle className="w-6 h-6 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Completed Tasks */}
      <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-600 mb-1">Completed</p>
              <p className="text-3xl font-bold text-green-900">{stats.completed}</p>
            </div>
            <div className="bg-green-500 p-3 rounded-full">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Completion Rate */}
      <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-medium text-purple-600 mb-1">Completion Rate</p>
              <p className="text-3xl font-bold text-purple-900">
                {Math.round(stats.completionRate)}%
              </p>
            </div>
            <div className="bg-purple-500 p-3 rounded-full">
              <Target className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <Progress 
              value={stats.completionRate} 
              className="h-2 bg-purple-200"
            />
            <p className="text-xs text-purple-600">
              {stats.completed} of {stats.total} tasks completed
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};