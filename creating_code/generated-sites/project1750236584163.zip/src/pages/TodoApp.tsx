import React, { useState, useEffect } from 'react';
import { Todo, TodoFormData, TodoFilters, TodoStats } from '@/types';
import { TodoHeader } from '@/components/TodoHeader';
import { TodoForm } from '@/components/TodoForm';
import { TodoList } from '@/components/TodoList';
import { TodoFiltersBar } from '@/components/TodoFiltersBar';
import { TodoStats as TodoStatsComponent } from '@/components/TodoStats';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Plus } from 'lucide-react';

const TodoApp: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);
  const [filters, setFilters] = useState<TodoFilters>({
    status: 'all',
    priority: 'all',
    category: 'all'
  });

  // Load todos from localStorage on component mount
  useEffect(() => {
    const savedTodos = localStorage.getItem('todos');
    if (savedTodos) {
      const parsedTodos = JSON.parse(savedTodos).map((todo: any) => ({
        ...todo,
        createdAt: new Date(todo.createdAt),
        updatedAt: new Date(todo.updatedAt)
      }));
      setTodos(parsedTodos);
    }
  }, []);

  // Save todos to localStorage whenever todos change
  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = (formData: TodoFormData) => {
    const newTodo: Todo = {
      id: crypto.randomUUID(),
      ...formData,
      completed: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setTodos(prev => [newTodo, ...prev]);
    setShowForm(false);
  };

  const updateTodo = (id: string, updates: Partial<Todo>) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id 
        ? { ...todo, ...updates, updatedAt: new Date() }
        : todo
    ));
  };

  const deleteTodo = (id: string) => {
    setTodos(prev => prev.filter(todo => todo.id !== id));
  };

  const toggleComplete = (id: string) => {
    updateTodo(id, { 
      completed: !todos.find(t => t.id === id)?.completed 
    });
  };

  const editTodo = (formData: TodoFormData) => {
    if (editingTodo) {
      updateTodo(editingTodo.id, formData);
      setEditingTodo(null);
    }
  };

  const filteredTodos = todos.filter(todo => {
    if (filters.status === 'active' && todo.completed) return false;
    if (filters.status === 'completed' && !todo.completed) return false;
    if (filters.priority !== 'all' && todo.priority !== filters.priority) return false;
    if (filters.category !== 'all' && todo.category !== filters.category) return false;
    return true;
  });

  const stats: TodoStats = {
    total: todos.length,
    completed: todos.filter(t => t.completed).length,
    active: todos.filter(t => !t.completed).length,
    completionRate: todos.length > 0 ? (todos.filter(t => t.completed).length / todos.length) * 100 : 0
  };

  const categories = Array.from(new Set(todos.map(t => t.category).filter(Boolean)));

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <TodoHeader />
        
        <div className="mb-8">
          <TodoStatsComponent stats={stats} />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            {!showForm && !editingTodo && (
              <Card className="p-6 border-dashed border-2 border-gray-200 hover:border-blue-300 transition-colors">
                <Button 
                  onClick={() => setShowForm(true)}
                  className="w-full h-16 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold"
                  size="lg"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Add New Todo
                </Button>
              </Card>
            )}

            {(showForm || editingTodo) && (
              <TodoForm
                onSubmit={editingTodo ? editTodo : addTodo}
                onCancel={() => {
                  setShowForm(false);
                  setEditingTodo(null);
                }}
                initialData={editingTodo || undefined}
                categories={categories}
              />
            )}

            <TodoFiltersBar
              filters={filters}
              onFiltersChange={setFilters}
              categories={categories}
            />

            <TodoList
              todos={filteredTodos}
              onToggleComplete={toggleComplete}
              onEdit={setEditingTodo}
              onDelete={deleteTodo}
            />
          </div>

          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 text-gray-800">Quick Actions</h3>
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => setFilters({ ...filters, status: 'active' })}
                >
                  View Active Tasks
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => setFilters({ ...filters, status: 'completed' })}
                >
                  View Completed
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => setFilters({ status: 'all', priority: 'high', category: 'all' })}
                >
                  High Priority
                </Button>
              </div>
            </Card>

            {categories.length > 0 && (
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4 text-gray-800">Categories</h3>
                <div className="space-y-2">
                  {categories.map(category => (
                    <div 
                      key={category}
                      className="flex justify-between items-center p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                      onClick={() => setFilters({ ...filters, category })}
                    >
                      <span className="text-sm text-gray-600">{category}</span>
                      <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded-full">
                        {todos.filter(t => t.category === category).length}
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TodoApp;