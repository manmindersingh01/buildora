import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  MapPin, Phone, Mail, Wifi, Car, Coffee, Utensils, 
  Star, Calendar, Users, ArrowRight, Mountain, Trees, 
  CheckCircle, Quote, Camera, Sunset 
} from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Room, Review, Amenity } from '@/types';
import axios from 'axios';

const Home: React.FC = () => {
  const [featuredRooms, setFeaturedRooms] = useState<Room[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [amenities, setAmenities] = useState<Amenity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHomeData();
  }, []);

  const fetchHomeData = async () => {
    try {
      setLoading(true);
      
      // Mock data for featured rooms
      const roomsData: Room[] = [
        {
          id: '1',
          name: 'Mountain View Deluxe',
          type: 'Deluxe Room',
          capacity: 2,
          price: 3500,
          images: ['/api/placeholder/400/300'],
          amenities: ['Free WiFi', 'Mountain View', 'Private Balcony', 'Room Service'],
          description: 'Spacious room with stunning Parvati Valley views',
          available: true
        },
        {
          id: '2',
          name: 'Riverside Cottage',
          type: 'Cottage',
          capacity: 4,
          price: 5500,
          images: ['/api/placeholder/400/300'],
          amenities: ['River View', 'Fireplace', 'Kitchen', 'Garden Access'],
          description: 'Cozy cottage by the Parvati River with modern amenities',
          available: true
        },
        {
          id: '3',
          name: 'Himalayan Suite',
          type: 'Suite',
          capacity: 3,
          price: 7500,
          images: ['/api/placeholder/400/300'],
          amenities: ['Panoramic Views', 'Jacuzzi', 'Living Room', 'Terrace'],
          description: 'Luxury suite with breathtaking Himalayan panorama',
          available: true
        }
      ];

      // Mock data for reviews
      const reviewsData: Review[] = [
        {
          id: '1',
          name: 'Priya Sharma',
          rating: 5,
          comment: 'Absolutely magical stay! The mountain views from our room were breathtaking. Perfect place to disconnect and rejuvenate.',
          date: '2024-01-15'
        },
        {
          id: '2',
          name: 'Raj Kumar',
          rating: 5,
          comment: 'Excellent hospitality and serene location. The staff went above and beyond to make our honeymoon special.',
          date: '2024-01-10'
        },
        {
          id: '3',
          name: 'Sarah Johnson',
          rating: 4,
          comment: 'Beautiful property with great amenities. The riverside cottage was perfect for our family vacation.',
          date: '2024-01-08'
        }
      ];

      // Mock data for amenities
      const amenitiesData: Amenity[] = [
        { id: '1', name: 'Free WiFi', icon: 'Wifi', description: 'High-speed internet throughout the property' },
        { id: '2', name: 'Mountain Views', icon: 'Mountain', description: 'Stunning panoramic views of the Himalayas' },
        { id: '3', name: 'Restaurant', icon: 'Utensils', description: 'Multi-cuisine restaurant with local specialties' },
        { id: '4', name: 'Parking', icon: 'Car', description: 'Free parking for all guests' },
        { id: '5', name: 'Coffee Shop', icon: 'Coffee', description: '24/7 coffee and refreshments' },
        { id: '6', name: 'Garden', icon: 'Trees', description: 'Beautiful landscaped gardens to relax' }
      ];

      setFeaturedRooms(roomsData);
      setReviews(reviewsData);
      setAmenities(amenitiesData);
    } catch (error) {
      console.error('Error fetching home data:', error);
    } finally {
      setLoading(false);
    }
  };

  const IconComponent = ({ iconName }: { iconName: string }) => {
    const icons: any = { Wifi, Mountain, Utensils, Car, Coffee, Trees };
    const Icon = icons[iconName] || CheckCircle;
    return <Icon className="h-6 w-6" />;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-teal-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-emerald-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your mountain escape...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/90 to-teal-800/80 z-10"></div>
        <div className="absolute inset-0 bg-[url('/api/placeholder/1920/1080')] bg-cover bg-center"></div>
        <div className="relative z-20 container mx-auto px-4 py-32 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Himalayan Retreat
              <span className="block text-emerald-300 text-3xl md:text-4xl font-light mt-2">
                Kasol, Himachal Pradesh
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-emerald-100 mb-8 leading-relaxed">
              Experience tranquility amidst the majestic Parvati Valley
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-full text-lg">
                Book Your Stay <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-3 rounded-full text-lg">
                <Camera className="mr-2 h-5 w-5" /> Virtual Tour
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-emerald-50 to-transparent z-20"></div>
      </section>

      {/* Quick Info */}
      <section className="py-12 bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex items-center justify-center space-x-3">
              <MapPin className="h-8 w-8 text-emerald-600" />
              <div>
                <h3 className="font-semibold text-gray-900">Prime Location</h3>
                <p className="text-gray-600">Heart of Kasol Valley</p>
              </div>
            </div>
            <div className="flex items-center justify-center space-x-3">
              <Mountain className="h-8 w-8 text-emerald-600" />
              <div>
                <h3 className="font-semibold text-gray-900">Mountain Views</h3>
                <p className="text-gray-600">360° Himalayan Panorama</p>
              </div>
            </div>
            <div className="flex items-center justify-center space-x-3">
              <Star className="h-8 w-8 text-emerald-600" />
              <div>
                <h3 className="font-semibold text-gray-900">5-Star Service</h3>
                <p className="text-gray-600">Exceptional Hospitality</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Rooms */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Luxury Accommodations
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Choose from our carefully designed rooms and cottages, each offering unique views and premium amenities
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredRooms.length > 0 && featuredRooms.map((room) => (
              <Card key={room.id} className="group overflow-hidden border-0 shadow-xl hover:shadow-2xl transition-all duration-500 bg-white/90 backdrop-blur-sm">
                <div className="relative overflow-hidden">
                  <img 
                    src={room.images[0]} 
                    alt={room.name}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-emerald-600 text-white">{room.type}</Badge>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-2xl font-bold text-gray-900">{room.name}</h3>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-emerald-600">₹{room.price.toLocaleString()}</p>
                      <p className="text-sm text-gray-500">per night</p>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4">{room.description}</p>
                  <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Users className="h-4 w-4" /> {room.capacity} guests
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {room.amenities.slice(0, 3).map((amenity, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {amenity}
                      </Badge>
                    ))}
                  </div>
                  <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                    Book Now <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Amenities */}
      <section className="py-20 bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">World-Class Amenities</h2>
            <p className="text-xl text-emerald-100 max-w-2xl mx-auto">
              Everything you need for a perfect mountain getaway
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {amenities.length > 0 && amenities.map((amenity) => (
              <div key={amenity.id} className="text-center group">
                <div className="bg-white/10 backdrop-blur-sm rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 group-hover:bg-white/20 transition-colors duration-300">
                  <IconComponent iconName={amenity.icon} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{amenity.name}</h3>
                <p className="text-emerald-100">{amenity.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Your Gateway to Himalayan Serenity
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Nestled in the heart of Kasol, our hotel offers an unparalleled experience of mountain hospitality. 
                Wake up to the melodious sounds of the Parvati River and breathtaking views of snow-capped peaks.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Whether you're seeking adventure in the nearby trekking trails or simply want to unwind in nature's embrace, 
                our property provides the perfect base for your Himalayan adventure.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-emerald-600 mb-2">15+</div>
                  <div className="text-gray-600">Luxury Rooms</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-emerald-600 mb-2">500+</div>
                  <div className="text-gray-600">Happy Guests</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-2xl transform rotate-3"></div>
              <img 
                src="/api/placeholder/600/400" 
                alt="Hotel exterior" 
                className="relative rounded-2xl shadow-2xl w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Guest Experiences
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Hear what our guests say about their unforgettable stays
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {reviews.length > 0 && reviews.map((review) => (
              <Card key={review.id} className="bg-white border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-400 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-5 w-5 ${i < review.rating ? 'fill-current' : ''}`} 
                        />
                      ))}
                    </div>
                  </div>
                  <Quote className="h-8 w-8 text-emerald-600 mb-4" />
                  <p className="text-gray-600 mb-4 italic leading-relaxed">
                    "{review.comment}"
                  </p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                      {review.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{review.name}</p>
                      <p className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-emerald-800 to-teal-800 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready for Your Mountain Escape?
            </h2>
            <p className="text-xl text-emerald-100 mb-8">
              Book your stay today and discover the magic of Kasol. Limited rooms available for the peak season.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-emerald-800 hover:bg-emerald-50 px-8 py-3 rounded-full text-lg font-semibold">
                <Calendar className="mr-2 h-5 w-5" /> Check Availability
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-3 rounded-full text-lg">
                <Phone className="mr-2 h-5 w-5" /> Call Now: +91 98765 43210
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1200 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1200 120L0 16.48V0h1200v120z" fill="rgb(236 253 245)" />
          </svg>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;