import React, { useState, useEffect, useMemo } from 'react';
import { TodoHeader } from '@/components/TodoHeader';
import { TodoForm } from '@/components/TodoForm';
import { TodoList } from '@/components/TodoList';
import { TodoFilters } from '@/components/TodoFilters';
import { TodoStats } from '@/components/TodoStats';
import { useTodos } from '@/hooks/useTodos';
import type { TodoFilter } from '@/types';

export default function TodoApp() {
  const { todos, loading, error, addTodo, updateTodo, deleteTodo } = useTodos();
  const [filter, setFilter] = useState<TodoFilter>({
    status: 'all',
    priority: 'all',
    searchTerm: ''
  });

  const filteredTodos = useMemo(() => {
    if (!todos || todos.length === 0) return [];
    
    return todos.filter(todo => {
      // Status filter
      if (filter.status === 'active' && todo.completed) return false;
      if (filter.status === 'completed' && !todo.completed) return false;
      
      // Priority filter
      if (filter.priority !== 'all' && todo.priority !== filter.priority) return false;
      
      // Search filter
      if (filter.searchTerm) {
        const searchLower = filter.searchTerm.toLowerCase();
        return (
          todo.title.toLowerCase().includes(searchLower) ||
          (todo.description && todo.description.toLowerCase().includes(searchLower))
        );
      }
      
      return true;
    });
  }, [todos, filter]);

  const stats = useMemo(() => {
    if (!todos || todos.length === 0) {
      return { total: 0, completed: 0, active: 0, overdue: 0 };
    }
    
    const now = new Date();
    return {
      total: todos.length,
      completed: todos.filter(t => t.completed).length,
      active: todos.filter(t => !t.completed).length,
      overdue: todos.filter(t => !t.completed && t.dueDate && new Date(t.dueDate) < now).length
    };
  }, [todos]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <TodoHeader />
      
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Stats Overview */}
        <TodoStats stats={stats} />
        
        {/* Add Todo Form */}
        <div className="mb-8">
          <TodoForm onAddTodo={addTodo} />
        </div>
        
        {/* Filters */}
        <div className="mb-6">
          <TodoFilters filter={filter} onFilterChange={setFilter} />
        </div>
        
        {/* Todo List */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
            <p className="text-sm">Error loading todos: {error}</p>
          </div>
        )}
        
        <TodoList
          todos={filteredTodos}
          loading={loading}
          onUpdateTodo={updateTodo}
          onDeleteTodo={deleteTodo}
        />
      </main>
    </div>
  );
}