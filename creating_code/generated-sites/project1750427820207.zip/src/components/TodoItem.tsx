import React, { useState } from 'react';
import { Check, X, Edit, Delete, Calendar, Flag, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import type { Todo } from '@/types';
import { cn } from '@/lib/utils';

interface TodoItemProps {
  todo: Todo;
  onUpdate: (id: string, updates: Partial<Todo>) => void;
  onDelete: (id: string) => void;
}

export function TodoItem({ todo, onUpdate, onDelete }: TodoItemProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(todo.title);

  const handleSave = () => {
    if (editTitle.trim() && editTitle !== todo.title) {
      onUpdate(todo.id, { title: editTitle.trim() });
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditTitle(todo.title);
    setIsEditing(false);
  };

  const priorityStyles = {
    low: 'border-l-green-500 bg-green-50/50',
    medium: 'border-l-yellow-500 bg-yellow-50/50',
    high: 'border-l-red-500 bg-red-50/50'
  };

  const priorityBadgeStyles = {
    low: 'text-green-600 bg-green-100',
    medium: 'text-yellow-600 bg-yellow-100',
    high: 'text-red-600 bg-red-100'
  };

  const isOverdue = todo.dueDate && new Date(todo.dueDate) < new Date() && !todo.completed;

  return (
    <div
      className={cn(
        'bg-white rounded-lg shadow-sm border border-gray-200 p-4 transition-all duration-200 hover:shadow-md border-l-4',
        priorityStyles[todo.priority],
        todo.completed && 'opacity-75'
      )}
    >
      <div className="flex items-start gap-3">
        <Checkbox
          checked={todo.completed}
          onCheckedChange={(checked) => onUpdate(todo.id, { completed: !!checked })}
          className="mt-1"
        />

        <div className="flex-1 min-w-0">
          {isEditing ? (
            <div className="flex gap-2">
              <Input
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSave();
                  if (e.key === 'Escape') handleCancel();
                }}
                className="flex-1"
                autoFocus
              />
              <Button size="sm" onClick={handleSave} variant="ghost">
                <Check className="h-4 w-4" />
              </Button>
              <Button size="sm" onClick={handleCancel} variant="ghost">
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div>
              <h3
                className={cn(
                  'text-lg font-medium text-gray-900 mb-1',
                  todo.completed && 'line-through text-gray-500'
                )}
              >
                {todo.title}
              </h3>
              {todo.description && (
                <p className={cn('text-sm text-gray-600', todo.completed && 'text-gray-400')}>
                  {todo.description}
                </p>
              )}
              
              <div className="flex items-center gap-4 mt-2">
                <span className={cn('inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded', priorityBadgeStyles[todo.priority])}>
                  <Flag className="h-3 w-3" />
                  {todo.priority.charAt(0).toUpperCase() + todo.priority.slice(1)}
                </span>
                
                {todo.dueDate && (
                  <span className={cn(
                    'inline-flex items-center gap-1 text-xs',
                    isOverdue ? 'text-red-600' : 'text-gray-500'
                  )}>
                    <Calendar className="h-3 w-3" />
                    {new Date(todo.dueDate).toLocaleDateString()}
                  </span>
                )}
                
                <span className="inline-flex items-center gap-1 text-xs text-gray-400">
                  <Clock className="h-3 w-3" />
                  {new Date(todo.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          )}
        </div>

        {!isEditing && (
          <div className="flex items-center gap-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsEditing(true)}
              className="text-gray-500 hover:text-gray-700"
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onDelete(todo.id)}
              className="text-gray-500 hover:text-red-600"
            >
              <Delete className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}