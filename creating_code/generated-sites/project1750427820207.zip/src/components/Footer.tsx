import React from 'react';
import { 
  Mountain, Phone, Mail, MapPin, 
  Facebook, Instagram, Twitter, 
  ArrowRight, Heart, Star,
  Wifi, Car, Coffee, Utensils
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';

export const Footer: React.FC = () => {
  const quickLinks = [
    { name: 'Rooms & Suites', href: '/rooms' },
    { name: 'Dining', href: '/dining' },
    { name: 'Activities', href: '/activities' },
    { name: 'Gallery', href: '/gallery' },
    { name: 'Reviews', href: '/reviews' }
  ];

  const amenities = [
    { name: 'Free WiFi', icon: Wifi },
    { name: 'Parking', icon: Car },
    { name: 'Restaurant', icon: Utensils },
    { name: 'Coffee Shop', icon: Coffee }
  ];

  return (
    <footer className="bg-gradient-to-r from-gray-900 to-gray-800 text-white">
      {/* Newsletter Section */}
      <div className="border-b border-gray-700">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Stay Updated with Our Mountain Stories
            </h3>
            <p className="text-gray-300 mb-8 text-lg">
              Get exclusive offers, travel tips, and updates from the heart of Himalayas
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input 
                type="email" 
                placeholder="Enter your email" 
                className="bg-white/10 border-gray-600 text-white placeholder:text-gray-400 flex-1"
              />
              <Button className="bg-emerald-600 hover:bg-emerald-700 text-white px-6">
                Subscribe <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Hotel Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-2 rounded-full">
                <Mountain className="h-8 w-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
                  Himalayan Retreat
                </h2>
                <p className="text-sm text-gray-400">Kasol, Himachal Pradesh</p>
              </div>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Your gateway to Himalayan serenity. Experience luxury hospitality 
              amidst the breathtaking beauty of Parvati Valley.
            </p>
            <div className="flex items-center space-x-2 text-yellow-400 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-current" />
              ))}
              <span className="text-gray-300 ml-2">4.9/5 Guest Rating</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold mb-6 text-emerald-400">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="text-gray-300 hover:text-emerald-400 transition-colors duration-200 flex items-center group"
                  >
                    <ArrowRight className="h-4 w-4 mr-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-semibold mb-6 text-emerald-400">Contact Us</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-emerald-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">Near Parvati River</p>
                  <p className="text-gray-300">Kasol, Parvati Valley</p>
                  <p className="text-gray-300">Himachal Pradesh 175105</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-emerald-400" />
                <div>
                  <p className="text-gray-300">+91 98765 43210</p>
                  <p className="text-sm text-gray-400">24/7 Reception</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-emerald-400" />
                <div>
                  <p className="text-gray-300">info@himalayan-retreat.com</p>
                  <p className="text-sm text-gray-400">bookings@himalayan-retreat.com</p>
                </div>
              </div>
            </div>
          </div>

          {/* Amenities & Social */}
          <div>
            <h3 className="text-xl font-semibold mb-6 text-emerald-400">Amenities</h3>
            <div className="grid grid-cols-2 gap-3 mb-8">
              {amenities.map((amenity) => {
                const IconComponent = amenity.icon;
                return (
                  <div key={amenity.name} className="flex items-center space-x-2 text-gray-300">
                    <IconComponent className="h-4 w-4 text-emerald-400" />
                    <span className="text-sm">{amenity.name}</span>
                  </div>
                );
              })}
            </div>
            
            <h4 className="text-lg font-semibold mb-4 text-emerald-400">Follow Us</h4>
            <div className="flex space-x-4">
              <a href="#" className="bg-white/10 hover:bg-emerald-600 p-3 rounded-full transition-colors duration-300 group">
                <Facebook className="h-5 w-5 text-white" />
              </a>
              <a href="#" className="bg-white/10 hover:bg-emerald-600 p-3 rounded-full transition-colors duration-300 group">
                <Instagram className="h-5 w-5 text-white" />
              </a>
              <a href="#" className="bg-white/10 hover:bg-emerald-600 p-3 rounded-full transition-colors duration-300 group">
                <Twitter className="h-5 w-5 text-white" />
              </a>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Bottom Footer */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex items-center space-x-2 text-gray-400">
            <span>© 2024 Himalayan Retreat. All rights reserved.</span>
            <span className="flex items-center space-x-1">
              <span>Made with</span>
              <Heart className="h-4 w-4 text-red-500 fill-current" />
              <span>in the Himalayas</span>
            </span>
          </div>
          <div className="flex space-x-6 text-sm">
            <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors duration-200">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors duration-200">
              Terms & Conditions
            </a>
            <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors duration-200">
              Cancellation Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};