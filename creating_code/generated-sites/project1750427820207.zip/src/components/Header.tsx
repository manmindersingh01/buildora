import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Menu, X, Phone, Mail, MapPin, Calendar,
  Mountain, Home as HomeIcon
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigation = [
    { name: 'Home', href: '/', icon: HomeIcon },
    { name: 'Rooms', href: '/rooms', icon: Mountain },
    { name: 'Dining', href: '/dining', icon: Calendar },
    { name: 'Activities', href: '/activities', icon: MapPin },
    { name: 'Contact', href: '/contact', icon: Phone }
  ];

  return (
    <header className="bg-white/95 backdrop-blur-md shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-2 rounded-full group-hover:scale-110 transition-transform duration-300">
              <Mountain className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                Himalayan Retreat
              </h1>
              <p className="text-sm text-gray-500 -mt-1">Kasol, Himachal Pradesh</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navigation.map((item) => {
              const IconComponent = item.icon;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className="flex items-center space-x-2 text-gray-700 hover:text-emerald-600 font-medium transition-colors duration-200 group"
                >
                  <IconComponent className="h-4 w-4 group-hover:scale-110 transition-transform duration-200" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* Contact Info & CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="text-right">
              <div className="flex items-center text-sm text-gray-600 mb-1">
                <Phone className="h-3 w-3 mr-1" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Mail className="h-3 w-3 mr-1" />
                <span>info@himalayan-retreat.com</span>
              </div>
            </div>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-full">
              <Calendar className="mr-2 h-4 w-4" />
              Book Now
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-gray-700" />
            ) : (
              <Menu className="h-6 w-6 text-gray-700" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 py-4">
            <nav className="flex flex-col space-y-4">
              {navigation.map((item) => {
                const IconComponent = item.icon;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center space-x-3 text-gray-700 hover:text-emerald-600 font-medium transition-colors duration-200 py-2"
                  >
                    <IconComponent className="h-5 w-5" />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </nav>
            
            {/* Mobile Contact & CTA */}
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <Phone className="h-4 w-4 mr-2" />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Mail className="h-4 w-4 mr-2" />
                  <span>info@himalayan-retreat.com</span>
                </div>
              </div>
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white rounded-full">
                <Calendar className="mr-2 h-4 w-4" />
                Book Your Stay
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};