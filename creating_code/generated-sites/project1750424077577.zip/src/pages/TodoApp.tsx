import React, { useState, useEffect, useMemo } from 'react';
import { Todo, TodoFilter, TodoStats } from '@/types';
import { TodoHeader } from '@/components/TodoHeader';
import { TodoForm } from '@/components/TodoForm';
import { TodoList } from '@/components/TodoList';
import { TodoFilters } from '@/components/TodoFilters';
import { TodoStats as StatsComponent } from '@/components/TodoStats';
import { useTodos } from '@/hooks/useTodos';
import { Loader } from 'lucide-react';

export const TodoApp: React.FC = () => {
  const { todos, loading, error, addTodo, updateTodo, deleteTodo, refetch } = useTodos();
  const [filter, setFilter] = useState<TodoFilter>({
    status: 'all',
    priority: 'all',
    searchTerm: ''
  });

  const filteredTodos = useMemo(() => {
    if (!todos || todos.length === 0) return [];
    
    return todos.filter(todo => {
      // Status filter
      if (filter.status === 'active' && todo.completed) return false;
      if (filter.status === 'completed' && !todo.completed) return false;
      
      // Priority filter
      if (filter.priority !== 'all' && todo.priority !== filter.priority) return false;
      
      // Search filter
      if (filter.searchTerm && !todo.title.toLowerCase().includes(filter.searchTerm.toLowerCase())) {
        return false;
      }
      
      return true;
    });
  }, [todos, filter]);

  const stats: TodoStats = useMemo(() => {
    if (!todos || todos.length === 0) {
      return { total: 0, completed: 0, active: 0, overdue: 0 };
    }
    
    const now = new Date();
    return {
      total: todos.length,
      completed: todos.filter(t => t.completed).length,
      active: todos.filter(t => !t.completed).length,
      overdue: todos.filter(t => {
        if (t.completed || !t.dueDate) return false;
        return new Date(t.dueDate) < now;
      }).length
    };
  }, [todos]);

  if (loading && todos.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
        <div className="flex items-center gap-2 text-purple-600">
          <Loader className="animate-spin" />
          <span>Loading todos...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <TodoHeader />
        
        <div className="grid gap-6 mt-8">
          <StatsComponent stats={stats} />
          <TodoForm onAddTodo={addTodo} />
          <TodoFilters filter={filter} onFilterChange={setFilter} />
          
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              Error: {error}
            </div>
          )}
          
          <TodoList
            todos={filteredTodos}
            onUpdateTodo={updateTodo}
            onDeleteTodo={deleteTodo}
            loading={loading}
          />
        </div>
      </div>
    </div>
  );
};