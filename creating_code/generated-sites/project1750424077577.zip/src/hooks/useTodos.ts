import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { Todo } from '@/types';

export const useTodos = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Simulated API calls - replace with actual API endpoints
  const API_BASE_URL = '/api/todos';

  const fetchTodos = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Simulated API response
      const mockTodos: Todo[] = [
        {
          id: '1',
          title: 'Complete project documentation',
          description: 'Write comprehensive documentation for the new feature',
          completed: false,
          priority: 'high',
          dueDate: new Date(Date.now() + 86400000).toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: '2',
          title: 'Review pull requests',
          description: 'Check and approve pending PRs from the team',
          completed: true,
          priority: 'medium',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: '3',
          title: 'Team meeting preparation',
          completed: false,
          priority: 'low',
          dueDate: new Date(Date.now() - 86400000).toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      setTodos(mockTodos);
      
      // Actual API call would be:
      // const response = await axios.get(API_BASE_URL);
      // if (response.data.success) {
      //   setTodos(response.data.data);
      // }
    } catch (err) {
      setError('Failed to fetch todos');
      console.error('Error fetching todos:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const addTodo = useCallback(async (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    setLoading(true);
    try {
      const newTodo: Todo = {
        ...todoData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 300));
      setTodos(prev => [newTodo, ...prev]);
      
      // Actual API call would be:
      // const response = await axios.post(API_BASE_URL, todoData);
      // if (response.data.success) {
      //   setTodos(prev => [response.data.data, ...prev]);
      // }
    } catch (err) {
      setError('Failed to add todo');
      console.error('Error adding todo:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const updateTodo = useCallback(async (id: string, updates: Partial<Todo>) => {
    setLoading(true);
    try {
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 300));
      setTodos(prev => prev.map(todo => 
        todo.id === id 
          ? { ...todo, ...updates, updatedAt: new Date().toISOString() }
          : todo
      ));
      
      // Actual API call would be:
      // const response = await axios.patch(`${API_BASE_URL}/${id}`, updates);
      // if (response.data.success) {
      //   setTodos(prev => prev.map(todo => 
      //     todo.id === id ? response.data.data : todo
      //   ));
      // }
    } catch (err) {
      setError('Failed to update todo');
      console.error('Error updating todo:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteTodo = useCallback(async (id: string) => {
    setLoading(true);
    try {
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 300));
      setTodos(prev => prev.filter(todo => todo.id !== id));
      
      // Actual API call would be:
      // await axios.delete(`${API_BASE_URL}/${id}`);
      // setTodos(prev => prev.filter(todo => todo.id !== id));
    } catch (err) {
      setError('Failed to delete todo');
      console.error('Error deleting todo:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTodos();
  }, [fetchTodos]);

  return {
    todos,
    loading,
    error,
    addTodo,
    updateTodo,
    deleteTodo,
    refetch: fetchTodos
  };
};