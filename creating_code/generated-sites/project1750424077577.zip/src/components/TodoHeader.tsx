import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';

export const TodoHeader: React.FC = () => {
  return (
    <header className="text-center">
      <div className="flex items-center justify-center gap-3 mb-4">
        <div className="bg-gradient-to-br from-purple-600 to-blue-600 p-3 rounded-2xl shadow-lg">
          <CheckCircle className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          TaskMaster Pro
        </h1>
      </div>
      <p className="text-gray-600 flex items-center justify-center gap-2">
        <Calendar className="w-4 h-4" />
        Organize your life, one task at a time
      </p>
    </header>
  );
};