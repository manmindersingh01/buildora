import React from 'react';
import { Todo } from '@/types';
import { TodoItem } from '@/components/TodoItem';
import { Card } from '@/components/ui/card';
import { CheckCircle, Loader } from 'lucide-react';

interface TodoListProps {
  todos: Todo[];
  onUpdateTodo: (id: string, updates: Partial<Todo>) => void;
  onDeleteTodo: (id: string) => void;
  loading: boolean;
}

export const TodoList: React.FC<TodoListProps> = ({ todos, onUpdateTodo, onDeleteTodo, loading }) => {
  if (loading && todos.length === 0) {
    return (
      <Card className="p-12 text-center border-0 bg-white/80 backdrop-blur-sm">
        <Loader className="w-8 h-8 animate-spin mx-auto text-purple-600" />
        <p className="mt-2 text-gray-600">Loading your tasks...</p>
      </Card>
    );
  }

  if (!todos || todos.length === 0) {
    return (
      <Card className="p-12 text-center border-0 bg-white/80 backdrop-blur-sm">
        <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
        <h3 className="text-lg font-medium text-gray-600">No tasks found</h3>
        <p className="text-sm text-gray-500 mt-1">Start by adding a new task above</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onUpdate={onUpdateTodo}
          onDelete={onDeleteTodo}
        />
      ))}
    </div>
  );
};