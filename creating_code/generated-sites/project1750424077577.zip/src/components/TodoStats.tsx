import React from 'react';
import { TodoStats as Stats } from '@/types';
import { Card } from '@/components/ui/card';
import { CheckCircle, Clock, AlertTriangle, LayoutList } from 'lucide-react';

interface TodoStatsProps {
  stats: Stats;
}

export const TodoStats: React.FC<TodoStatsProps> = ({ stats }) => {
  const statCards = [
    {
      icon: LayoutList,
      label: 'Total Tasks',
      value: stats.total,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      icon: Clock,
      label: 'Active',
      value: stats.active,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      icon: CheckCircle,
      label: 'Completed',
      value: stats.completed,
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50'
    },
    {
      icon: AlertTriangle,
      label: 'Overdue',
      value: stats.overdue,
      color: 'from-red-500 to-red-600',
      bgColor: 'bg-red-50'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card key={index} className="p-4 border-0 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <Icon className={`w-5 h-5 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
};