import React from 'react';
import { TodoFilter } from '@/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter } from 'lucide-react';

interface TodoFiltersProps {
  filter: TodoFilter;
  onFilterChange: (filter: TodoFilter) => void;
}

export const TodoFilters: React.FC<TodoFiltersProps> = ({ filter, onFilterChange }) => {
  const statusButtons = [
    { value: 'all', label: 'All Tasks' },
    { value: 'active', label: 'Active' },
    { value: 'completed', label: 'Completed' }
  ];

  return (
    <Card className="p-4 border-0 bg-white/80 backdrop-blur-sm">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex gap-2 flex-1">
          {statusButtons.map((btn) => (
            <Button
              key={btn.value}
              variant={filter.status === btn.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => onFilterChange({ ...filter, status: btn.value as TodoFilter['status'] })}
              className={filter.status === btn.value 
                ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white border-0' 
                : 'border-gray-200 hover:border-purple-300'}
            >
              {btn.label}
            </Button>
          ))}
        </div>
        
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search tasks..."
              value={filter.searchTerm || ''}
              onChange={(e) => onFilterChange({ ...filter, searchTerm: e.target.value })}
              className="pl-9 w-full md:w-[200px] border-gray-200 focus:border-purple-400 focus:ring-purple-400"
            />
          </div>
          
          <Select
            value={filter.priority || 'all'}
            onValueChange={(value) => onFilterChange({ ...filter, priority: value as TodoFilter['priority'] })}
          >
            <SelectTrigger className="w-[140px] border-gray-200">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4" />
                <SelectValue placeholder="Priority" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="high">High Priority</SelectItem>
              <SelectItem value="medium">Medium Priority</SelectItem>
              <SelectItem value="low">Low Priority</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </Card>
  );
};