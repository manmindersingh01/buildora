import React, { useState } from 'react';
import { Todo } from '@/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Edit, Delete, Save, X, Calendar, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TodoItemProps {
  todo: Todo;
  onUpdate: (id: string, updates: Partial<Todo>) => void;
  onDelete: (id: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(todo.title);
  const [editedDescription, setEditedDescription] = useState(todo.description || '');

  const isOverdue = todo.dueDate && !todo.completed && new Date(todo.dueDate) < new Date();

  const handleSave = () => {
    if (editedTitle.trim()) {
      onUpdate(todo.id, {
        title: editedTitle.trim(),
        description: editedDescription.trim() || undefined
      });
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditedTitle(todo.title);
    setEditedDescription(todo.description || '');
    setIsEditing(false);
  };

  const priorityColors = {
    low: 'bg-green-100 text-green-800 border-green-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    high: 'bg-red-100 text-red-800 border-red-200'
  };

  return (
    <Card className={cn(
      "p-4 transition-all duration-200 border-0 bg-white/80 backdrop-blur-sm",
      todo.completed && "opacity-60",
      isOverdue && "border-l-4 border-l-red-500"
    )}>
      <div className="flex items-start gap-3">
        <Checkbox
          checked={todo.completed}
          onCheckedChange={(checked) => onUpdate(todo.id, { completed: !!checked })}
          className="mt-1 data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
        />
        
        <div className="flex-1 space-y-2">
          {isEditing ? (
            <>
              <Input
                value={editedTitle}
                onChange={(e) => setEditedTitle(e.target.value)}
                className="font-medium border-gray-200"
                autoFocus
              />
              <Textarea
                value={editedDescription}
                onChange={(e) => setEditedDescription(e.target.value)}
                placeholder="Add description..."
                className="min-h-[60px] border-gray-200"
              />
            </>
          ) : (
            <>
              <h3 className={cn(
                "font-medium text-gray-800",
                todo.completed && "line-through text-gray-500"
              )}>
                {todo.title}
              </h3>
              {todo.description && (
                <p className="text-sm text-gray-600">{todo.description}</p>
              )}
            </>
          )}
          
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={cn("text-xs", priorityColors[todo.priority])}>
              {todo.priority} priority
            </Badge>
            
            {todo.dueDate && (
              <Badge variant="outline" className={cn(
                "text-xs flex items-center gap-1",
                isOverdue && "border-red-500 text-red-600"
              )}>
                {isOverdue && <AlertCircle className="w-3 h-3" />}
                <Calendar className="w-3 h-3" />
                {new Date(todo.dueDate).toLocaleDateString()}
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-1">
          {isEditing ? (
            <>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleSave}
                className="h-8 w-8 p-0 text-green-600 hover:text-green-700 hover:bg-green-50"
              >
                <Save className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleCancel}
                className="h-8 w-8 p-0 text-gray-600 hover:text-gray-700"
              >
                <X className="w-4 h-4" />
              </Button>
            </>
          ) : (
            <>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setIsEditing(true)}
                className="h-8 w-8 p-0 text-gray-600 hover:text-gray-700"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onDelete(todo.id)}
                className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <Delete className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
      </div>
    </Card>
  );
};