export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string;
  image: string;
  features: string[];
}

export interface Testimonial {
  id: string;
  name: string;
  rating: number;
  comment: string;
  image: string;
  weddingDate: string;
}

export interface GalleryImage {
  id: string;
  url: string;
  alt: string;
  category: 'bridal' | 'engagement' | 'reception' | 'traditional';
}

export interface BookingForm {
  name: string;
  email: string;
  phone: string;
  weddingDate: string;
  service: string;
  message: string;
}

export interface ContactInfo {
  address: string;
  phone: string;
  email: string;
  hours: string;
}