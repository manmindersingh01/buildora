import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Heart, Calendar, Phone, Mail, MapPin, Clock, Check, ArrowRight } from 'lucide-react';
import { Service, Testimonial, GalleryImage } from '@/types';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { BookingModal } from '@/components/BookingModal';
import axios from 'axios';

const Home = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [gallery, setGallery] = useState<GalleryImage[]>([]);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Mock data - replace with actual API calls
      const mockServices: Service[] = [
        {
          id: '1',
          name: 'Complete Bridal Package',
          description: 'Full bridal makeup with trial, including hair styling and accessories',
          price: 25000,
          duration: '4-5 hours',
          image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=500',
          features: ['Pre-wedding trial', 'HD makeup', 'Hair styling', 'Accessories', 'Touch-up kit']
        },
        {
          id: '2',
          name: 'Engagement Makeup',
          description: 'Elegant makeup for your special engagement ceremony',
          price: 15000,
          duration: '2-3 hours',
          image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=500',
          features: ['Professional makeup', 'Basic hair styling', 'Consultation']
        },
        {
          id: '3',
          name: 'Reception Glam',
          description: 'Glamorous evening look for your wedding reception',
          price: 18000,
          duration: '3 hours',
          image: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=500',
          features: ['Evening makeup', 'Hair styling', 'False lashes', 'Setting spray']
        }
      ];

      const mockTestimonials: Testimonial[] = [
        {
          id: '1',
          name: 'Priya Sharma',
          rating: 5,
          comment: 'Absolutely stunning work! Made me feel like a princess on my wedding day.',
          image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100',
          weddingDate: '2024-02-15'
        },
        {
          id: '2',
          name: 'Anisha Patel',
          rating: 5,
          comment: 'Professional service and amazing results. Highly recommended!',
          image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
          weddingDate: '2024-01-20'
        }
      ];

      const mockGallery: GalleryImage[] = [
        {
          id: '1',
          url: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400',
          alt: 'Bridal makeup look 1',
          category: 'bridal'
        },
        {
          id: '2',
          url: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=400',
          alt: 'Engagement makeup',
          category: 'engagement'
        },
        {
          id: '3',
          url: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400',
          alt: 'Reception glam look',
          category: 'reception'
        },
        {
          id: '4',
          url: 'https://images.unsplash.com/photo-1524863479829-916d8e77f114?w=400',
          alt: 'Traditional bridal look',
          category: 'traditional'
        }
      ];

      setServices(mockServices);
      setTestimonials(mockTestimonials);
      setGallery(mockGallery);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 to-purple-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading beautiful experiences...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50">
      <Header onBookingClick={() => setIsBookingOpen(true)} />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative container mx-auto px-4 py-20 lg:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-pink-200 bg-clip-text text-transparent">
              Your Dream Bridal Look
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-pink-100">
              Transform into the most beautiful version of yourself on your special day
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-purple-600 hover:bg-pink-50 text-lg px-8 py-3"
                onClick={() => setIsBookingOpen(true)}
              >
                Book Consultation <Heart className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-purple-600 text-lg px-8 py-3"
              >
                View Gallery <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-pink-50 to-transparent"></div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gradient-to-br from-pink-50 to-purple-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Bridal Services
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Professional bridal makeup services tailored to make your special day unforgettable
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {services.length > 0 && services.map((service) => (
              <Card key={service.id} className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-white/80 backdrop-blur border-0 shadow-lg">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img 
                    src={service.image} 
                    alt={service.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-semibold text-gray-800">{service.name}</h3>
                    <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white">
                      ₹{service.price.toLocaleString()}
                    </Badge>
                  </div>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex items-center text-sm text-gray-500 mb-4">
                    <Clock className="h-4 w-4 mr-1" />
                    {service.duration}
                  </div>
                  <div className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <div key={index} className="flex items-center text-sm text-gray-600">
                        <Check className="h-4 w-4 mr-2 text-green-500" />
                        {feature}
                      </div>
                    ))}
                  </div>
                  <Button 
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white"
                    onClick={() => setIsBookingOpen(true)}
                  >
                    Book Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-gradient-to-r from-purple-50 to-indigo-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4 bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
              Our Beautiful Work
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              See how we've helped brides look and feel their absolute best
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-6xl mx-auto">
            {gallery.length > 0 && gallery.map((image) => (
              <div key={image.id} className="group relative overflow-hidden rounded-xl aspect-square">
                <img 
                  src={image.url} 
                  alt={image.alt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 text-white">
                    <Badge className="bg-white/20 text-white capitalize">{image.category}</Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-to-br from-indigo-50 to-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4 bg-gradient-to-r from-indigo-600 to-pink-600 bg-clip-text text-transparent">
              Happy Brides
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it - hear from our beautiful brides
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.length > 0 && testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="bg-white/80 backdrop-blur border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover mr-4"
                    />
                    <div>
                      <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                      <div className="flex items-center">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 italic mb-4">"{testimonial.comment}"</p>
                  <p className="text-sm text-gray-500">
                    Wedding Date: {new Date(testimonial.weddingDate).toLocaleDateString()}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h2 className="text-4xl font-bold mb-8">
              Ready to Look Stunning?
            </h2>
            <p className="text-xl mb-8 text-pink-100">
              Book your consultation today and let's create your perfect bridal look together
            </p>
            
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="bg-white/20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-8 w-8" />
                </div>
                <h3 className="font-semibold mb-2">Call Us</h3>
                <p className="text-pink-100">+91 98765 43210</p>
              </div>
              
              <div className="text-center">
                <div className="bg-white/20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-8 w-8" />
                </div>
                <h3 className="font-semibold mb-2">Email Us</h3>
                <p className="text-pink-100">hello@bridalmakeup.com</p>
              </div>
              
              <div className="text-center">
                <div className="bg-white/20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-8 w-8" />
                </div>
                <h3 className="font-semibold mb-2">Visit Us</h3>
                <p className="text-pink-100">123 Beauty Street, Mumbai</p>
              </div>
            </div>
            
            <Button 
              size="lg" 
              className="bg-white text-purple-600 hover:bg-pink-50 text-lg px-12 py-4"
              onClick={() => setIsBookingOpen(true)}
            >
              Book Your Dream Look <Calendar className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <BookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} />
    </div>
  );
};

export default Home;