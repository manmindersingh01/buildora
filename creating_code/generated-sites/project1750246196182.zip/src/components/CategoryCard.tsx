import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { Category } from '@/types';

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Card className="group cursor-pointer transform hover:scale-105 transition-all duration-300 bg-white/10 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl overflow-hidden">
      <div className="relative overflow-hidden h-48">
        <img 
          src={category.image} 
          alt={category.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="font-black text-xl text-white mb-1 group-hover:text-yellow-300 transition-colors">
            {category.name}
          </h3>
          <p className="text-white/80 text-sm mb-3">{category.description}</p>
          <div className="flex items-center text-yellow-300 font-bold text-sm group-hover:translate-x-2 transition-transform duration-200">
            <span>Explore</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </div>
        </div>
      </div>
    </Card>
  );
}