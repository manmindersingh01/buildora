import React from 'react';
import { TodoFilter } from '@/types';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Filter, Search, SortAsc, SortDesc, X } from 'lucide-react';

interface TodoFiltersProps {
  filter: TodoFilter;
  onFilterChange: (filter: TodoFilter) => void;
  categories: string[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const TodoFilters: React.FC<TodoFiltersProps> = ({
  filter,
  onFilterChange,
  categories,
  searchQuery,
  onSearchChange
}) => {
  const statusOptions = [
    { value: 'all', label: 'All Tasks' },
    { value: 'active', label: 'Active' },
    { value: 'completed', label: 'Completed' }
  ];

  const priorityOptions = [
    { value: 'all', label: 'All Priorities' },
    { value: 'high', label: 'High' },
    { value: 'medium', label: 'Medium' },
    { value: 'low', label: 'Low' }
  ];

  const sortOptions = [
    { value: 'createdAt', label: 'Created Date' },
    { value: 'dueDate', label: 'Due Date' },
    { value: 'priority', label: 'Priority' },
    { value: 'title', label: 'Title' }
  ];

  const toggleSortOrder = () => {
    onFilterChange({
      ...filter,
      sortOrder: filter.sortOrder === 'asc' ? 'desc' : 'asc'
    });
  };

  const clearFilters = () => {
    onFilterChange({
      status: 'all',
      sortBy: 'createdAt',
      sortOrder: 'desc'
    });
    onSearchChange('');
  };

  const hasActiveFilters = filter.status !== 'all' || filter.priority || filter.category || searchQuery;

  return (
    <div className="bg-white rounded-lg border p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Filter className="w-5 h-5 text-gray-600" />
          <span className="font-medium text-gray-900">Filters</span>
        </div>
        
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="text-gray-600 hover:text-gray-900"
          >
            <X className="w-4 h-4 mr-1" />
            Clear
          </Button>
        )}
      </div>
      
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          placeholder="Search todos..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>
      
      {/* Filter Controls */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Status Filter */}
        <Select
          value={filter.status}
          onValueChange={(value: 'all' | 'active' | 'completed') => 
            onFilterChange({ ...filter, status: value })
          }
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {statusOptions.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {/* Priority Filter */}
        <Select
          value={filter.priority || 'all'}
          onValueChange={(value) => 
            onFilterChange({ 
              ...filter, 
              priority: value === 'all' ? undefined : value as 'low' | 'medium' | 'high'
            })
          }
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {priorityOptions.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {/* Category Filter */}
        <Select
          value={filter.category || 'all'}
          onValueChange={(value) => 
            onFilterChange({ 
              ...filter, 
              category: value === 'all' ? undefined : value
            })
          }
        >
          <SelectTrigger>
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(category => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {/* Sort */}
        <div className="flex space-x-2">
          <Select
            value={filter.sortBy}
            onValueChange={(value: 'createdAt' | 'dueDate' | 'priority' | 'title') => 
              onFilterChange({ ...filter, sortBy: value })
            }
          >
            <SelectTrigger className="flex-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button
            variant="outline"
            size="sm"
            onClick={toggleSortOrder}
            className="w-10 h-10 p-0"
          >
            {filter.sortOrder === 'asc' ? <SortAsc className="w-4 h-4" /> : <SortDesc className="w-4 h-4" />}
          </Button>
        </div>
      </div>
      
      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2">
          {filter.status !== 'all' && (
            <Badge variant="secondary">
              Status: {filter.status}
            </Badge>
          )}
          {filter.priority && (
            <Badge variant="secondary">
              Priority: {filter.priority}
            </Badge>
          )}
          {filter.category && (
            <Badge variant="secondary">
              Category: {filter.category}
            </Badge>
          )}
          {searchQuery && (
            <Badge variant="secondary">
              Search: "{searchQuery}"
            </Badge>
          )}
        </div>
      )}
    </div>
  );
};

export default TodoFilters;