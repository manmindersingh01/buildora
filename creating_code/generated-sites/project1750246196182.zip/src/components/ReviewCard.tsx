import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Star } from 'lucide-react';
import { Review } from '@/types';

interface ReviewCardProps {
  review: Review;
}

export function ReviewCard({ review }: ReviewCardProps) {
  return (
    <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
      <CardContent className="p-6">
        <div className="flex items-center gap-4 mb-4">
          <img 
            src={review.avatar} 
            alt={review.name}
            className="w-12 h-12 rounded-full object-cover border-2 border-gradient-to-r from-purple-400 to-pink-400"
          />
          <div>
            <h4 className="font-bold text-gray-800">{review.name}</h4>
            <div className="flex items-center gap-1">
              {[...Array(review.rating)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
          </div>
        </div>
        <p className="text-gray-700 italic leading-relaxed">
          "{review.comment}"
        </p>
      </CardContent>
    </Card>
  );
}