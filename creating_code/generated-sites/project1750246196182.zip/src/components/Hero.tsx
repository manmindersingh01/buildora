import { Button } from '@/components/ui/button';
import { Star, Calendar, Heart } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 h-32 bg-rose-200/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-purple-200/30 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-pink-200/30 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      <div className="relative container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Left Content */}
          <div className="space-y-8 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span className="text-sm font-medium text-gray-700">Rated #1 Bridal Makeup Artist</span>
            </div>
            
            <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
              <span className="bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 bg-clip-text text-transparent">
                Your Dream
              </span>
              <br />
              <span className="text-gray-800">Bridal Look</span>
            </h1>
            
            <p className="text-xl text-gray-600 leading-relaxed max-w-xl">
              Transform into the most beautiful version of yourself on your special day. 
              Expert bridal makeup that captures your unique essence and makes you glow.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white px-8 py-6 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              >
                <Calendar className="w-5 h-5 mr-2" />
                Book Your Trial
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-rose-300 text-rose-600 hover:bg-rose-50 px-8 py-6 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              >
                View Gallery
              </Button>
            </div>
            
            <div className="flex items-center justify-center lg:justify-start gap-8 pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800">500+</div>
                <div className="text-sm text-gray-600">Happy Brides</div>
              </div>
              <div className="w-px h-12 bg-gray-300"></div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800">5★</div>
                <div className="text-sm text-gray-600">Rating</div>
              </div>
              <div className="w-px h-12 bg-gray-300"></div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800">3+</div>
                <div className="text-sm text-gray-600">Years Exp</div>
              </div>
            </div>
          </div>
          
          {/* Right Content - Image Collage */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4 h-[600px]">
              {/* Main large image */}
              <div className="col-span-2 row-span-2 relative rounded-3xl overflow-hidden shadow-2xl transform rotate-1 hover:rotate-0 transition-all duration-300">
                <img 
                  src="https://images.unsplash.com/photo-1594736797933-d0d79ba7ac61?w=600&h=800&fit=crop&crop=face" 
                  alt="Beautiful Indian Bride" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <div className="flex items-center gap-1 mb-1">
                    <Heart className="w-4 h-4 fill-current" />
                    <span className="text-sm">Traditional Elegance</span>
                  </div>
                </div>
              </div>
              
              {/* Smaller accent images */}
              <div className="relative rounded-2xl overflow-hidden shadow-xl transform -rotate-2 hover:rotate-0 transition-all duration-300">
                <img 
                  src="https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=300&h=200&fit=crop&crop=face" 
                  alt="Bridal Makeup Details" 
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="relative rounded-2xl overflow-hidden shadow-xl transform rotate-2 hover:rotate-0 transition-all duration-300">
                <img 
                  src="https://images.unsplash.com/photo-1606170033648-5d55a3eaca8b?w=300&h=200&fit=crop&crop=face" 
                  alt="Bridal Eye Makeup" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-white/90 backdrop-blur-sm p-3 rounded-full shadow-lg animate-bounce">
              <Star className="w-6 h-6 text-yellow-500 fill-current" />
            </div>
            <div className="absolute bottom-10 -left-4 bg-white/90 backdrop-blur-sm p-3 rounded-full shadow-lg animate-pulse">
              <Heart className="w-6 h-6 text-rose-500 fill-current" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;