export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  trending?: boolean;
  new?: boolean;
  sizes: string[];
  description: string;
}

export interface Category {
  id: string;
  name: string;
  image: string;
  count: number;
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  avatar: string;
  productId: string;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize: string;
}