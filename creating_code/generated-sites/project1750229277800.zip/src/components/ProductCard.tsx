import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { heart, shopping-cart, star, eye } from 'lucide-react';
import { Product } from '@/types';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [isLiked, setIsLiked] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Card 
      className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border-0 bg-white overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.trending && (
            <Badge className="bg-gradient-to-r from-pink-500 to-rose-500 text-white border-0 shadow-lg">
              🔥 Trending
            </Badge>
          )}
          {product.new && (
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 shadow-lg">
              ✨ New
            </Badge>
          )}
        </div>

        {/* Heart Icon */}
        <Button
          variant="ghost"
          size="sm"
          className={`absolute top-3 right-3 w-10 h-10 rounded-full backdrop-blur-sm transition-all duration-200 ${
            isLiked ? 'bg-pink-100 text-pink-600' : 'bg-white/80 text-gray-600 hover:bg-pink-100 hover:text-pink-600'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            setIsLiked(!isLiked);
          }}
        >
          <heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
        </Button>

        {/* Hover Actions */}
        <div className={`absolute bottom-3 left-3 right-3 transform transition-all duration-300 ${
          isHovered ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0'
        }`}>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              className="flex-1 bg-white/90 text-gray-900 hover:bg-white backdrop-blur-sm font-medium"
              onClick={(e) => e.stopPropagation()}
            >
              <eye className="w-4 h-4 mr-2" />
              Quick View
            </Button>
            <Button 
              size="sm" 
              className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white backdrop-blur-sm"
              onClick={(e) => e.stopPropagation()}
            >
              <shopping-cart className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <CardContent className="p-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500 font-medium">{product.category}</span>
            <div className="flex items-center gap-1">
              <star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm text-gray-600">4.8</span>
            </div>
          </div>
          
          <h3 className="font-semibold text-gray-900 line-clamp-2 group-hover:text-pink-600 transition-colors">
            {product.name}
          </h3>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-gray-900">${product.price}</span>
              {product.originalPrice && (
                <span className="text-sm text-gray-500 line-through">${product.originalPrice}</span>
              )}
            </div>
            
            <div className="flex gap-1">
              {product.sizes.slice(0, 3).map((size) => (
                <span key={size} className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">
                  {size}
                </span>
              ))}
              {product.sizes.length > 3 && (
                <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">
                  +{product.sizes.length - 3}
                </span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};