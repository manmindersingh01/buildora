import React from 'react';
import { Todo } from '@/types';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Edit, Delete, Calendar, Flag } from 'lucide-react';
import { format } from 'date-fns';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onEdit: (todo: Todo) => void;
  onDelete: (id: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onEdit, onDelete }) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const isOverdue = todo.dueDate && new Date(todo.dueDate) < new Date() && !todo.completed;

  return (
    <Card className={`transition-all duration-200 hover:shadow-md ${
      todo.completed ? 'opacity-75 bg-gray-50' : ''
    } ${isOverdue ? 'border-red-300' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <Checkbox
            checked={todo.completed}
            onCheckedChange={() => onToggle(todo.id)}
            className="mt-1"
          />
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-2">
              <h3 className={`font-medium text-gray-900 ${
                todo.completed ? 'line-through text-gray-500' : ''
              }`}>
                {todo.title}
              </h3>
              
              <div className="flex items-center space-x-2">
                <Badge className={getPriorityColor(todo.priority)}>
                  <Flag className="w-3 h-3 mr-1" />
                  {todo.priority}
                </Badge>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onEdit(todo)}
                  className="h-8 w-8 p-0"
                >
                  <Edit className="w-4 h-4" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDelete(todo.id)}
                  className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                >
                  <Delete className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            {todo.description && (
              <p className={`text-sm text-gray-600 mb-2 ${
                todo.completed ? 'line-through' : ''
              }`}>
                {todo.description}
              </p>
            )}
            
            <div className="flex items-center justify-between text-xs text-gray-500">
              <Badge variant="outline" className="text-xs">
                {todo.category}
              </Badge>
              
              {todo.dueDate && (
                <div className={`flex items-center space-x-1 ${
                  isOverdue ? 'text-red-600' : ''
                }`}>
                  <Calendar className="w-3 h-3" />
                  <span>{format(new Date(todo.dueDate), 'MMM d, yyyy')}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TodoItem;