import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingBag, Star } from 'lucide-react';
import { Product } from '@/types';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [isLiked, setIsLiked] = React.useState(false);

  return (
    <Card className="group bg-gray-900/50 border-gray-700 hover:border-purple-500/50 transition-all duration-300 hover:transform hover:scale-105">
      <CardContent className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
          />
          <div className="absolute top-3 left-3 flex gap-2">
            {product.isNew && (
              <Badge className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white border-none">
                NEW
              </Badge>
            )}
            {product.isTrending && (
              <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white border-none">
                🔥 TRENDING
              </Badge>
            )}
            {product.originalPrice && (
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-none">
                SALE
              </Badge>
            )}
          </div>
          <button
            onClick={() => setIsLiked(!isLiked)}
            className="absolute top-3 right-3 p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors"
          >
            <Heart
              className={`h-5 w-5 ${
                isLiked ? 'fill-pink-500 text-pink-500' : 'text-white'
              }`}
            />
          </button>
        </div>
        <div className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline" className="border-purple-500/50 text-purple-400">
              {product.category}
            </Badge>
            <div className="flex items-center gap-1 text-yellow-400">
              <Star className="h-4 w-4 fill-current" />
              <span className="text-sm text-gray-400">4.8</span>
            </div>
          </div>
          <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-400 transition-colors">
            {product.name}
          </h3>
          <p className="text-gray-400 text-sm mb-3 line-clamp-2">
            {product.description}
          </p>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl font-bold text-white">
              ${product.price}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">
                ${product.originalPrice}
              </span>
            )}
          </div>
          <div className="flex gap-2 mb-4">
            {product.colors.slice(0, 3).map((color, index) => (
              <div
                key={index}
                className="w-6 h-6 rounded-full border-2 border-gray-600"
                style={{
                  backgroundColor: color.toLowerCase() === 'holographic' 
                    ? 'linear-gradient(45deg, #ff006e, #8338ec, #3a86ff)' 
                    : color.toLowerCase()
                }}
                title={color}
              />
            ))}
            {product.colors.length > 3 && (
              <div className="w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center text-xs text-gray-400">
                +{product.colors.length - 3}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <Button className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white border-none">
              <ShoppingBag className="h-4 w-4 mr-2" />
              Add to Cart
            </Button>
            <Button variant="outline" className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black">
              View
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};