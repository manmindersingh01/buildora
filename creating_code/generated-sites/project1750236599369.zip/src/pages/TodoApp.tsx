import React, { useState } from 'react';
import { Todo } from '@/types';
import { useTodos } from '@/hooks/useTodos';
import TodoItem from '@/components/TodoItem';
import TodoForm from '@/components/TodoForm';
import TodoFilters from '@/components/TodoFilters';
import TodoStatsComponent from '@/components/TodoStats';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Plus, CheckCircle, ListTodo } from 'lucide-react';

const TodoApp: React.FC = () => {
  const {
    todos,
    filter,
    searchQuery,
    isLoading,
    categories,
    stats,
    setFilter,
    setSearchQuery,
    addTodo,
    updateTodo,
    deleteTodo,
    toggleTodo
  } = useTodos();
  
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);
  const [showForm, setShowForm] = useState(false);

  const handleAddTodo = (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    addTodo(todoData);
    setShowForm(false);
  };

  const handleEditTodo = (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingTodo) {
      updateTodo(editingTodo.id, todoData);
      setEditingTodo(null);
    }
  };

  const handleDeleteTodo = (id: string) => {
    if (window.confirm('Are you sure you want to delete this todo?')) {
      deleteTodo(id);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your todos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg">
                <ListTodo className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">TodoMaster</h1>
                <p className="text-gray-600">Organize your tasks efficiently</p>
              </div>
            </div>
            
            <Dialog open={showForm} onOpenChange={setShowForm}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Todo
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <TodoForm
                  onSubmit={handleAddTodo}
                  onCancel={() => setShowForm(false)}
                  categories={categories}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics */}
        <TodoStatsComponent stats={stats} />
        
        {/* Filters */}
        <TodoFilters
          filter={filter}
          onFilterChange={setFilter}
          categories={categories}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        
        {/* Todo List */}
        <div className="mt-8">
          {todos.length === 0 ? (
            <Card className="py-16">
              <CardContent className="text-center">
                <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="w-12 h-12 text-gray-400" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">
                  {searchQuery || filter.status !== 'all' || filter.priority || filter.category
                    ? 'No todos match your filters'
                    : 'No todos yet'}
                </h3>
                <p className="text-gray-600 mb-6">
                  {searchQuery || filter.status !== 'all' || filter.priority || filter.category
                    ? 'Try adjusting your search or filters to find what you\'re looking for.'
                    : 'Get started by adding your first todo item.'}
                </p>
                {!searchQuery && filter.status === 'all' && !filter.priority && !filter.category && (
                  <Button 
                    onClick={() => setShowForm(true)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Todo
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {todos.map(todo => (
                <TodoItem
                  key={todo.id}
                  todo={todo}
                  onToggle={toggleTodo}
                  onEdit={setEditingTodo}
                  onDelete={handleDeleteTodo}
                />
              ))}
            </div>
          )}
        </div>
        
        {/* Edit Todo Dialog */}
        {editingTodo && (
          <Dialog open={!!editingTodo} onOpenChange={() => setEditingTodo(null)}>
            <DialogContent className="max-w-md">
              <TodoForm
                todo={editingTodo}
                onSubmit={handleEditTodo}
                onCancel={() => setEditingTodo(null)}
                categories={categories}
              />
            </DialogContent>
          </Dialog>
        )}
      </main>
      
      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 TodoMaster. Built with React, TypeScript & Tailwind CSS.</p>
            <p className="mt-2 text-sm">Stay organized, stay productive! ✨</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default TodoApp;