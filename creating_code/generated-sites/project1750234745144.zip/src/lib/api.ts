import axios from 'axios';
import { Todo } from '@/types';

const API_BASE_URL = 'http://localhost:3000/api';

export const todoApi = {
  // Get all todos
  getTodos: async () => {
    const response = await axios.get(`${API_BASE_URL}/todos`);
    return response.data;
  },

  // Create new todo
  createTodo: async (todo: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    const response = await axios.post(`${API_BASE_URL}/todos`, todo);
    return response.data;
  },

  // Update todo
  updateTodo: async (id: string, updates: Partial<Todo>) => {
    const response = await axios.put(`${API_BASE_URL}/todos/${id}`, updates);
    return response.data;
  },

  // Delete todo
  deleteTodo: async (id: string) => {
    const response = await axios.delete(`${API_BASE_URL}/todos/${id}`);
    return response.data;
  },

  // Toggle todo completion
  toggleTodo: async (id: string) => {
    const response = await axios.patch(`${API_BASE_URL}/todos/${id}/toggle`);
    return response.data;
  }
};