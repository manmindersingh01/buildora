import { useState, useEffect } from 'react';
import axios from 'axios';
import { Product } from '@/types';

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Mock data for development
  const mockProducts: Product[] = [
    {
      id: '1',
      name: 'Main Character Energy Tee',
      price: 28,
      originalPrice: 35,
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop',
      category: 'Aesthetic',
      trending: true,
      new: false,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      description: 'Channel your main character energy with this soft cotton tee'
    },
    {
      id: '2',
      name: 'Y2K Butterfly Dreams',
      price: 32,
      image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=400&h=400&fit=crop',
      category: 'Y2K',
      trending: true,
      new: true,
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      description: 'Nostalgic Y2K vibes with butterfly graphics'
    },
    {
      id: '3',
      name: 'Soft Girl Sunset',
      price: 25,
      image: 'https://images.unsplash.com/photo-1583743814966-8936f37f8302?w=400&h=400&fit=crop',
      category: 'Soft Girl',
      trending: false,
      new: true,
      sizes: ['XS', 'S', 'M', 'L'],
      description: 'Dreamy sunset colors for your soft girl aesthetic'
    },
    {
      id: '4',
      name: 'Dark Academia Scholar',
      price: 30,
      originalPrice: 38,
      image: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400&h=400&fit=crop',
      category: 'Dark Academia',
      trending: true,
      new: false,
      sizes: ['S', 'M', 'L', 'XL'],
      description: 'Intellectual vibes for the modern scholar'
    },
    {
      id: '5',
      name: 'Cottagecore Dreamer',
      price: 27,
      image: 'https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=400&h=400&fit=crop',
      category: 'Cottagecore',
      trending: false,
      new: true,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      description: 'Embrace the cottagecore lifestyle with floral designs'
    },
    {
      id: '6',
      name: 'Grunge Revival',
      price: 33,
      image: 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=400&h=400&fit=crop',
      category: 'Grunge',
      trending: true,
      new: false,
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      description: '90s grunge aesthetic for the modern rebellious spirit'
    }
  ];

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // In a real app, this would be:
        // const response = await axios.get('/api/products');
        // if (response.data.success) {
        //   setProducts(response.data.data);
        // }
        
        setProducts(mockProducts);
      } catch (err) {
        setError('Failed to fetch products');
        console.error('Error fetching products:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return { products, loading, error };
};