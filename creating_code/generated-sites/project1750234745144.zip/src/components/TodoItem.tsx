import React, { useState } from 'react';
import { CheckCircle, Circle, Star, Calendar, Trash2, Edit2, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { EditTodoDialog } from '@/components/EditTodoDialog';
import { Todo } from '@/types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onUpdate: (id: string, updates: Partial<Todo>) => void;
  onDelete: (id: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onUpdate, onDelete }) => {
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return '🔴';
      case 'medium': return '🟡';
      case 'low': return '🟢';
      default: return '⚪';
    }
  };

  const isOverdue = todo.dueDate && new Date(todo.dueDate) < new Date() && !todo.completed;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: date.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined
    });
  };

  const handleUpdate = (updates: Partial<Todo>) => {
    onUpdate(todo.id, updates);
    setIsEditDialogOpen(false);
  };

  return (
    <>
      <Card className={`group transition-all duration-200 hover:shadow-md border-0 bg-white/70 backdrop-blur-sm ${
        todo.completed ? 'opacity-75' : ''
      } ${
        isOverdue ? 'ring-1 ring-red-200' : ''
      }`}>
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            {/* Toggle Button */}
            <Button
              variant="ghost"
              size="sm"
              className="mt-0.5 p-1 h-auto hover:bg-transparent"
              onClick={() => onToggle(todo.id)}
            >
              {todo.completed ? (
                <CheckCircle className="w-5 h-5 text-green-600" />
              ) : (
                <Circle className="w-5 h-5 text-gray-400 hover:text-blue-600 transition-colors" />
              )}
            </Button>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <h3 className={`font-medium text-gray-900 mb-1 ${
                    todo.completed ? 'line-through text-gray-500' : ''
                  }`}>
                    {todo.title}
                  </h3>
                  {todo.description && (
                    <p className={`text-sm text-gray-600 mb-2 ${
                      todo.completed ? 'line-through text-gray-400' : ''
                    }`}>
                      {todo.description}
                    </p>
                  )}
                </div>
                
                {/* Actions */}
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 hover:bg-blue-100 hover:text-blue-600"
                    onClick={() => setIsEditDialogOpen(true)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 hover:bg-red-100 hover:text-red-600"
                    onClick={() => onDelete(todo.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Meta Information */}
              <div className="flex items-center gap-3 mt-2">
                {/* Priority */}
                <Badge variant="outline" className={`text-xs ${getPriorityColor(todo.priority)}`}>
                  <span className="mr-1">{getPriorityIcon(todo.priority)}</span>
                  {todo.priority}
                </Badge>

                {/* Due Date */}
                {todo.dueDate && (
                  <div className={`flex items-center gap-1 text-xs ${
                    isOverdue ? 'text-red-600' : 'text-gray-500'
                  }`}>
                    <Calendar className="w-3 h-3" />
                    <span>{formatDate(todo.dueDate)}</span>
                    {isOverdue && (
                      <Badge variant="outline" className="text-xs bg-red-50 text-red-600 border-red-200 ml-1">
                        Overdue
                      </Badge>
                    )}
                  </div>
                )}

                {/* Created Date */}
                <div className="flex items-center gap-1 text-xs text-gray-400">
                  <Clock className="w-3 h-3" />
                  <span>Created {formatDate(todo.createdAt)}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <EditTodoDialog
        todo={todo}
        isOpen={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        onSubmit={handleUpdate}
      />
    </>
  );
};