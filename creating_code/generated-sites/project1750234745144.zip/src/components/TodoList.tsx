import { useState } from 'react';
import { Calendar, Clock, Flag, Edit, Delete, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Todo } from '@/types';
import { TodoForm } from './TodoForm';

interface TodoListProps {
  todos: Todo[];
  loading: boolean;
  onToggle: (id: string) => void;
  onUpdate: (id: string, data: Partial<Todo>) => void;
  onDelete: (id: string) => void;
}

export function TodoList({ todos, loading, onToggle, onUpdate, onDelete }: TodoListProps) {
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityBadgeColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const isOverdue = (dueDate?: string) => {
    if (!dueDate) return false;
    return new Date(dueDate) < new Date() && !todos.find(t => t.dueDate === dueDate)?.completed;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="bg-white/50 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/4"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (todos.length === 0) {
    return (
      <Card className="bg-white/50 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No tasks found</h3>
          <p className="text-gray-600">Get started by adding your first task!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-4">
        {todos.map((todo) => (
          <Card key={todo.id} className={`bg-white/50 backdrop-blur-sm border-0 shadow-lg transition-all duration-200 hover:shadow-xl ${todo.completed ? 'opacity-75' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                {/* Priority Indicator */}
                <div className={`w-1 h-16 rounded-full ${getPriorityColor(todo.priority)} flex-shrink-0 mt-1`}></div>
                
                {/* Checkbox */}
                <div className="flex-shrink-0 mt-1">
                  <Checkbox
                    checked={todo.completed}
                    onCheckedChange={() => onToggle(todo.id)}
                    className="w-5 h-5"
                  />
                </div>

                {/* Content */}
                <div className="flex-grow min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-grow">
                      <h3 className={`font-semibold text-gray-900 mb-1 ${todo.completed ? 'line-through text-gray-500' : ''}`}>
                        {todo.title}
                      </h3>
                      {todo.description && (
                        <p className={`text-sm text-gray-600 mb-2 ${todo.completed ? 'line-through' : ''}`}>
                          {todo.description}
                        </p>
                      )}
                      
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <Badge className={`text-xs ${getPriorityBadgeColor(todo.priority)}`}>
                          <Flag className="w-3 h-3 mr-1" />
                          {todo.priority}
                        </Badge>
                        
                        {todo.category && (
                          <Badge variant="secondary" className="text-xs">
                            {todo.category}
                          </Badge>
                        )}
                        
                        {todo.dueDate && (
                          <Badge className={`text-xs ${isOverdue(todo.dueDate) ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}`}>
                            <Calendar className="w-3 h-3 mr-1" />
                            {formatDate(todo.dueDate)}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center text-xs text-gray-500">
                        <Clock className="w-3 h-3 mr-1" />
                        Created {formatDate(todo.createdAt)}
                      </div>
                    </div>
                    
                    {/* Actions */}
                    <div className="flex items-center space-x-1 flex-shrink-0 ml-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditingTodo(todo)}
                        className="h-8 w-8 p-0 hover:bg-blue-100"
                      >
                        <Edit className="w-4 h-4 text-blue-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDelete(todo.id)}
                        className="h-8 w-8 p-0 hover:bg-red-100"
                      >
                        <Delete className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Edit Todo Modal */}
      {editingTodo && (
        <TodoForm
          todo={editingTodo}
          onSubmit={(data) => {
            onUpdate(editingTodo.id, data);
            setEditingTodo(null);
          }}
          onClose={() => setEditingTodo(null)}
        />
      )}
    </>
  );
}