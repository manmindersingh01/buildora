import React, { useState, useEffect } from 'react';
import { Plus, Search, Filter, CheckCircle, Circle, Star, Calendar, Trash2, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { TodoItem } from '@/components/TodoItem';
import { TodoStats } from '@/components/TodoStats';
import { AddTodoDialog } from '@/components/AddTodoDialog';
import { useTodos } from '@/hooks/useTodos';
import { Todo, TodoFilters } from '@/types';

const TodoApp: React.FC = () => {
  const { todos, loading, addTodo, updateTodo, deleteTodo, toggleTodo } = useTodos();
  const [filters, setFilters] = useState<TodoFilters>({
    status: 'all',
    search: ''
  });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const filteredTodos = todos.filter(todo => {
    const matchesStatus = 
      filters.status === 'all' || 
      (filters.status === 'active' && !todo.completed) ||
      (filters.status === 'completed' && todo.completed);
    
    const matchesSearch = 
      filters.search === '' ||
      todo.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      todo.description?.toLowerCase().includes(filters.search.toLowerCase());
    
    const matchesPriority = 
      !filters.priority || todo.priority === filters.priority;
    
    return matchesStatus && matchesSearch && matchesPriority;
  });

  const handleAddTodo = async (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    await addTodo(todoData);
    setIsAddDialogOpen(false);
  };

  const handleUpdateFilters = (key: keyof TodoFilters, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  TodoMaster
                </h1>
                <p className="text-sm text-gray-600">Stay organized, stay productive</p>
              </div>
            </div>
            <AddTodoDialog
              isOpen={isAddDialogOpen}
              onOpenChange={setIsAddDialogOpen}
              onSubmit={handleAddTodo}
            />
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Stats */}
        <TodoStats todos={todos} />
        
        {/* Filters */}
        <Card className="mb-6 shadow-sm border-0 bg-white/70 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search todos..."
                  value={filters.search}
                  onChange={(e) => handleUpdateFilters('search', e.target.value)}
                  className="pl-10 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              
              {/* Status Filter */}
              <Select
                value={filters.status}
                onValueChange={(value) => handleUpdateFilters('status', value)}
              >
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tasks</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
              
              {/* Priority Filter */}
              <Select
                value={filters.priority || 'all'}
                onValueChange={(value) => handleUpdateFilters('priority', value === 'all' ? '' : value)}
              >
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Todo List */}
        <div className="space-y-3">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : filteredTodos.length === 0 ? (
            <Card className="text-center py-12 shadow-sm border-0 bg-white/70 backdrop-blur-sm">
              <CardContent>
                <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {filters.search || filters.priority || filters.status !== 'all' 
                    ? 'No todos match your filters' 
                    : 'No todos yet'}
                </h3>
                <p className="text-gray-600 mb-4">
                  {filters.search || filters.priority || filters.status !== 'all'
                    ? 'Try adjusting your filters to see more todos'
                    : 'Create your first todo to get started'}
                </p>
                {(!filters.search && !filters.priority && filters.status === 'all') && (
                  <Button 
                    onClick={() => setIsAddDialogOpen(true)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Todo
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            filteredTodos.map(todo => (
              <TodoItem
                key={todo.id}
                todo={todo}
                onToggle={toggleTodo}
                onUpdate={updateTodo}
                onDelete={deleteTodo}
              />
            ))
          )}
        </div>
      </main>
    </div>
  );
};

export default TodoApp;