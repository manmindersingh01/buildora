import { useState, useEffect } from 'react';
import axios from 'axios';
import { Pizza } from '@/types';

export const usePizzas = () => {
  const [pizzas, setPizzas] = useState<Pizza[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPizzas = async () => {
      try {
        setLoading(true);
        // Simulating API call with mock data
        const mockPizzas: Pizza[] = [
          {
            id: '1',
            name: 'Margherita Classic',
            description: 'Fresh mozzarella, tomato sauce, basil, and extra virgin olive oil',
            price: 14,
            image: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=500&h=400&fit=crop',
            category: 'classic',
            ingredients: ['Mozzarella', 'Tomato Sauce', 'Fresh Basil', 'Olive Oil'],
            size: 'medium',
            popular: true
          },
          {
            id: '2',
            name: 'Pepperoni Supreme',
            description: 'Classic pepperoni with mozzarella cheese and signature tomato sauce',
            price: 16,
            image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=500&h=400&fit=crop',
            category: 'classic',
            ingredients: ['Pepperoni', 'Mozzarella', 'Tomato Sauce', 'Oregano'],
            size: 'medium',
            popular: true
          },
          {
            id: '3',
            name: 'Quattro Stagioni',
            description: 'Four seasons pizza with mushrooms, artichokes, ham, and olives',
            price: 18,
            image: 'https://images.unsplash.com/photo-1571066811602-716837d681de?w=500&h=400&fit=crop',
            category: 'specialty',
            ingredients: ['Mushrooms', 'Artichokes', 'Ham', 'Black Olives', 'Mozzarella'],
            size: 'medium',
            popular: true
          },
          {
            id: '4',
            name: 'Vegetarian Delight',
            description: 'Bell peppers, mushrooms, onions, tomatoes, and fresh herbs',
            price: 15,
            image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=500&h=400&fit=crop',
            category: 'vegetarian',
            ingredients: ['Bell Peppers', 'Mushrooms', 'Red Onions', 'Cherry Tomatoes', 'Fresh Herbs'],
            size: 'medium',
            popular: false
          },
          {
            id: '5',
            name: 'BBQ Chicken',
            description: 'Grilled chicken, BBQ sauce, red onions, and cilantro',
            price: 17,
            image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&h=400&fit=crop',
            category: 'specialty',
            ingredients: ['Grilled Chicken', 'BBQ Sauce', 'Red Onions', 'Cilantro', 'Mozzarella'],
            size: 'medium',
            popular: false
          },
          {
            id: '6',
            name: 'Vegan Paradise',
            description: 'Vegan cheese, roasted vegetables, and plant-based pepperoni',
            price: 16,
            image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=500&h=400&fit=crop',
            category: 'vegan',
            ingredients: ['Vegan Cheese', 'Roasted Peppers', 'Zucchini', 'Plant-based Pepperoni'],
            size: 'medium',
            popular: false
          }
        ];
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setPizzas(mockPizzas);
        setError(null);
      } catch (err) {
        setError('Failed to fetch pizzas');
        console.error('Error fetching pizzas:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPizzas();
  }, []);

  return { pizzas, loading, error };
};