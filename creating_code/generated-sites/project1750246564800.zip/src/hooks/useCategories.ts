import { useState, useEffect } from 'react';
import axios from 'axios';
import { Category } from '@/types';

export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Mock data for development
  const mockCategories: Category[] = [
    {
      id: '1',
      name: 'Aesthetic',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=300&fit=crop',
      count: 24
    },
    {
      id: '2',
      name: 'Y2K',
      image: 'https://images.unsplash.com/photo-1550928431-ee0ec6db30d3?w=400&h=300&fit=crop',
      count: 18
    },
    {
      id: '3',
      name: 'Soft Girl',
      image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=300&fit=crop',
      count: 15
    },
    {
      id: '4',
      name: 'Dark Academia',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop',
      count: 21
    },
    {
      id: '5',
      name: 'Cottagecore',
      image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=400&h=300&fit=crop',
      count: 12
    },
    {
      id: '6',
      name: 'Grunge',
      image: 'https://images.unsplash.com/photo-1494252713559-f26b4bf0b174?w=400&h=300&fit=crop',
      count: 16
    }
  ];

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // In a real app, this would be:
        // const response = await axios.get('/api/categories');
        // if (response.data.success) {
        //   setCategories(response.data.data);
        // }
        
        setCategories(mockCategories);
      } catch (err) {
        setError('Failed to fetch categories');
        console.error('Error fetching categories:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  return { categories, loading, error };
};