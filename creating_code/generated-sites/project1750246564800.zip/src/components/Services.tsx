import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Clock, Star } from 'lucide-react';
import { Service } from '@/types';

const services: Service[] = [
  {
    id: 1,
    name: "Bridal Makeup Package",
    description: "Complete bridal makeup with trial session, including base, eyes, lips, and touch-up kit.",
    price: 299,
    duration: "4-5 hours",
    image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
    features: ["Pre-wedding trial", "Wedding day makeup", "Touch-up kit", "False lashes", "Setting spray"]
  },
  {
    id: 2,
    name: "Engagement Makeup",
    description: "Elegant makeup for your engagement ceremony, designed to photograph beautifully.",
    price: 149,
    duration: "2-3 hours",
    image: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
    features: ["Consultation included", "HD makeup", "Contouring", "Eye makeup", "Lip color"]
  },
  {
    id: 3,
    name: "Mehendi & Sangeet",
    description: "Vibrant and colorful makeup perfect for pre-wedding celebrations and festivities.",
    price: 129,
    duration: "2 hours",
    image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
    features: ["Bright colors", "Glitter accents", "Waterproof formula", "Quick application", "Photo-ready"]
  },
  {
    id: 4,
    name: "Reception Glam",
    description: "Glamorous evening makeup for wedding reception, with bold eyes and lasting wear.",
    price: 179,
    duration: "3 hours",
    image: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
    features: ["Dramatic eyes", "Contouring", "Highlighting", "Long-lasting", "Touch-up included"]
  }
];

export const Services = () => {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="bg-pink-100 text-pink-600 mb-4">Our Services</Badge>
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Professional Bridal Makeup Services
          </h2>
          <p className="text-lg text-gray-600">
            From intimate ceremonies to grand celebrations, we create the perfect look for every moment of your special day.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8 mb-12">
          {services.map((service) => (
            <Card key={service.id} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden">
              <div className="relative">
                <img 
                  src={service.image} 
                  alt={service.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4">
                  <Badge className="bg-white/90 text-pink-600">
                    ${service.price}
                  </Badge>
                </div>
              </div>
              
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl text-gray-900">{service.name}</CardTitle>
                  <div className="flex items-center text-yellow-500">
                    <Star className="fill-current" size={16} />
                    <span className="text-sm ml-1">4.9</span>
                  </div>
                </div>
                <div className="flex items-center text-gray-500 text-sm">
                  <Clock size={16} className="mr-1" />
                  <span>{service.duration}</span>
                </div>
                <CardDescription className="text-gray-600">
                  {service.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-medium text-gray-900">Includes:</h4>
                    <ul className="space-y-1">
                      {service.features.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-gray-600">
                          <CheckCircle className="text-green-500 mr-2" size={14} />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Button className="w-full bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-600 hover:to-rose-500">
                    Book This Service
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Need a Custom Package?
          </h3>
          <p className="text-gray-600 mb-6">
            Every bride is unique. Let's create a personalized makeup package that perfectly fits your vision and budget.
          </p>
          <Button size="lg" className="bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-600 hover:to-rose-500">
            Get Custom Quote
          </Button>
        </div>
      </div>
    </section>
  );
};