import React from 'react';
import { TodoFilters } from '@/types';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { Filter, RotateCcw } from 'lucide-react';

interface TodoFiltersBarProps {
  filters: TodoFilters;
  onFiltersChange: (filters: TodoFilters) => void;
  categories: string[];
}

export const TodoFiltersBar: React.FC<TodoFiltersBarProps> = ({
  filters,
  onFiltersChange,
  categories
}) => {
  const resetFilters = () => {
    onFiltersChange({
      status: 'all',
      priority: 'all',
      category: 'all'
    });
  };

  const hasActiveFilters = filters.status !== 'all' || filters.priority !== 'all' || filters.category !== 'all';

  return (
    <Card className="p-4 bg-white/60 backdrop-blur-sm border-gray-200">
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-700">Filter by:</span>
        </div>

        <div className="flex flex-wrap items-center gap-3 flex-1">
          {/* Status Filter */}
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Status:</span>
            <div className="flex bg-gray-100 rounded-lg p-1">
              {(['all', 'active', 'completed'] as const).map((status) => (
                <Button
                  key={status}
                  variant={filters.status === status ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => onFiltersChange({ ...filters, status })}
                  className={`text-xs px-3 py-1 ${
                    filters.status === status 
                      ? 'bg-blue-500 text-white shadow-sm' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-white'
                  }`}
                >
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </Button>
              ))}
            </div>
          </div>

          {/* Priority Filter */}
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Priority:</span>
            <Select
              value={filters.priority}
              onValueChange={(value) => onFiltersChange({ ...filters, priority: value as any })}
            >
              <SelectTrigger className="w-28 h-8 text-xs border-gray-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="high">
                  <span className="flex items-center">
                    <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                    High
                  </span>
                </SelectItem>
                <SelectItem value="medium">
                  <span className="flex items-center">
                    <span className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></span>
                    Medium
                  </span>
                </SelectItem>
                <SelectItem value="low">
                  <span className="flex items-center">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                    Low
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Category Filter */}
          {categories.length > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Category:</span>
              <Select
                value={filters.category}
                onValueChange={(value) => onFiltersChange({ ...filters, category: value })}
              >
                <SelectTrigger className="w-32 h-8 text-xs border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {hasActiveFilters && (
          <Button
            variant="outline"
            size="sm"
            onClick={resetFilters}
            className="text-xs text-gray-600 hover:text-gray-900 border-gray-200"
          >
            <RotateCcw className="w-3 h-3 mr-1" />
            Reset
          </Button>
        )}
      </div>
    </Card>
  );
};