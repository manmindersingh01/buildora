import React from 'react';
import { TodoStats } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Circle, AlertTriangle, BarChart3 } from 'lucide-react';

interface TodoStatsProps {
  stats: TodoStats;
}

const TodoStatsComponent: React.FC<TodoStatsProps> = ({ stats }) => {
  const completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
  
  const statItems = [
    {
      icon: BarChart3,
      label: 'Total Tasks',
      value: stats.total,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      icon: CheckCircle,
      label: 'Completed',
      value: stats.completed,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      icon: Circle,
      label: 'Active',
      value: stats.active,
      color: 'text-gray-600',
      bgColor: 'bg-gray-100'
    },
    {
      icon: AlertTriangle,
      label: 'Overdue',
      value: stats.overdue,
      color: 'text-red-600',
      bgColor: 'bg-red-100'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      {statItems.map((item, index) => {
        const Icon = item.icon;
        return (
          <Card key={index} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${item.bgColor}`}>
                  <Icon className={`w-5 h-5 ${item.color}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{item.value}</p>
                  <p className="text-sm text-gray-600">{item.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
      
      {/* Completion Rate */}
      {stats.total > 0 && (
        <Card className="md:col-span-4 hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Completion Rate</span>
              <span className="text-sm font-bold text-gray-900">{completionRate}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${completionRate}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>0%</span>
              <span>100%</span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default TodoStatsComponent;