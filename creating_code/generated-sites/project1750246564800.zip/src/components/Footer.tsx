import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Heart, Phone, Mail, MapPin, Facebook, Instagram, Star } from 'lucide-react';

export const Footer = () => {
  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'Portfolio', href: '#portfolio' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' }
  ];

  const services = [
    'Bridal Makeup',
    'Engagement Makeup',
    'Reception Glam',
    'Mehendi & Sangeet',
    'Trial Sessions',
    'Group Bookings'
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        {/* Main Footer Content */}
        <div className="py-16 grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-rose-400 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">B</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">Bella Bridal</h3>
                <p className="text-sm text-pink-400">Makeup Artistry</p>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Professional bridal makeup services that enhance your natural beauty and make your special day unforgettable.
            </p>
            <div className="flex items-center space-x-1 text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="fill-current" size={16} />
              ))}
              <span className="ml-2 text-sm text-gray-300">4.9/5 from 200+ reviews</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="text-gray-300 hover:text-pink-400 transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Services</h4>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service}>
                  <span className="text-gray-300">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-semibold mb-6">Get In Touch</h4>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone size={16} className="text-pink-400" />
                  <span className="text-gray-300 text-sm">(555) 123-4567</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail size={16} className="text-pink-400" />
                  <span className="text-gray-300 text-sm">hello@bellabridal.com</span>
                </div>
                <div className="flex items-start space-x-3">
                  <MapPin size={16} className="text-pink-400 mt-0.5" />
                  <span className="text-gray-300 text-sm">123 Main Street<br />City, State 12345</span>
                </div>
              </div>
            </div>

            {/* Newsletter */}
            <div>
              <h5 className="font-semibold mb-3">Stay Updated</h5>
              <p className="text-gray-300 text-sm mb-3">
                Get beauty tips and special offers
              </p>
              <div className="flex space-x-2">
                <Input 
                  placeholder="Your email" 
                  className="bg-gray-800 border-gray-700 text-white placeholder-gray-400"
                />
                <Button className="bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-600 hover:to-rose-500">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-gray-800 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-1 text-gray-300">
              <span>Made with</span>
              <Heart className="text-pink-400 fill-current" size={16} />
              <span>© 2024 Bella Bridal. All rights reserved.</span>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-4">
                <Button size="sm" variant="ghost" className="text-gray-300 hover:text-pink-400">
                  <Facebook size={20} />
                </Button>
                <Button size="sm" variant="ghost" className="text-gray-300 hover:text-pink-400">
                  <Instagram size={20} />
                </Button>
              </div>
              
              <div className="flex items-center space-x-4 text-sm text-gray-400">
                <a href="#" className="hover:text-pink-400 transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-pink-400 transition-colors">Terms of Service</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};