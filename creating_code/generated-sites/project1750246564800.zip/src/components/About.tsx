import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Award, Users, Calendar } from 'lucide-react';

const achievements = [
  {
    icon: Award,
    title: "Certified Professional",
    description: "Certified makeup artist with advanced training in bridal artistry"
  },
  {
    icon: Users,
    title: "500+ Happy Brides",
    description: "Successfully created stunning looks for over 500 brides"
  },
  {
    icon: Calendar,
    title: "5+ Years Experience",
    description: "Half a decade of experience in bridal makeup industry"
  }
];

const skills = [
  "HD Bridal Makeup",
  "Airbrush Techniques",
  "Traditional & Modern Styles",
  "Color Theory & Skin Analysis",
  "Long-lasting Formulations",
  "Photography-ready Looks"
];

export const About = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-br from-pink-50 to-rose-50">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div>
              <Badge className="bg-pink-100 text-pink-600 mb-4">About Me</Badge>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Creating Beauty, One Bride at a Time
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                Hello! I'm Sarah, the founder and lead makeup artist at Bella Bridal. With over 5 years of experience in bridal makeup artistry, I specialize in creating stunning, long-lasting looks that enhance your natural beauty and make you feel absolutely radiant on your special day.
              </p>
              <p className="text-gray-600 leading-relaxed">
                My passion lies in understanding each bride's unique style and vision, then bringing it to life with professional techniques and premium products. Every bride deserves to feel like the most beautiful version of herself.
              </p>
            </div>

            {/* Skills */}
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Expertise & Skills</h3>
              <div className="grid grid-cols-2 gap-3">
                {skills.map((skill, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <CheckCircle className="text-pink-500" size={16} />
                    <span className="text-gray-600 text-sm">{skill}</span>
                  </div>
                ))}
              </div>
            </div>

            <Button size="lg" className="bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-600 hover:to-rose-500">
              Schedule Consultation
            </Button>
          </div>

          {/* Image & Achievements */}
          <div className="space-y-8">
            {/* Profile Image */}
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1559599101-f09722fb4948?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Sarah - Professional Makeup Artist"
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-lg p-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-pink-600">4.9★</div>
                  <div className="text-sm text-gray-600">200+ Reviews</div>
                </div>
              </div>
            </div>

            {/* Achievements */}
            <div className="space-y-4">
              {achievements.map((achievement, index) => {
                const IconComponent = achievement.icon;
                return (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <div className="bg-pink-100 rounded-lg p-2">
                          <IconComponent className="text-pink-600" size={20} />
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">
                            {achievement.title}
                          </h4>
                          <p className="text-sm text-gray-600">
                            {achievement.description}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>

        {/* Mission Statement */}
        <div className="mt-16 text-center bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            My Mission
          </h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            To make every bride feel confident, beautiful, and radiant on their wedding day through expert makeup artistry, personalized service, and attention to detail that exceeds expectations.
          </p>
        </div>
      </div>
    </section>
  );
};