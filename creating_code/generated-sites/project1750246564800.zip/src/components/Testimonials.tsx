import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Quote } from 'lucide-react';
import { Testimonial } from '@/types';

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Priya Sharma",
    rating: 5,
    comment: "Absolutely stunning work! The makeup lasted all day and looked flawless in every photo. Highly recommend for any bride looking for perfection.",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b77c?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    service: "Bridal Makeup Package"
  },
  {
    id: 2,
    name: "Anita Patel",
    rating: 5,
    comment: "The team was professional, punctual, and incredibly talented. They understood my vision perfectly and created the exact look I dreamed of.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    service: "Reception Glam"
  },
  {
    id: 3,
    name: "Meera Singh",
    rating: 5,
    comment: "From trial to wedding day, everything was perfect. The makeup enhanced my natural features beautifully. I felt like a princess!",
    image: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    service: "Engagement Makeup"
  }
];

export const Testimonials = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="bg-pink-100 text-pink-600 mb-4">Testimonials</Badge>
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            What Our Brides Say
          </h2>
          <p className="text-lg text-gray-600">
            Don't just take our word for it. Here's what our beautiful brides have to say about their experience with us.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 relative overflow-hidden">
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 text-pink-200">
                <Quote size={32} />
              </div>
              
              <CardContent className="p-6">
                {/* Rating */}
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="fill-yellow-400 text-yellow-400" size={16} />
                  ))}
                </div>
                
                {/* Comment */}
                <p className="text-gray-600 mb-6 leading-relaxed">
                  "{testimonial.comment}"
                </p>
                
                {/* Service Badge */}
                <Badge className="bg-pink-100 text-pink-600 mb-4">
                  {testimonial.service}
                </Badge>
                
                {/* Author */}
                <div className="flex items-center">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">Happy Bride</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom Stats */}
        <div className="mt-16 bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-pink-600 mb-2">500+</div>
              <div className="text-gray-600">Happy Brides</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-pink-600 mb-2">4.9</div>
              <div className="text-gray-600">Average Rating</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-pink-600 mb-2">200+</div>
              <div className="text-gray-600">Reviews</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-pink-600 mb-2">100%</div>
              <div className="text-gray-600">Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};