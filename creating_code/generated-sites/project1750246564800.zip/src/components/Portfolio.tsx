import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';
import { Portfolio as PortfolioType } from '@/types';

const portfolioItems: PortfolioType[] = [
  {
    id: 1,
    title: "Classic Elegance",
    image: "https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    category: "Bridal",
    description: "Timeless bridal look with soft glam"
  },
  {
    id: 2,
    title: "Bollywood Glam",
    image: "https://images.unsplash.com/photo-1594736797933-d0f02aad7d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    category: "Reception",
    description: "Bold and dramatic evening look"
  },
  {
    id: 3,
    title: "Natural Radiance",
    image: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    category: "Engagement",
    description: "Fresh and natural engagement makeup"
  },
  {
    id: 4,
    title: "Traditional Beauty",
    image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    category: "Mehendi",
    description: "Vibrant traditional ceremony look"
  },
  {
    id: 5,
    title: "Soft Romance",
    image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    category: "Bridal",
    description: "Romantic bridal makeup with soft tones"
  },
  {
    id: 6,
    title: "Royal Elegance",
    image: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    category: "Reception",
    description: "Regal and sophisticated reception look"
  }
];

const categories = ['All', 'Bridal', 'Reception', 'Engagement', 'Mehendi'];

export const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [hoveredItem, setHoveredItem] = useState<number | null>(null);

  const filteredItems = activeCategory === 'All' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activeCategory);

  return (
    <section id="portfolio" className="py-20 bg-gradient-to-br from-gray-50 to-pink-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="bg-pink-100 text-pink-600 mb-4">Our Work</Badge>
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Bridal Makeup Portfolio
          </h2>
          <p className="text-lg text-gray-600">
            Discover our stunning collection of bridal transformations. Each look is carefully crafted to enhance natural beauty and create unforgettable moments.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeCategory === category 
                  ? 'bg-gradient-to-r from-pink-500 to-rose-400 text-white shadow-lg' 
                  : 'border-pink-200 text-pink-600 hover:bg-pink-50'
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {filteredItems.map((item) => (
            <div 
              key={item.id} 
              className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer"
              onMouseEnter={() => setHoveredItem(item.id)}
              onMouseLeave={() => setHoveredItem(null)}
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              
              {/* Overlay */}
              <div className={`absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent transition-opacity duration-300 ${
                hoveredItem === item.id ? 'opacity-100' : 'opacity-0'
              }`}>
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  <Badge className="bg-white/20 text-white mb-2">
                    {item.category}
                  </Badge>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-sm text-white/90 mb-4">{item.description}</p>
                  <Button size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30">
                    <Eye size={16} className="mr-2" />
                    View Details
                  </Button>
                </div>
              </div>
              
              {/* Category Badge */}
              <div className="absolute top-4 left-4">
                <Badge className="bg-white/90 text-pink-600">
                  {item.category}
                </Badge>
              </div>
            </div>
          ))}
        </div>

        {/* Load More Button */}
        <div className="text-center">
          <Button 
            size="lg" 
            variant="outline" 
            className="border-pink-300 text-pink-600 hover:bg-pink-50 px-8"
          >
            View More Work
          </Button>
        </div>
      </div>
    </section>
  );
};