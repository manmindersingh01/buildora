import { Button } from '@/components/ui/button';
import { Star, Calendar, Heart } from 'lucide-react';

export const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center bg-gradient-to-br from-pink-50 via-rose-50 to-purple-50 pt-20">
      <div className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-pink-600">
                <Star className="fill-current" size={20} />
                <span className="text-sm font-medium">Award-Winning Makeup Artist</span>
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Your Perfect
                <span className="bg-gradient-to-r from-pink-500 to-rose-400 bg-clip-text text-transparent block">
                  Bridal Look
                </span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Transform your special day with stunning bridal makeup that enhances your natural beauty. Professional artistry for the most important day of your life.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 py-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-600">500+</div>
                <div className="text-sm text-gray-600">Happy Brides</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-600">5+</div>
                <div className="text-sm text-gray-600">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-600">4.9</div>
                <div className="text-sm text-gray-600">Rating</div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-600 hover:to-rose-500 text-white px-8 py-3"
              >
                <Calendar className="mr-2" size={20} />
                Book Free Consultation
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-pink-300 text-pink-600 hover:bg-pink-50 px-8 py-3"
              >
                View Portfolio
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center space-x-6 pt-6">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="fill-yellow-400 text-yellow-400" size={16} />
                ))}
                <span className="ml-2 text-sm text-gray-600">4.9/5 from 200+ reviews</span>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="relative z-10">
              <img 
                src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
                alt="Beautiful bride with professional makeup"
                className="rounded-2xl shadow-2xl w-full"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-72 h-72 bg-gradient-to-r from-pink-200 to-rose-200 rounded-full -z-10 opacity-50"></div>
            <div className="absolute -bottom-6 -left-6 w-48 h-48 bg-gradient-to-r from-purple-200 to-pink-200 rounded-full -z-10 opacity-50"></div>
            
            {/* Floating elements */}
            <div className="absolute top-10 -left-6 bg-white rounded-xl shadow-lg p-4 animate-pulse">
              <div className="flex items-center space-x-2">
                <Heart className="text-pink-500 fill-current" size={20} />
                <span className="text-sm font-medium">Perfect Match!</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};