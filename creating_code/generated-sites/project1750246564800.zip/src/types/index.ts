export interface Service {
  id: number;
  name: string;
  description: string;
  price: number;
  duration: string;
  image: string;
  features: string[];
}

export interface Testimonial {
  id: number;
  name: string;
  rating: number;
  comment: string;
  image: string;
  service: string;
}

export interface Portfolio {
  id: number;
  title: string;
  image: string;
  category: string;
  description: string;
}

export interface ContactForm {
  name: string;
  email: string;
  phone: string;
  eventDate: string;
  service: string;
  message: string;
}