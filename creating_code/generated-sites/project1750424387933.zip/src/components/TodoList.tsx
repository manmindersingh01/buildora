import React from 'react';
import { Todo } from '@/types';
import { TodoItem } from '@/components/TodoItem';
import { Card } from '@/components/ui/card';
import { Inbox } from 'lucide-react';

interface TodoListProps {
  todos: Todo[];
  onUpdate: (id: string, updates: Partial<Todo>) => void;
  onDelete: (id: string) => void;
}

export const TodoList: React.FC<TodoListProps> = ({ todos, onUpdate, onDelete }) => {
  if (!todos || todos.length === 0) {
    return (
      <Card className="p-12 text-center border-0 shadow-lg">
        <Inbox className="w-16 h-16 mx-auto text-gray-300 mb-4" />
        <p className="text-gray-500 text-lg">No tasks yet. Create your first task above!</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onUpdate={onUpdate}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
};