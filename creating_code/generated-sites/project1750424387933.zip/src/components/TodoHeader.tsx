import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';

export const TodoHeader: React.FC = () => {
  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <header className="text-center py-8">
      <div className="flex items-center justify-center gap-3 mb-4">
        <CheckCircle className="w-12 h-12 text-purple-600" />
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          TaskMaster Pro
        </h1>
      </div>
      <p className="text-gray-600 text-lg flex items-center justify-center gap-2">
        <Calendar className="w-5 h-5" />
        {today}
      </p>
    </header>
  );
};