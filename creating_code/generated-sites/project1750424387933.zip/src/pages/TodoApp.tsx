import React, { useState, useEffect, useMemo } from 'react';
import { Todo, TodoFilter, TodoStats } from '@/types';
import { TodoHeader } from '@/components/TodoHeader';
import { TodoForm } from '@/components/TodoForm';
import { TodoList } from '@/components/TodoList';
import { TodoFilters } from '@/components/TodoFilters';
import { TodoStats as StatsComponent } from '@/components/TodoStats';
import { useTodos } from '@/hooks/useTodos';
import { Loader } from 'lucide-react';

const TodoApp: React.FC = () => {
  const { todos, loading, error, addTodo, updateTodo, deleteTodo } = useTodos();
  const [filter, setFilter] = useState<TodoFilter>({
    status: 'all',
    priority: 'all',
    searchTerm: ''
  });

  const filteredTodos = useMemo(() => {
    if (!todos || todos.length === 0) return [];
    
    return todos.filter(todo => {
      // Status filter
      if (filter.status === 'active' && todo.completed) return false;
      if (filter.status === 'completed' && !todo.completed) return false;
      
      // Priority filter
      if (filter.priority !== 'all' && todo.priority !== filter.priority) return false;
      
      // Search filter
      if (filter.searchTerm) {
        const searchLower = filter.searchTerm.toLowerCase();
        return (
          todo.title.toLowerCase().includes(searchLower) ||
          (todo.description && todo.description.toLowerCase().includes(searchLower))
        );
      }
      
      return true;
    });
  }, [todos, filter]);

  const stats: TodoStats = useMemo(() => {
    const now = new Date();
    return {
      total: todos.length,
      completed: todos.filter(todo => todo.completed).length,
      active: todos.filter(todo => !todo.completed).length,
      overdue: todos.filter(todo => 
        !todo.completed && todo.dueDate && new Date(todo.dueDate) < now
      ).length
    };
  }, [todos]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 flex items-center justify-center">
        <Loader className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <TodoHeader />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          <div className="lg:col-span-2 space-y-6">
            <TodoForm onSubmit={addTodo} />
            <TodoFilters filter={filter} onFilterChange={setFilter} />
            <TodoList 
              todos={filteredTodos}
              onUpdate={updateTodo}
              onDelete={deleteTodo}
            />
          </div>
          
          <div className="lg:col-span-1">
            <StatsComponent stats={stats} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TodoApp;