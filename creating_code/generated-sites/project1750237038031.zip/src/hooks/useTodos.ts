import { useState, useEffect, useCallback } from 'react';
import { Todo, TodoFilter, TodoStats } from '@/types';
import { v4 as uuidv4 } from 'uuid';

const STORAGE_KEY = 'todos-app-data';

export const useTodos = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [filter, setFilter] = useState<TodoFilter>({
    status: 'all',
    sortBy: 'createdAt',
    sortOrder: 'desc'
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Load todos from localStorage on mount
  useEffect(() => {
    try {
      const savedData = localStorage.getItem(STORAGE_KEY);
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        setTodos(parsedData.todos || []);
        setFilter({ ...filter, ...parsedData.filter });
        setSearchQuery(parsedData.searchQuery || '');
      }
    } catch (error) {
      console.error('Error loading todos from localStorage:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Save todos to localStorage whenever todos, filter, or searchQuery changes
  useEffect(() => {
    if (!isLoading) {
      try {
        const dataToSave = {
          todos,
          filter,
          searchQuery
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
      } catch (error) {
        console.error('Error saving todos to localStorage:', error);
      }
    }
  }, [todos, filter, searchQuery, isLoading]);

  const addTodo = useCallback((todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newTodo: Todo = {
      ...todoData,
      id: uuidv4(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setTodos(prev => [newTodo, ...prev]);
  }, []);

  const updateTodo = useCallback((id: string, updates: Partial<Todo>) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id 
        ? { ...todo, ...updates, updatedAt: new Date() }
        : todo
    ));
  }, []);

  const deleteTodo = useCallback((id: string) => {
    setTodos(prev => prev.filter(todo => todo.id !== id));
  }, []);

  const toggleTodo = useCallback((id: string) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id 
        ? { ...todo, completed: !todo.completed, updatedAt: new Date() }
        : todo
    ));
  }, []);

  // Filter and sort todos
  const filteredTodos = useCallback(() => {
    let result = [...todos];

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      result = result.filter(todo => 
        todo.title.toLowerCase().includes(query) ||
        (todo.description && todo.description.toLowerCase().includes(query)) ||
        todo.category.toLowerCase().includes(query)
      );
    }

    // Apply status filter
    if (filter.status !== 'all') {
      result = result.filter(todo => 
        filter.status === 'completed' ? todo.completed : !todo.completed
      );
    }

    // Apply priority filter
    if (filter.priority) {
      result = result.filter(todo => todo.priority === filter.priority);
    }

    // Apply category filter
    if (filter.category) {
      result = result.filter(todo => todo.category === filter.category);
    }

    // Apply sorting
    result.sort((a, b) => {
      let comparison = 0;
      
      switch (filter.sortBy) {
        case 'title':
          comparison = a.title.localeCompare(b.title);
          break;
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          comparison = priorityOrder[b.priority] - priorityOrder[a.priority];
          break;
        case 'dueDate':
          if (!a.dueDate && !b.dueDate) comparison = 0;
          else if (!a.dueDate) comparison = 1;
          else if (!b.dueDate) comparison = -1;
          else comparison = new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
          break;
        case 'createdAt':
        default:
          comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          break;
      }
      
      return filter.sortOrder === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [todos, filter, searchQuery]);

  // Get unique categories
  const categories = useCallback(() => {
    const uniqueCategories = [...new Set(todos.map(todo => todo.category))];
    const defaultCategories = ['Work', 'Personal', 'Shopping', 'Health', 'General'];
    
    return [...new Set([...defaultCategories, ...uniqueCategories])].sort();
  }, [todos]);

  // Calculate statistics
  const stats = useCallback((): TodoStats => {
    const now = new Date();
    const overdue = todos.filter(todo => 
      !todo.completed && 
      todo.dueDate && 
      new Date(todo.dueDate) < now
    ).length;
    
    return {
      total: todos.length,
      completed: todos.filter(todo => todo.completed).length,
      active: todos.filter(todo => !todo.completed).length,
      overdue
    };
  }, [todos]);

  return {
    todos: filteredTodos(),
    allTodos: todos,
    filter,
    searchQuery,
    isLoading,
    categories: categories(),
    stats: stats(),
    setFilter,
    setSearchQuery,
    addTodo,
    updateTodo,
    deleteTodo,
    toggleTodo
  };
};