import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';

export const TodoHeader: React.FC = () => {
  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="text-center mb-8">
      <div className="flex items-center justify-center mb-4">
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-full">
          <CheckCircle className="w-8 h-8 text-white" />
        </div>
      </div>
      <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
        My Todo App
      </h1>
      <div className="flex items-center justify-center text-gray-600 text-sm">
        <Calendar className="w-4 h-4 mr-2" />
        <span>{currentDate}</span>
      </div>
    </div>
  );
};