import React from 'react';
import { Todo } from '@/types';
import { TodoItem } from '@/components/TodoItem';
import { Card } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';

interface TodoListProps {
  todos: Todo[];
  onToggleComplete: (id: string) => void;
  onEdit: (todo: Todo) => void;
  onDelete: (id: string) => void;
}

export const TodoList: React.FC<TodoListProps> = ({
  todos,
  onToggleComplete,
  onEdit,
  onDelete
}) => {
  if (todos.length === 0) {
    return (
      <Card className="p-12 text-center border-dashed border-2 border-gray-200">
        <div className="flex flex-col items-center space-y-4">
          <div className="bg-gray-100 p-4 rounded-full">
            <CheckCircle className="w-8 h-8 text-gray-400" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-600 mb-2">
              No todos found
            </h3>
            <p className="text-gray-400 text-sm">
              Create your first todo to get started!
            </p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggleComplete={onToggleComplete}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
};