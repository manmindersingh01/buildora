import React from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MapPin, Heart, Star, Zap } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-purple-900 via-purple-800 to-pink-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <h2 className="text-3xl font-black mb-4">
              FRESH<span className="bg-gradient-to-r from-yellow-400 to-pink-400 bg-clip-text text-transparent">FIT</span>
            </h2>
            <p className="text-white/80 mb-6 max-w-md">
              Where Gen-Z meets fresh style. We're not just selling tees, we're creating a vibe that hits different. Stay fresh, stay you. 💯
            </p>
            <div className="flex space-x-4">
              <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white hover:text-purple-900 rounded-full">
                <Heart className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white hover:text-purple-900 rounded-full">
                <Star className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white hover:text-purple-900 rounded-full">
                <Zap className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-6 text-yellow-300">Quick Links</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-white/80 hover:text-yellow-300 transition-colors font-medium">Shop All</a></li>
              <li><a href="#" className="text-white/80 hover:text-yellow-300 transition-colors font-medium">New Drops</a></li>
              <li><a href="#" className="text-white/80 hover:text-yellow-300 transition-colors font-medium">Trending</a></li>
              <li><a href="#" className="text-white/80 hover:text-yellow-300 transition-colors font-medium">Size Guide</a></li>
              <li><a href="#" className="text-white/80 hover:text-yellow-300 transition-colors font-medium">Returns</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-6 text-yellow-300">Get in Touch</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-cyan-400" />
                <span className="text-white/80">hello@freshfit.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-cyan-400" />
                <span className="text-white/80">+1 (555) FRESH-FIT</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-cyan-400" />
                <span className="text-white/80">Los Angeles, CA</span>
              </div>
            </div>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mt-12 pt-8 border-t border-white/20">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Stay in the Loop ✨</h3>
            <p className="text-white/80 mb-6">Get early access to new drops and exclusive deals</p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 px-4 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/30 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
              <Button className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold px-6 py-3 rounded-full">
                Subscribe 🚀
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-white/20 text-center">
          <p className="text-white/60">
            © 2024 FreshFit. Made with 💜 for the culture. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}