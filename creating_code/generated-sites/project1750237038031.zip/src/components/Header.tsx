import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, ShoppingBag, User, Search, Heart } from 'lucide-react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-2xl md:text-3xl font-black text-white">
              FRESH<span className="bg-gradient-to-r from-yellow-400 to-pink-400 bg-clip-text text-transparent">FIT</span>
            </h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Home</a>
            <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Shop</a>
            <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Categories</a>
            <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">About</a>
            <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Contact</a>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <Button size="sm" variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
              <Search className="w-5 h-5" />
            </Button>
            <Button size="sm" variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
              <Heart className="w-5 h-5" />
            </Button>
            <Button size="sm" variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
              <User className="w-5 h-5" />
            </Button>
            <Button size="sm" className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold">
              <ShoppingBag className="w-4 h-4 mr-2" />
              Cart
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button 
            size="sm" 
            variant="ghost" 
            className="md:hidden text-white hover:text-yellow-300 hover:bg-white/10"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-white/20">
            <nav className="flex flex-col space-y-4">
              <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Home</a>
              <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Shop</a>
              <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Categories</a>
              <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">About</a>
              <a href="#" className="text-white hover:text-yellow-300 font-bold transition-colors">Contact</a>
            </nav>
            <div className="flex items-center space-x-4 mt-4 pt-4 border-t border-white/20">
              <Button size="sm" variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
                <Search className="w-5 h-5" />
              </Button>
              <Button size="sm" variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
                <Heart className="w-5 h-5" />
              </Button>
              <Button size="sm" variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
                <User className="w-5 h-5" />
              </Button>
              <Button size="sm" className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold flex-1">
                <ShoppingBag className="w-4 h-4 mr-2" />
                Cart
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}