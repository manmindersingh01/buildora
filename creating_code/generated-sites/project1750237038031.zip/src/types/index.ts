export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  isNew?: boolean;
  isTrending?: boolean;
  colors: string[];
  sizes: string[];
  description: string;
}

export interface CartItem {
  id: number;
  product: Product;
  quantity: number;
  size: string;
  color: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  image: string;
  description: string;
}

export interface Review {
  id: number;
  name: string;
  rating: number;
  comment: string;
  productId: number;
  avatar: string;
}