import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Star, ShoppingBag, Heart, Eye, Zap, Sparkles, Flame } from 'lucide-react';
import { Product, Category, Review } from '@/types';
import { ProductCard } from '@/components/ProductCard';
import { CategoryCard } from '@/components/CategoryCard';
import { ReviewCard } from '@/components/ReviewCard';
import axios from 'axios';

export default function Home() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHomeData();
  }, []);

  const fetchHomeData = async () => {
    try {
      // Mock data for demo purposes
      const mockProducts: Product[] = [
        {
          id: 1,
          name: "Vibe Check Tee",
          price: 29.99,
          image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
          category: "trendy",
          isNew: true,
          isTrending: true,
          colors: ["black", "white", "pink"],
          sizes: ["S", "M", "L", "XL"],
          description: "Express your mood with this iconic tee"
        },
        {
          id: 2,
          name: "No Cap Graphic Tee",
          price: 34.99,
          image: "https://images.unsplash.com/photo-1583743814966-8936f37f7ad3?w=400",
          category: "graphic",
          isTrending: true,
          colors: ["black", "navy", "purple"],
          sizes: ["S", "M", "L", "XL"],
          description: "Keeping it 100 with this fire design"
        },
        {
          id: 3,
          name: "Main Character Energy",
          price: 32.99,
          image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=400",
          category: "motivational",
          isNew: true,
          colors: ["white", "yellow", "cyan"],
          sizes: ["S", "M", "L", "XL"],
          description: "Step into your power with this empowering tee"
        },
        {
          id: 4,
          name: "Aesthetic Vibes Only",
          price: 28.99,
          image: "https://images.unsplash.com/photo-1562157873-818bc0726f68?w=400",
          category: "aesthetic",
          isTrending: true,
          colors: ["lavender", "mint", "peach"],
          sizes: ["S", "M", "L", "XL"],
          description: "Soft colors for soft vibes"
        }
      ];

      const mockCategories: Category[] = [
        {
          id: 1,
          name: "Trendy Fits",
          slug: "trendy",
          image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400",
          description: "The hottest styles rn"
        },
        {
          id: 2,
          name: "Graphic Tees",
          slug: "graphic",
          image: "https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=400",
          description: "Express yourself boldly"
        },
        {
          id: 3,
          name: "Motivational",
          slug: "motivational",
          image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400",
          description: "Positive vibes only"
        },
        {
          id: 4,
          name: "Aesthetic",
          slug: "aesthetic",
          image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400",
          description: "Soft girl/boy era"
        }
      ];

      const mockReviews: Review[] = [
        {
          id: 1,
          name: "Emma K.",
          rating: 5,
          comment: "This tee is literally everything! The quality is chef's kiss and the design is so unique.",
          productId: 1,
          avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b830?w=100"
        },
        {
          id: 2,
          name: "Jake M.",
          rating: 5,
          comment: "Got so many compliments wearing this. Definitely ordering more!",
          productId: 2,
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100"
        },
        {
          id: 3,
          name: "Zoe L.",
          rating: 5,
          comment: "The fit is perfect and the material is so soft. Obsessed!",
          productId: 3,
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100"
        }
      ];

      setFeaturedProducts(mockProducts);
      setCategories(mockCategories);
      setReviews(mockReviews);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching home data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-400 via-pink-500 to-cyan-400">
        <div className="text-white text-2xl font-bold animate-pulse">Loading the vibes...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-cyan-400">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-sm"></div>
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="mb-6 flex justify-center space-x-2">
            <Sparkles className="text-yellow-300 w-8 h-8 animate-pulse" />
            <Flame className="text-orange-400 w-8 h-8 animate-bounce" />
            <Zap className="text-cyan-300 w-8 h-8 animate-pulse" />
          </div>
          <h1 className="text-6xl md:text-8xl font-black text-white mb-6 leading-tight">
            STAY
            <span className="bg-gradient-to-r from-yellow-400 to-pink-400 bg-clip-text text-transparent"> FRESH</span>
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto font-medium">
            Serving looks that hit different 💯 Express your vibe with tees that understand the assignment
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold px-8 py-4 text-lg rounded-full transform hover:scale-105 transition-all duration-200 shadow-lg">
              Shop Now <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-purple-600 font-bold px-8 py-4 text-lg rounded-full transform hover:scale-105 transition-all duration-200">
              Explore Vibes <Eye className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-4 bg-white/10 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Find Your <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Aesthetic</span>
            </h2>
            <p className="text-xl text-white/80">Different moods, different fits ✨</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.length > 0 && categories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-4 py-2 text-sm font-bold mb-4">
              🔥 TRENDING NOW
            </Badge>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Fits That <span className="bg-gradient-to-r from-yellow-400 to-pink-400 bg-clip-text text-transparent">Slap</span>
            </h2>
            <p className="text-xl text-white/80">These tees are straight up iconic</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.length > 0 && featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              The <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Receipts</span>
            </h2>
            <p className="text-xl text-white/80">Don't just take our word for it 💅</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {reviews.length > 0 && reviews.map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-6xl font-black text-white mb-6">
            Ready to <span className="bg-gradient-to-r from-yellow-400 to-pink-400 bg-clip-text text-transparent">Glow Up</span>?
          </h2>
          <p className="text-xl text-white/80 mb-8">Join the squad and get exclusive drops first 🎯</p>
          <Button size="lg" className="bg-gradient-to-r from-cyan-400 to-purple-500 hover:from-cyan-500 hover:to-purple-600 text-white font-bold px-10 py-5 text-xl rounded-full transform hover:scale-105 transition-all duration-200 shadow-xl">
            Join the Vibe <ShoppingBag className="ml-2 w-6 h-6" />
          </Button>
        </div>
      </section>
    </div>
  );
}