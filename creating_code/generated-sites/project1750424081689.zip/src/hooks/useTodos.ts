import { useState, useEffect } from 'react';
import { Todo } from '@/types';
import axios from 'axios';

export const useTodos = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load todos from localStorage on mount
  useEffect(() => {
    const loadTodos = async () => {
      try {
        setLoading(true);
        // For demo purposes, using localStorage
        // In production, replace with actual API call
        const storedTodos = localStorage.getItem('todos');
        if (storedTodos) {
          setTodos(JSON.parse(storedTodos));
        } else {
          // Initialize with sample todos
          const sampleTodos: Todo[] = [
            {
              id: '1',
              title: 'Complete project documentation',
              description: 'Write comprehensive documentation for the new feature',
              completed: false,
              priority: 'high',
              dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
            {
              id: '2',
              title: 'Review pull requests',
              description: 'Check and approve pending PRs from team members',
              completed: false,
              priority: 'medium',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
            {
              id: '3',
              title: 'Update dependencies',
              description: 'Update npm packages to latest stable versions',
              completed: true,
              priority: 'low',
              createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
              updatedAt: new Date().toISOString(),
            },
          ];
          setTodos(sampleTodos);
          localStorage.setItem('todos', JSON.stringify(sampleTodos));
        }
      } catch (err) {
        setError('Failed to load todos');
        console.error('Error loading todos:', err);
      } finally {
        setLoading(false);
      }
    };

    loadTodos();
  }, []);

  // Save todos to localStorage whenever they change
  useEffect(() => {
    if (todos.length > 0 || localStorage.getItem('todos')) {
      localStorage.setItem('todos', JSON.stringify(todos));
    }
  }, [todos]);

  const addTodo = async (todoData: Omit<Todo, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newTodo: Todo = {
        ...todoData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      setTodos(prevTodos => [...prevTodos, newTodo]);
      
      // In production, make API call:
      // const response = await axios.post('/api/todos', todoData);
      // if (response.data.success) {
      //   setTodos(prevTodos => [...prevTodos, response.data.data]);
      // }
    } catch (err) {
      console.error('Error adding todo:', err);
      setError('Failed to add todo');
    }
  };

  const updateTodo = async (id: string, updates: Partial<Todo>) => {
    try {
      setTodos(prevTodos => 
        prevTodos.map(todo => 
          todo.id === id 
            ? { ...todo, ...updates, updatedAt: new Date().toISOString() }
            : todo
        )
      );
      
      // In production, make API call:
      // const response = await axios.put(`/api/todos/${id}`, updates);
      // if (response.data.success) {
      //   setTodos(prevTodos => 
      //     prevTodos.map(todo => 
      //       todo.id === id ? response.data.data : todo
      //     )
      //   );
      // }
    } catch (err) {
      console.error('Error updating todo:', err);
      setError('Failed to update todo');
    }
  };

  const deleteTodo = async (id: string) => {
    try {
      setTodos(prevTodos => prevTodos.filter(todo => todo.id !== id));
      
      // In production, make API call:
      // const response = await axios.delete(`/api/todos/${id}`);
      // if (response.data.success) {
      //   setTodos(prevTodos => prevTodos.filter(todo => todo.id !== id));
      // }
    } catch (err) {
      console.error('Error deleting todo:', err);
      setError('Failed to delete todo');
    }
  };

  return {
    todos,
    loading,
    error,
    addTodo,
    updateTodo,
    deleteTodo,
  };
};