import React, { useState, useEffect, useMemo } from 'react';
import { Todo, TodoFilter, TodoStats } from '@/types';
import { TodoHeader } from '@/components/TodoHeader';
import { TodoList } from '@/components/TodoList';
import { TodoStats as StatsComponent } from '@/components/TodoStats';
import { AddTodoDialog } from '@/components/AddTodoDialog';
import { useTodos } from '@/hooks/useTodos';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

export const TodoApp: React.FC = () => {
  const { todos, loading, addTodo, updateTodo, deleteTodo } = useTodos();
  const [filter, setFilter] = useState<TodoFilter>({
    status: 'all',
    priority: 'all',
    searchTerm: ''
  });

  const filteredTodos = useMemo(() => {
    let filtered = [...todos];

    // Filter by status
    if (filter.status !== 'all') {
      filtered = filtered.filter(todo => 
        filter.status === 'completed' ? todo.completed : !todo.completed
      );
    }

    // Filter by priority
    if (filter.priority && filter.priority !== 'all') {
      filtered = filtered.filter(todo => todo.priority === filter.priority);
    }

    // Filter by search term
    if (filter.searchTerm) {
      filtered = filtered.filter(todo => 
        todo.title.toLowerCase().includes(filter.searchTerm!.toLowerCase()) ||
        (todo.description && todo.description.toLowerCase().includes(filter.searchTerm!.toLowerCase()))
      );
    }

    // Sort by priority and due date
    filtered.sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      }
      if (a.dueDate && b.dueDate) {
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      return 0;
    });

    return filtered;
  }, [todos, filter]);

  const stats: TodoStats = useMemo(() => {
    const now = new Date();
    return {
      total: todos.length,
      completed: todos.filter(t => t.completed).length,
      active: todos.filter(t => !t.completed).length,
      overdue: todos.filter(t => 
        !t.completed && t.dueDate && new Date(t.dueDate) < now
      ).length
    };
  }, [todos]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <TodoHeader />
      
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <StatsComponent stats={stats} />
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Search todos..."
                className="pl-10"
                value={filter.searchTerm}
                onChange={(e) => setFilter({ ...filter, searchTerm: e.target.value })}
              />
            </div>
            <AddTodoDialog onAdd={addTodo} />
          </div>

          <Tabs value={filter.status} onValueChange={(value) => setFilter({ ...filter, status: value as TodoFilter['status'] })}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All ({stats.total})</TabsTrigger>
              <TabsTrigger value="active">Active ({stats.active})</TabsTrigger>
              <TabsTrigger value="completed">Completed ({stats.completed})</TabsTrigger>
            </TabsList>
            
            <TabsContent value={filter.status} className="mt-6">
              {loading ? (
                <div className="text-center py-12">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
                  <p className="mt-2 text-gray-500">Loading todos...</p>
                </div>
              ) : filteredTodos.length > 0 ? (
                <TodoList 
                  todos={filteredTodos}
                  onUpdate={updateTodo}
                  onDelete={deleteTodo}
                />
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">
                    {filter.searchTerm ? 'No todos found matching your search.' : 'No todos yet. Create your first todo!'}
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};