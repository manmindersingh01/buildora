import React, { useState } from 'react';
import { Todo } from '@/types';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { EditTodoDialog } from '@/components/EditTodoDialog';
import { Calendar, Clock, MoreVertical, Edit, Delete, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TodoItemProps {
  todo: Todo;
  onUpdate: (id: string, updates: Partial<Todo>) => void;
  onDelete: (id: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onUpdate, onDelete }) => {
  const [isEditOpen, setIsEditOpen] = useState(false);
  
  const isOverdue = todo.dueDate && new Date(todo.dueDate) < new Date() && !todo.completed;
  
  const priorityColors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800'
  };

  const handleToggleComplete = () => {
    onUpdate(todo.id, { completed: !todo.completed });
  };

  return (
    <>
      <Card className={cn(
        "transition-all duration-200 hover:shadow-md",
        todo.completed && "opacity-60",
        isOverdue && "border-red-300"
      )}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3 flex-1">
              <Checkbox
                checked={todo.completed}
                onCheckedChange={handleToggleComplete}
                className="mt-1"
              />
              <div className="flex-1">
                <CardTitle className={cn(
                  "text-lg",
                  todo.completed && "line-through text-gray-500"
                )}>
                  {todo.title}
                </CardTitle>
                {todo.description && (
                  <CardDescription className="mt-1">
                    {todo.description}
                  </CardDescription>
                )}
                <div className="flex items-center gap-4 mt-3">
                  <Badge className={priorityColors[todo.priority]}>
                    {todo.priority}
                  </Badge>
                  {todo.dueDate && (
                    <div className={cn(
                      "flex items-center gap-1 text-sm",
                      isOverdue ? "text-red-600" : "text-gray-500"
                    )}>
                      {isOverdue && <AlertCircle className="h-3 w-3" />}
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(todo.dueDate).toLocaleDateString()}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Clock className="h-3 w-3" />
                    <span>{new Date(todo.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setIsEditOpen(true)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => onDelete(todo.id)}
                  className="text-red-600"
                >
                  <Delete className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
      </Card>
      
      <EditTodoDialog
        todo={todo}
        open={isEditOpen}
        onOpenChange={setIsEditOpen}
        onUpdate={onUpdate}
      />
    </>
  );
};