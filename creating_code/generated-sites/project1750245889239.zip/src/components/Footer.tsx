import { Heart, Phone, Mail, MapPin, Calendar, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-b from-gray-900 to-black text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-r from-rose-500 to-purple-500 rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-white fill-current" />
              </div>
              <div>
                <h3 className="text-xl font-bold bg-gradient-to-r from-rose-400 to-purple-400 bg-clip-text text-transparent">
                  Bridal Bliss
                </h3>
                <p className="text-xs text-gray-400">Makeup Artistry</p>
              </div>
            </div>
            
            <p className="text-gray-300 leading-relaxed">
              Creating magical bridal transformations that make every bride feel like royalty on their special day.
            </p>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
              </div>
              <span className="text-sm text-gray-400">5.0 (500+ reviews)</span>
            </div>
          </div>
          
          {/* Services */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold text-white">Our Services</h4>
            <ul className="space-y-3">
              {[
                'Bridal Makeup',
                'Engagement Glam',
                'Reception Ready',
                'Mehendi Ceremony',
                'Trial Sessions',
                'Group Bookings'
              ].map((service) => (
                <li key={service}>
                  <a 
                    href="#" 
                    className="text-gray-300 hover:text-rose-400 transition-colors duration-200 flex items-center gap-2"
                  >
                    <div className="w-1.5 h-1.5 bg-rose-400 rounded-full"></div>
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact Info */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold text-white">Get in Touch</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-rose-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Phone className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-gray-300">+1 (555) 123-4567</p>
                  <p className="text-sm text-gray-400">Available 9 AM - 8 PM</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-rose-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Mail className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-gray-300">hello@bridalbliss.com</p>
                  <p className="text-sm text-gray-400">Quick response guaranteed</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-rose-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-gray-300">Downtown Beauty Studio</p>
                  <p className="text-sm text-gray-400">123 Bridal Avenue, City</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Quick Actions */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold text-white">Quick Actions</h4>
            <div className="space-y-4">
              <Button 
                className="w-full bg-gradient-to-r from-rose-500 to-purple-500 hover:from-rose-600 hover:to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Book Free Trial
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full border-rose-400 text-rose-400 hover:bg-rose-400/10 rounded-full"
              >
                View Portfolio
              </Button>
              
              <div className="bg-gradient-to-r from-rose-500/10 to-purple-500/10 p-4 rounded-xl border border-rose-500/20">
                <h5 className="font-semibold text-rose-400 mb-2">Special Offer</h5>
                <p className="text-sm text-gray-300 mb-3">Book your bridal package and get a free trial session!</p>
                <Button size="sm" className="bg-rose-500 hover:bg-rose-600 text-white rounded-full">
                  Claim Offer
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © 2024 Bridal Bliss Makeup Artistry. All rights reserved.
            </p>
            
            <div className="flex items-center gap-6">
              <a href="#" className="text-gray-400 hover:text-rose-400 text-sm transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-rose-400 text-sm transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-rose-400 text-sm transition-colors">
                Cancellation Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;