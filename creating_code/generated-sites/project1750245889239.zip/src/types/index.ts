export interface Service {
  id: string;
  name: string;
  description: string;
  price: string;
  duration: string;
  image: string;
  features: string[];
}

export interface Package {
  id: string;
  name: string;
  description: string;
  price: string;
  originalPrice?: string;
  services: string[];
  image: string;
  popular?: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  rating: number;
  comment: string;
  image: string;
  weddingDate: string;
}

export interface GalleryImage {
  id: string;
  url: string;
  alt: string;
  category: 'bridal' | 'engagement' | 'reception' | 'mehendi';
}

export interface BookingForm {
  name: string;
  email: string;
  phone: string;
  weddingDate: string;
  service: string;
  message: string;
}