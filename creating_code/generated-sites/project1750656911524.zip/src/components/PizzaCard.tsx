import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Pizza } from '@/types';
import { ShoppingCart, Star } from 'lucide-react';

interface PizzaCardProps {
  pizza: Pizza;
  onAddToCart: (pizza: Pizza) => void;
}

export const PizzaCard = ({ pizza, onAddToCart }: PizzaCardProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 group">
      <div className="relative overflow-hidden">
        <img 
          src={pizza.image} 
          alt={pizza.name}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <Badge 
          className="absolute top-2 right-2 bg-orange-500 hover:bg-orange-600"
          variant="secondary"
        >
          {pizza.category}
        </Badge>
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold text-lg text-gray-800">{pizza.name}</h3>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm text-gray-600">4.5</span>
          </div>
        </div>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{pizza.description}</p>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {pizza.ingredients.slice(0, 3).map((ingredient, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {ingredient}
            </Badge>
          ))}
          {pizza.ingredients.length > 3 && (
            <Badge variant="outline" className="text-xs">+{pizza.ingredients.length - 3} more</Badge>
          )}
        </div>
        
        <div className="flex items-center justify-between">
          <span className="font-bold text-xl text-orange-600">${pizza.price}</span>
          <Badge variant="secondary">{pizza.size}</Badge>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button 
          onClick={() => onAddToCart(pizza)}
          className="w-full bg-orange-500 hover:bg-orange-600 text-white"
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
};