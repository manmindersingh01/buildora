import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Navbar } from '@/components/Navbar';
import { PizzaCard } from '@/components/PizzaCard';
import { TestimonialCard } from '@/components/TestimonialCard';
import { Pizza, Testimonial } from '@/types';
import { 
  ArrowRight, 
  Clock, 
  Truck, 
  ChefHat, 
  Phone, 
  Mail, 
  MapPin,
  Star,
  Users,
  Award
} from 'lucide-react';

export const Home = () => {
  const [featuredPizzas, setFeaturedPizzas] = useState<Pizza[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call with mock data
    const fetchData = async () => {
      try {
        // Mock pizza data
        const mockPizzas: Pizza[] = [
          {
            id: '1',
            name: 'Margherita Supreme',
            description: 'Fresh mozzarella, basil, tomatoes on our signature crust',
            price: 16.99,
            image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400&h=300&fit=crop',
            category: 'classic',
            size: 'large',
            ingredients: ['Mozzarella', 'Basil', 'Tomatoes', 'Olive Oil']
          },
          {
            id: '2',
            name: 'Pepperoni Deluxe',
            description: 'Premium pepperoni with extra cheese and Italian herbs',
            price: 18.99,
            image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400&h=300&fit=crop',
            category: 'classic',
            size: 'large',
            ingredients: ['Pepperoni', 'Mozzarella', 'Italian Herbs', 'Tomato Sauce']
          },
          {
            id: '3',
            name: 'Veggie Garden',
            description: 'Fresh vegetables with vegan cheese on whole wheat base',
            price: 19.99,
            image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop',
            category: 'vegan',
            size: 'large',
            ingredients: ['Bell Peppers', 'Mushrooms', 'Olives', 'Vegan Cheese']
          }
        ];

        // Mock testimonials
        const mockTestimonials: Testimonial[] = [
          {
            id: '1',
            name: 'Sarah Johnson',
            rating: 5,
            comment: 'Best pizza in town! The crust is perfect and ingredients are always fresh.',
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b95b7c12?w=100&h=100&fit=crop&crop=face'
          },
          {
            id: '2',
            name: 'Mike Rodriguez',
            rating: 5,
            comment: 'Tony\'s Pizza never disappoints. Fast delivery and amazing taste every time!',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
          },
          {
            id: '3',
            name: 'Emily Chen',
            rating: 4,
            comment: 'Great variety of pizzas and excellent customer service. Highly recommended!',
            avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'
          }
        ];

        setFeaturedPizzas(mockPizzas);
        setTestimonials(mockTestimonials);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleAddToCart = (pizza: Pizza) => {
    console.log('Added to cart:', pizza);
    // Implement cart functionality
  };

  const stats = [
    { icon: Users, label: 'Happy Customers', value: '10,000+' },
    { icon: Award, label: 'Years of Excellence', value: '15+' },
    { icon: Star, label: 'Average Rating', value: '4.8' }
  ];

  const features = [
    {
      icon: Clock,
      title: 'Fast Delivery',
      description: 'Hot pizza delivered in 30 minutes or less'
    },
    {
      icon: ChefHat,
      title: 'Fresh Ingredients',
      description: 'Made with the finest, locally-sourced ingredients'
    },
    {
      icon: Truck,
      title: 'Free Delivery',
      description: 'Free delivery on orders over $25 in our area'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading delicious pizzas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <section id="home" className="relative bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="bg-white/20 text-white mb-4" variant="secondary">
                🔥 Hot & Fresh Daily
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                Authentic Italian
                <span className="block text-yellow-300">Pizza Experience</span>
              </h1>
              <p className="text-xl mb-8 text-gray-100 max-w-lg">
                Handcrafted pizzas made with love, using traditional recipes and the freshest ingredients. 
                Taste the difference that 15 years of passion makes.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-orange-600 hover:bg-gray-100">
                  <Phone className="w-5 h-5 mr-2" />
                  Order Now
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-orange-600">
                  View Menu
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
              
              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 mt-12">
                {stats.map((stat, index) => {
                  const IconComponent = stat.icon;
                  return (
                    <div key={index} className="text-center">
                      <IconComponent className="w-8 h-8 mx-auto mb-2 text-yellow-300" />
                      <div className="font-bold text-2xl">{stat.value}</div>
                      <div className="text-gray-200 text-sm">{stat.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div className="relative">
              <div className="relative z-10">
                <img 
                  src="https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&h=600&fit=crop" 
                  alt="Delicious Pizza"
                  className="rounded-full w-96 h-96 object-cover mx-auto shadow-2xl"
                />
              </div>
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-yellow-300 rounded-full opacity-20 animate-pulse"></div>
              <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-white rounded-full opacity-10 animate-pulse delay-1000"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Why Choose Tony's Pizza?
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              We're committed to delivering not just pizza, but an exceptional experience every time.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow duration-300 border-0 bg-gradient-to-br from-orange-50 to-red-50">
                  <CardContent className="pt-6">
                    <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="w-8 h-8 text-orange-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Pizzas Section */}
      <section id="menu" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="bg-orange-100 text-orange-800 mb-4" variant="secondary">
              🍕 Our Specialties
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Featured Pizzas
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Discover our most popular pizzas, crafted with care and bursting with flavor.
            </p>
          </div>
          
          {featuredPizzas.length > 0 && (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredPizzas.map((pizza) => (
                <PizzaCard 
                  key={pizza.id} 
                  pizza={pizza} 
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          )}
          
          <div className="text-center mt-12">
            <Button size="lg" className="bg-orange-500 hover:bg-orange-600">
              View Full Menu
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="bg-orange-100 text-orange-800 mb-4" variant="secondary">
                Our Story
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
                Bringing Italy to Your Table Since 2008
              </h2>
              <p className="text-gray-600 text-lg mb-6">
                Started by Tony Marcelli, our family-owned pizzeria has been serving authentic Italian 
                pizzas made with traditional recipes passed down through generations. Every pizza is 
                handcrafted with love and the finest ingredients.
              </p>
              <p className="text-gray-600 text-lg mb-8">
                From our wood-fired ovens to your table, we ensure every bite delivers the authentic 
                taste of Italy right here in your neighborhood.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Fresh Daily</h4>
                  <p className="text-gray-600 text-sm">Dough made fresh every morning</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Local Sourcing</h4>
                  <p className="text-gray-600 text-sm">Ingredients from local farms</p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop" 
                alt="Tony's Pizza Kitchen"
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-orange-500 text-white p-4 rounded-lg shadow-lg">
                <div className="text-2xl font-bold">15+</div>
                <div className="text-sm">Years of Excellence</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gradient-to-br from-orange-50 to-red-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              What Our Customers Say
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Don't just take our word for it - hear from our happy customers!
            </p>
          </div>
          
          {testimonials.length > 0 && (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial) => (
                <TestimonialCard key={testimonial.id} testimonial={testimonial} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gray-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Get in Touch
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Ready to order? Have questions? We're here to help!
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gray-700 border-gray-600 text-center">
              <CardContent className="pt-6">
                <Phone className="w-8 h-8 text-orange-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Call Us</h3>
                <p className="text-gray-300">(555) 123-PIZZA</p>
                <p className="text-sm text-gray-400 mt-2">Mon-Sun: 11AM - 11PM</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-700 border-gray-600 text-center">
              <CardContent className="pt-6">
                <MapPin className="w-8 h-8 text-orange-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Visit Us</h3>
                <p className="text-gray-300">123 Pizza Street</p>
                <p className="text-gray-300">Little Italy, NY 10013</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-700 border-gray-600 text-center">
              <CardContent className="pt-6">
                <Mail className="w-8 h-8 text-orange-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Email Us</h3>
                <p className="text-gray-300">hello@tonyspizza.com</p>
                <p className="text-sm text-gray-400 mt-2">We reply within 24 hours</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center mt-12">
            <Button size="lg" className="bg-orange-500 hover:bg-orange-600">
              <Phone className="w-5 h-5 mr-2" />
              Order Now: (555) 123-PIZZA
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold text-orange-400 mb-4">
                🍕 Tony's Pizza
              </div>
              <p className="text-gray-400 mb-4">
                Authentic Italian pizza made with love and the finest ingredients since 2008.
              </p>
              <div className="flex items-center text-sm text-gray-400">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                <span>4.8/5 based on 1,200+ reviews</span>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#home" className="hover:text-white transition-colors">Home</a></li>
                <li><a href="#menu" className="hover:text-white transition-colors">Menu</a></li>
                <li><a href="#about" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Menu Categories</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Classic Pizzas</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Specialty Pizzas</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Vegan Options</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Appetizers</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contact Info</h4>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  (555) 123-PIZZA
                </li>
                <li className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  hello@tonyspizza.com
                </li>
                <li className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  123 Pizza Street, NY
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Tony's Pizza. All rights reserved. Made with ❤️ and lots of cheese!</p>
          </div>
        </div>
      </footer>
    </div>
  );
};