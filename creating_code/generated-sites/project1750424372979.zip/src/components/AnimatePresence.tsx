import React from 'react';

interface AnimatePresenceProps {
  children: React.ReactNode;
}

export const AnimatePresence: React.FC<AnimatePresenceProps> = ({ children }) => {
  // Simple wrapper component that can be enhanced with animations later
  // For now, it just renders children with transition classes
  return (
    <div className="space-y-3">
      {React.Children.map(children, (child) => (
        <div className="transition-all duration-300 ease-in-out">
          {child}
        </div>
      ))}
    </div>
  );
};