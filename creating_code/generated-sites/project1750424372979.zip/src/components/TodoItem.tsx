import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Todo } from '@/types';
import { Edit, Delete, Check, X, Tag, Flag } from 'lucide-react';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onUpdate: (id: string, updates: Partial<Todo>) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onUpdate(todo.id, { text: editText });
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const priorityColors = {
    low: 'bg-green-100 text-green-800 border-green-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    high: 'bg-red-100 text-red-800 border-red-200'
  };

  return (
    <div
      className={`group p-4 bg-white border rounded-lg transition-all hover:shadow-md ${
        todo.completed ? 'opacity-75' : ''
      }`}
    >
      <div className="flex items-center gap-3">
        <Checkbox
          checked={todo.completed}
          onCheckedChange={() => onToggle(todo.id)}
          className="w-5 h-5"
        />

        <div className="flex-1">
          {isEditing ? (
            <div className="flex gap-2">
              <Input
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSave()}
                className="flex-1"
                autoFocus
              />
              <Button size="sm" onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                <Check className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline" onClick={handleCancel}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <div>
              <p className={`text-lg ${todo.completed ? 'line-through text-gray-500' : ''}`}>
                {todo.text}
              </p>
              <div className="flex items-center gap-4 mt-2">
                <span className="flex items-center gap-1 text-sm text-gray-500">
                  <Tag className="w-3 h-3" />
                  {todo.category}
                </span>
                <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full border ${priorityColors[todo.priority]}`}>
                  <Flag className="w-3 h-3" />
                  {todo.priority}
                </span>
              </div>
            </div>
          )}
        </div>

        {!isEditing && (
          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Select
              value={todo.priority}
              onValueChange={(value) => onUpdate(todo.id, { priority: value as Todo['priority'] })}
            >
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsEditing(true)}
            >
              <Edit className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onDelete(todo.id)}
              className="hover:bg-red-50 hover:text-red-600 hover:border-red-600"
            >
              <Delete className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};