import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { TodoFilter } from '@/types';
import { Filter, RefreshCw } from 'lucide-react';

interface TodoFiltersProps {
  filter: TodoFilter;
  setFilter: React.Dispatch<React.SetStateAction<TodoFilter>>;
}

export const TodoFilters: React.FC<TodoFiltersProps> = ({ filter, setFilter }) => {
  const categories = ['All', 'Work', 'Personal', 'Shopping', 'Health', 'General'];
  const priorities = ['All', 'low', 'medium', 'high'];

  const resetFilters = () => {
    setFilter({
      status: 'all',
      category: '',
      priority: ''
    });
  };

  return (
    <div className="flex flex-wrap items-center gap-3 mb-4 p-4 bg-gray-50 rounded-lg">
      <Filter className="w-5 h-5 text-gray-600" />
      
      <Select
        value={filter.category || 'All'}
        onValueChange={(value) => setFilter({ ...filter, category: value === 'All' ? '' : value })}
      >
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Category" />
        </SelectTrigger>
        <SelectContent>
          {categories.map((cat) => (
            <SelectItem key={cat} value={cat}>{cat}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={filter.priority || 'All'}
        onValueChange={(value) => setFilter({ ...filter, priority: value === 'All' ? '' : value })}
      >
        <SelectTrigger className="w-32">
          <SelectValue placeholder="Priority" />
        </SelectTrigger>
        <SelectContent>
          {priorities.map((priority) => (
            <SelectItem key={priority} value={priority}>
              {priority.charAt(0).toUpperCase() + priority.slice(1)}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Button
        variant="outline"
        size="sm"
        onClick={resetFilters}
        className="ml-auto"
      >
        <RefreshCw className="w-4 h-4 mr-1" />
        Reset
      </Button>
    </div>
  );
};