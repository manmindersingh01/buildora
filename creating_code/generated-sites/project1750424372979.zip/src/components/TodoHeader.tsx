import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';

export const TodoHeader: React.FC = () => {
  const today = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  return (
    <header className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <CheckCircle className="h-10 w-10" />
            <h1 className="text-3xl font-bold">TodoMaster</h1>
          </div>
          <div className="flex items-center space-x-2 text-indigo-100">
            <Calendar className="h-5 w-5" />
            <span className="text-sm">{today}</span>
          </div>
        </div>
        <p className="mt-2 text-indigo-100">Stay organized, stay productive</p>
      </div>
    </header>
  );
};