export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  createdAt: Date;
  priority: 'low' | 'medium' | 'high';
  category: string;
}

export interface TodoFilter {
  status: 'all' | 'active' | 'completed';
  category: string;
  priority: string;
}

export interface TodoStats {
  total: number;
  completed: number;
  active: number;
  highPriority: number;
}