import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TodoList } from '@/components/TodoList';
import { TodoStats } from '@/components/TodoStats';
import { TodoFilters } from '@/components/TodoFilters';
import { Todo, TodoFilter } from '@/types';
import { Plus, CheckCircle, ListTodo } from 'lucide-react';
import axios from 'axios';

const TodoApp: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [newTodo, setNewTodo] = useState('');
  const [filter, setFilter] = useState<TodoFilter>({
    status: 'all',
    category: '',
    priority: ''
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/todos');
      if (response.data.success) {
        setTodos(response.data.data || []);
      }
    } catch (error) {
      console.error('Error fetching todos:', error);
      // Initialize with sample data if API fails
      setTodos([
        {
          id: '1',
          text: 'Complete project documentation',
          completed: false,
          createdAt: new Date(),
          priority: 'high',
          category: 'Work'
        },
        {
          id: '2',
          text: 'Review pull requests',
          completed: true,
          createdAt: new Date(),
          priority: 'medium',
          category: 'Work'
        },
        {
          id: '3',
          text: 'Buy groceries',
          completed: false,
          createdAt: new Date(),
          priority: 'low',
          category: 'Personal'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const addTodo = async () => {
    if (!newTodo.trim()) return;

    const todo: Todo = {
      id: Date.now().toString(),
      text: newTodo,
      completed: false,
      createdAt: new Date(),
      priority: 'medium',
      category: 'General'
    };

    try {
      const response = await axios.post('/api/todos', todo);
      if (response.data.success) {
        setTodos([...todos, response.data.data]);
      }
    } catch (error) {
      // Fallback: add locally if API fails
      setTodos([...todos, todo]);
    }

    setNewTodo('');
  };

  const toggleTodo = async (id: string) => {
    const updatedTodos = todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    );
    setTodos(updatedTodos);

    try {
      await axios.put(`/api/todos/${id}/toggle`);
    } catch (error) {
      console.error('Error updating todo:', error);
    }
  };

  const deleteTodo = async (id: string) => {
    setTodos(todos.filter(todo => todo.id !== id));

    try {
      await axios.delete(`/api/todos/${id}`);
    } catch (error) {
      console.error('Error deleting todo:', error);
    }
  };

  const updateTodo = async (id: string, updates: Partial<Todo>) => {
    const updatedTodos = todos.map(todo =>
      todo.id === id ? { ...todo, ...updates } : todo
    );
    setTodos(updatedTodos);

    try {
      await axios.put(`/api/todos/${id}`, updates);
    } catch (error) {
      console.error('Error updating todo:', error);
    }
  };

  const filteredTodos = useMemo(() => {
    return todos.filter(todo => {
      if (filter.status === 'active' && todo.completed) return false;
      if (filter.status === 'completed' && !todo.completed) return false;
      if (filter.category && todo.category !== filter.category) return false;
      if (filter.priority && todo.priority !== filter.priority) return false;
      return true;
    });
  }, [todos, filter]);

  const stats = useMemo(() => ({
    total: todos.length,
    completed: todos.filter(t => t.completed).length,
    active: todos.filter(t => !t.completed).length,
    highPriority: todos.filter(t => t.priority === 'high' && !t.completed).length
  }), [todos]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <ListTodo className="w-10 h-10 text-indigo-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Todo Master
            </h1>
          </div>
          <p className="text-gray-600">Organize your tasks, boost your productivity</p>
        </header>

        <TodoStats stats={stats} />

        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex gap-2 mb-6">
            <Input
              type="text"
              placeholder="Add a new task..."
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addTodo()}
              className="flex-1 border-gray-200 focus:border-indigo-500 transition-colors"
            />
            <Button
              onClick={addTodo}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 transition-all transform hover:scale-105"
            >
              <Plus className="w-5 h-5 mr-1" />
              Add Task
            </Button>
          </div>

          <TodoFilters filter={filter} setFilter={setFilter} />

          <Tabs value={filter.status} onValueChange={(value) => setFilter({ ...filter, status: value as any })}>
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="all">All Tasks</TabsTrigger>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>

            <TabsContent value={filter.status} className="mt-0">
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
                </div>
              ) : filteredTodos.length > 0 ? (
                <TodoList
                  todos={filteredTodos}
                  onToggle={toggleTodo}
                  onDelete={deleteTodo}
                  onUpdate={updateTodo}
                />
              ) : (
                <div className="text-center py-12">
                  <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No tasks found. Add one to get started!</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>

        <footer className="text-center text-gray-500 text-sm">
          <p>© 2024 Todo Master. Stay organized, stay productive.</p>
        </footer>
      </div>
    </div>
  );
};

export default TodoApp;