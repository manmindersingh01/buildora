import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Star, ShoppingBag, Heart, Zap, Trophy, Palette } from 'lucide-react';
import { Product, Review } from '@/types';
import { ProductCard } from '@/components/ProductCard';
import { ReviewCard } from '@/components/ReviewCard';
import axios from 'axios';

const HomePage: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [trendingProducts, setTrendingProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch featured products
      const featuredResponse = await axios.get('/api/products/featured');
      if (featuredResponse.data.success) {
        setFeaturedProducts(featuredResponse.data.data);
      }

      // Fetch trending products
      const trendingResponse = await axios.get('/api/products/trending');
      if (trendingResponse.data.success) {
        setTrendingProducts(trendingResponse.data.data);
      }

      // Fetch reviews
      const reviewsResponse = await axios.get('/api/reviews');
      if (reviewsResponse.data.success) {
        setReviews(reviewsResponse.data.data);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      // Mock data for development
      setFeaturedProducts(mockFeaturedProducts);
      setTrendingProducts(mockTrendingProducts);
      setReviews(mockReviews);
    } finally {
      setLoading(false);
    }
  };

  const mockFeaturedProducts: Product[] = [
    {
      id: '1',
      name: 'Neon Dreams Tee',
      price: 29.99,
      originalPrice: 39.99,
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400',
      category: 'Graphic Tees',
      description: 'Vibrant neon design perfect for festivals',
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: ['Purple', 'Pink', 'Blue'],
      isNew: true
    },
    {
      id: '2',
      name: 'Aesthetic Vibes',
      price: 24.99,
      image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=400',
      category: 'Aesthetic',
      description: 'Minimalist design with maximum impact',
      sizes: ['S', 'M', 'L', 'XL'],
      colors: ['Black', 'White', 'Gray'],
      isTrending: true
    },
    {
      id: '3',
      name: 'Retro Wave',
      price: 32.99,
      image: 'https://images.unsplash.com/photo-1583743814966-8936f37f4ec2?w=400',
      category: 'Retro',
      description: 'Synthwave inspired design',
      sizes: ['XS', 'S', 'M', 'L'],
      colors: ['Purple', 'Cyan', 'Pink']
    }
  ];

  const mockTrendingProducts: Product[] = [
    {
      id: '4',
      name: 'Holographic Print',
      price: 34.99,
      image: 'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=400',
      category: 'Futuristic',
      description: 'Holographic effect tee that changes with light',
      sizes: ['S', 'M', 'L', 'XL'],
      colors: ['Holographic']
    },
    {
      id: '5',
      name: 'Pixel Art Cat',
      price: 27.99,
      image: 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=400',
      category: 'Gaming',
      description: 'Pixelated cat design for gamers',
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: ['Black', 'Navy', 'Gray']
    }
  ];

  const mockReviews: Review[] = [
    {
      id: '1',
      name: 'Alex Chen',
      rating: 5,
      comment: 'The quality is insane! Got so many compliments wearing this to a rave.',
      productId: '1',
      date: '2024-01-15'
    },
    {
      id: '2',
      name: 'Maya Rodriguez',
      rating: 5,
      comment: 'Perfect fit and the colors are even more vibrant in person!',
      productId: '2',
      date: '2024-01-14'
    },
    {
      id: '3',
      name: 'Jordan Kim',
      rating: 5,
      comment: 'Fast shipping and amazing design. Definitely ordering more!',
      productId: '3',
      date: '2024-01-13'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      {/* Hero Section */}
      <section className="relative px-4 py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20" />
        <div className="relative max-w-6xl mx-auto text-center">
          <Badge className="mb-6 bg-gradient-to-r from-pink-500 to-purple-500 text-white border-none px-4 py-2">
            ✨ Gen-Z Fashion Revolution
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Drip Different
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Express your vibe with our collection of aesthetic tees that hit different. 
            From neon dreams to pixel art - we've got your style covered.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white border-none px-8 py-3 text-lg">
              Shop Now <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-3 text-lg">
              View Collection
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-4 py-16 bg-black/20">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 border-purple-500/30">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Zap className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Lightning Fast Shipping</h3>
                <p className="text-gray-300">Get your fit delivered in 1-2 days. No cap.</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-cyan-900/50 to-blue-900/50 border-cyan-500/30">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center">
                  <Trophy className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Premium Quality</h3>
                <p className="text-gray-300">Soft, durable fabric that keeps you looking fresh.</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-pink-900/50 to-purple-900/50 border-pink-500/30">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                  <Palette className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Unique Designs</h3>
                <p className="text-gray-300">Original artwork you won't find anywhere else.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Featured Drops
            </h2>
            <p className="text-gray-300 text-lg">The hottest designs everyone's talking about</p>
          </div>
          {loading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((n) => (
                <div key={n} className="bg-gray-800 rounded-lg h-96 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8">
              {featuredProducts.length > 0 && featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Trending Section */}
      <section className="px-4 py-16 bg-gradient-to-r from-purple-900/30 to-pink-900/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-400 to-cyan-400 bg-clip-text text-transparent">
              Trending Now
            </h2>
            <p className="text-gray-300 text-lg">What's blowing up on social media</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {trendingProducts.length > 0 && trendingProducts.slice(0, 2).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Real Reviews
            </h2>
            <p className="text-gray-300 text-lg">See what our community is saying</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {reviews.length > 0 && reviews.map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-20 bg-gradient-to-r from-cyan-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Level Up Your Wardrobe?
          </h2>
          <p className="text-xl text-cyan-100 mb-8">
            Join thousands of Gen-Z fashion lovers who trust us for their daily fits.
          </p>
          <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-3 text-lg font-semibold">
            Start Shopping <ShoppingBag className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>
    </div>
  );
};

export default HomePage;