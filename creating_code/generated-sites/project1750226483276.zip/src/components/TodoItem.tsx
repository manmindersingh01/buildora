import React from 'react';
import { Calendar, Tag, Edit, Delete, CheckCircle2, Circle, Clock, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Todo } from '@/types';

interface TodoItemProps {
  todo: Todo;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onEdit, onDelete }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const isOverdue = (dueDate: string) => {
    if (!dueDate) return false;
    const due = new Date(dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return due < today && !todo.completed;
  };

  const isDueSoon = (dueDate: string) => {
    if (!dueDate) return false;
    const due = new Date(dueDate);
    const today = new Date();
    const threeDaysFromNow = new Date(today.getTime() + (3 * 24 * 60 * 60 * 1000));
    return due <= threeDaysFromNow && due >= today && !todo.completed;
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      'Personal': 'bg-blue-100 text-blue-800 border-blue-200',
      'Work': 'bg-purple-100 text-purple-800 border-purple-200',
      'Health': 'bg-green-100 text-green-800 border-green-200',
      'Learning': 'bg-indigo-100 text-indigo-800 border-indigo-200',
      'Shopping': 'bg-pink-100 text-pink-800 border-pink-200',
      'Finance': 'bg-emerald-100 text-emerald-800 border-emerald-200',
      'Travel': 'bg-orange-100 text-orange-800 border-orange-200',
      'Other': 'bg-gray-100 text-gray-800 border-gray-200'
    };
    return colors[category as keyof typeof colors] || colors.Other;
  };

  const overdue = todo.dueDate && isOverdue(todo.dueDate);
  const dueSoon = todo.dueDate && isDueSoon(todo.dueDate);

  return (
    <Card className={`bg-white/60 backdrop-blur-sm border-white/20 transition-all duration-200 hover:shadow-lg hover:bg-white/80 ${
      todo.completed ? 'opacity-75' : ''
    } ${
      overdue ? 'border-l-4 border-l-red-500' : dueSoon ? 'border-l-4 border-l-yellow-500' : ''
    }`}>
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          {/* Toggle Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            className={`mt-1 hover:bg-transparent ${
              todo.completed 
                ? 'text-green-600 hover:text-green-700' 
                : 'text-gray-400 hover:text-green-600'
            }`}
          >
            {todo.completed ? (
              <CheckCircle2 className="h-5 w-5" />
            ) : (
              <Circle className="h-5 w-5" />
            )}
          </Button>

          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Title and Status Indicators */}
            <div className="flex items-center space-x-2 mb-2">
              <h3 className={`font-semibold text-lg ${
                todo.completed 
                  ? 'line-through text-gray-500' 
                  : 'text-gray-900'
              }`}>
                {todo.title}
              </h3>
              {overdue && (
                <AlertTriangle className="h-4 w-4 text-red-500" />
              )}
              {dueSoon && !overdue && (
                <Clock className="h-4 w-4 text-yellow-500" />
              )}
            </div>

            {/* Description */}
            {todo.description && (
              <p className={`text-sm mb-3 ${
                todo.completed ? 'text-gray-400' : 'text-gray-600'
              }`}>
                {todo.description}
              </p>
            )}

            {/* Tags and Due Date */}
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <Badge 
                variant="outline" 
                className={`text-xs ${getPriorityColor(todo.priority)}`}
              >
                {todo.priority.charAt(0).toUpperCase() + todo.priority.slice(1)}
              </Badge>
              
              <Badge 
                variant="outline" 
                className={`text-xs ${getCategoryColor(todo.category)}`}
              >
                <Tag className="h-3 w-3 mr-1" />
                {todo.category}
              </Badge>

              {todo.dueDate && (
                <Badge 
                  variant="outline" 
                  className={`text-xs ${
                    overdue 
                      ? 'bg-red-100 text-red-800 border-red-200' 
                      : dueSoon 
                      ? 'bg-yellow-100 text-yellow-800 border-yellow-200'
                      : 'bg-gray-100 text-gray-600 border-gray-200'
                  }`}
                >
                  <Calendar className="h-3 w-3 mr-1" />
                  {formatDate(todo.dueDate)}
                  {overdue && ' (Overdue)'}
                  {dueSoon && !overdue && ' (Due Soon)'}
                </Badge>
              )}
            </div>

            {/* Timestamps */}
            <div className="text-xs text-gray-400">
              Created {formatDate(todo.createdAt)}
              {todo.updatedAt !== todo.createdAt && (
                <span className="ml-2">
                  • Updated {formatDate(todo.updatedAt)}
                </span>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={onEdit}
              className="text-gray-400 hover:text-blue-600 hover:bg-blue-50"
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onDelete}
              className="text-gray-400 hover:text-red-600 hover:bg-red-50"
            >
              <Delete className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};