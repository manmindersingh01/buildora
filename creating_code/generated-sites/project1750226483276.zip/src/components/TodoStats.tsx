import React from 'react';
import { CheckCircle2, Circle, AlertTriangle, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Todo } from '@/types';

interface TodoStatsProps {
  todos: Todo[];
}

export const TodoStats: React.FC<TodoStatsProps> = ({ todos }) => {
  const totalTodos = todos.length;
  const completedTodos = todos.filter(todo => todo.completed).length;
  const activeTodos = todos.filter(todo => !todo.completed).length;
  const overdueTodos = todos.filter(todo => {
    if (!todo.dueDate || todo.completed) return false;
    const dueDate = new Date(todo.dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return dueDate < today;
  }).length;

  const completionRate = totalTodos > 0 ? Math.round((completedTodos / totalTodos) * 100) : 0;

  const getProgressColor = (rate: number) => {
    if (rate >= 80) return 'from-green-500 to-emerald-500';
    if (rate >= 60) return 'from-blue-500 to-indigo-500';
    if (rate >= 40) return 'from-yellow-500 to-orange-500';
    return 'from-red-500 to-pink-500';
  };

  const stats = [
    {
      title: 'Total Tasks',
      value: totalTodos,
      icon: Circle,
      color: 'bg-gradient-to-r from-blue-500 to-indigo-500',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Completed',
      value: completedTodos,
      icon: CheckCircle2,
      color: 'bg-gradient-to-r from-green-500 to-emerald-500',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Active',
      value: activeTodos,
      icon: TrendingUp,
      color: 'bg-gradient-to-r from-purple-500 to-indigo-500',
      bgColor: 'bg-purple-50'
    },
    {
      title: 'Overdue',
      value: overdueTodos,
      icon: AlertTriangle,
      color: 'bg-gradient-to-r from-red-500 to-pink-500',
      bgColor: 'bg-red-50'
    }
  ];

  return (
    <div className="space-y-4">
      {/* Completion Rate */}
      <Card className="bg-white/60 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-700">
            Completion Rate
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-gray-900">{completionRate}%</span>
              <span className="text-sm text-gray-600">
                {completedTodos} of {totalTodos}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full bg-gradient-to-r ${getProgressColor(completionRate)} transition-all duration-500`}
                style={{ width: `${completionRate}%` }}
              ></div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="bg-white/60 backdrop-blur-sm border-white/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${stat.color}`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-600 uppercase tracking-wider">
                      {stat.title}
                    </p>
                    <p className="text-xl font-bold text-gray-900">
                      {stat.value}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Insights */}
      {totalTodos > 0 && (
        <Card className="bg-white/60 backdrop-blur-sm border-white/20">
          <CardContent className="p-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Quick Insights</h4>
              
              {completionRate >= 80 && (
                <div className="flex items-center space-x-2 text-green-700">
                  <CheckCircle2 className="h-4 w-4" />
                  <span className="text-xs">Great job! You're on track</span>
                </div>
              )}
              
              {overdueTodos > 0 && (
                <div className="flex items-center space-x-2 text-red-700">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="text-xs">{overdueTodos} task{overdueTodos > 1 ? 's' : ''} overdue</span>
                </div>
              )}
              
              {activeTodos > 0 && overdueTodos === 0 && (
                <div className="flex items-center space-x-2 text-blue-700">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-xs">{activeTodos} active task{activeTodos > 1 ? 's' : ''} remaining</span>
                </div>
              )}
              
              {totalTodos > 0 && completedTodos === totalTodos && (
                <div className="flex items-center space-x-2 text-green-700">
                  <CheckCircle2 className="h-4 w-4" />
                  <span className="text-xs">All tasks completed! 🎉</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};