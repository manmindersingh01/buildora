import React from 'react';
import { Filter, Tag, Star, Circle, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TodoFilters as TodoFiltersType, Todo } from '@/types';

interface TodoFiltersProps {
  filters: TodoFiltersType;
  onFiltersChange: (filters: TodoFiltersType) => void;
  todos: Todo[];
}

export const TodoFilters: React.FC<TodoFiltersProps> = ({ filters, onFiltersChange, todos }) => {
  const categories = Array.from(new Set(todos.map(todo => todo.category)));

  const getStatusCount = (status: string) => {
    switch (status) {
      case 'all': return todos.length;
      case 'active': return todos.filter(todo => !todo.completed).length;
      case 'completed': return todos.filter(todo => todo.completed).length;
      default: return 0;
    }
  };

  const getPriorityCount = (priority: string) => {
    if (priority === 'all') return todos.length;
    return todos.filter(todo => todo.priority === priority).length;
  };

  const getCategoryCount = (category: string) => {
    if (category === 'all') return todos.length;
    return todos.filter(todo => todo.category === category).length;
  };

  const updateFilter = (key: keyof TodoFiltersType, value: string) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <div className="space-y-6">
      {/* Status Filter */}
      <Card className="bg-white/60 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-700 flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            Status
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-2">
          {[
            { key: 'all', label: 'All Tasks', icon: Circle },
            { key: 'active', label: 'Active', icon: Circle },
            { key: 'completed', label: 'Completed', icon: CheckCircle2 }
          ].map(({ key, label, icon: Icon }) => (
            <Button
              key={key}
              variant={filters.status === key ? 'default' : 'ghost'}
              onClick={() => updateFilter('status', key)}
              className={`w-full justify-between h-auto p-3 ${
                filters.status === key 
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' 
                  : 'hover:bg-white/50'
              }`}
            >
              <div className="flex items-center space-x-2">
                <Icon className="h-4 w-4" />
                <span className="text-sm">{label}</span>
              </div>
              <Badge 
                variant="secondary" 
                className={`text-xs ${
                  filters.status === key 
                    ? 'bg-white/20 text-white' 
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {getStatusCount(key)}
              </Badge>
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* Priority Filter */}
      <Card className="bg-white/60 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-700 flex items-center">
            <Star className="h-4 w-4 mr-2" />
            Priority
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-2">
          {[
            { key: 'all', label: 'All Priorities', color: 'bg-gray-100 text-gray-600' },
            { key: 'high', label: 'High', color: 'bg-red-100 text-red-800' },
            { key: 'medium', label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
            { key: 'low', label: 'Low', color: 'bg-green-100 text-green-800' }
          ].map(({ key, label, color }) => (
            <Button
              key={key}
              variant={filters.priority === key ? 'default' : 'ghost'}
              onClick={() => updateFilter('priority', key)}
              className={`w-full justify-between h-auto p-3 ${
                filters.priority === key 
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' 
                  : 'hover:bg-white/50'
              }`}
            >
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${
                  key === 'all' ? 'bg-gray-400' :
                  key === 'high' ? 'bg-red-500' :
                  key === 'medium' ? 'bg-yellow-500' :
                  'bg-green-500'
                }`}></div>
                <span className="text-sm">{label}</span>
              </div>
              <Badge 
                variant="secondary" 
                className={`text-xs ${
                  filters.priority === key 
                    ? 'bg-white/20 text-white' 
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {getPriorityCount(key)}
              </Badge>
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* Category Filter */}
      {categories.length > 0 && (
        <Card className="bg-white/60 backdrop-blur-sm border-white/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-700 flex items-center">
              <Tag className="h-4 w-4 mr-2" />
              Categories
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-2">
            <Button
              variant={filters.category === 'all' ? 'default' : 'ghost'}
              onClick={() => updateFilter('category', 'all')}
              className={`w-full justify-between h-auto p-3 ${
                filters.category === 'all' 
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' 
                  : 'hover:bg-white/50'
              }`}
            >
              <div className="flex items-center space-x-2">
                <Tag className="h-4 w-4" />
                <span className="text-sm">All Categories</span>
              </div>
              <Badge 
                variant="secondary" 
                className={`text-xs ${
                  filters.category === 'all' 
                    ? 'bg-white/20 text-white' 
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {todos.length}
              </Badge>
            </Button>
            
            {categories.map((category) => (
              <Button
                key={category}
                variant={filters.category === category ? 'default' : 'ghost'}
                onClick={() => updateFilter('category', category)}
                className={`w-full justify-between h-auto p-3 ${
                  filters.category === category 
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' 
                    : 'hover:bg-white/50'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-400"></div>
                  <span className="text-sm">{category}</span>
                </div>
                <Badge 
                  variant="secondary" 
                  className={`text-xs ${
                    filters.category === category 
                      ? 'bg-white/20 text-white' 
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {getCategoryCount(category)}
                </Badge>
              </Button>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};