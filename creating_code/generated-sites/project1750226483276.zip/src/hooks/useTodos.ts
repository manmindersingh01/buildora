import { useState, useEffect } from 'react';
import axios from 'axios';
import { Todo, TodoFormData } from '@/types';

interface UseTodosReturn {
  todos: Todo[];
  loading: boolean;
  error: string | null;
  addTodo: (todoData: TodoFormData) => Promise<void>;
  updateTodo: (id: string, todoData: TodoFormData) => Promise<void>;
  deleteTodo: (id: string) => Promise<void>;
  toggleTodo: (id: string) => Promise<void>;
  refreshTodos: () => Promise<void>;
}

export const useTodos = (): UseTodosReturn => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Helper function to generate unique IDs
  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  // Load todos from localStorage on mount
  useEffect(() => {
    loadTodos();
  }, []);

  const loadTodos = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const storedTodos = localStorage.getItem('todos');
      if (storedTodos) {
        const parsedTodos = JSON.parse(storedTodos);
        setTodos(parsedTodos);
      } else {
        // Initialize with some sample todos
        const sampleTodos: Todo[] = [
          {
            id: generateId(),
            title: 'Welcome to TodoMaster!',
            description: 'This is your first todo. Click the checkbox to mark it as complete.',
            completed: false,
            priority: 'medium',
            category: 'Personal',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          },
          {
            id: generateId(),
            title: 'Plan weekly goals',
            description: 'Set up goals for the upcoming week and prioritize important tasks.',
            completed: false,
            priority: 'high',
            category: 'Work',
            dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
          },
          {
            id: generateId(),
            title: 'Grocery shopping',
            description: 'Buy vegetables, fruits, and pantry essentials for the week.',
            completed: true,
            priority: 'low',
            category: 'Shopping',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date().toISOString()
          }
        ];
        setTodos(sampleTodos);
        localStorage.setItem('todos', JSON.stringify(sampleTodos));
      }
    } catch (err) {
      setError('Failed to load todos');
      console.error('Error loading todos:', err);
    } finally {
      setLoading(false);
    }
  };

  const saveTodos = (updatedTodos: Todo[]) => {
    localStorage.setItem('todos', JSON.stringify(updatedTodos));
    setTodos(updatedTodos);
  };

  const addTodo = async (todoData: TodoFormData): Promise<void> => {
    try {
      setError(null);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const newTodo: Todo = {
        id: generateId(),
        title: todoData.title,
        description: todoData.description,
        completed: false,
        priority: todoData.priority,
        category: todoData.category,
        dueDate: todoData.dueDate,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const updatedTodos = [newTodo, ...todos];
      saveTodos(updatedTodos);
    } catch (err) {
      setError('Failed to add todo');
      throw err;
    }
  };

  const updateTodo = async (id: string, todoData: TodoFormData): Promise<void> => {
    try {
      setError(null);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const updatedTodos = todos.map(todo => 
        todo.id === id 
          ? {
              ...todo,
              title: todoData.title,
              description: todoData.description,
              priority: todoData.priority,
              category: todoData.category,
              dueDate: todoData.dueDate,
              updatedAt: new Date().toISOString()
            }
          : todo
      );
      
      saveTodos(updatedTodos);
    } catch (err) {
      setError('Failed to update todo');
      throw err;
    }
  };

  const deleteTodo = async (id: string): Promise<void> => {
    try {
      setError(null);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 200));
      
      const updatedTodos = todos.filter(todo => todo.id !== id);
      saveTodos(updatedTodos);
    } catch (err) {
      setError('Failed to delete todo');
      throw err;
    }
  };

  const toggleTodo = async (id: string): Promise<void> => {
    try {
      setError(null);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 200));
      
      const updatedTodos = todos.map(todo => 
        todo.id === id 
          ? { 
              ...todo, 
              completed: !todo.completed,
              updatedAt: new Date().toISOString()
            }
          : todo
      );
      
      saveTodos(updatedTodos);
    } catch (err) {
      setError('Failed to toggle todo');
      throw err;
    }
  };

  const refreshTodos = async (): Promise<void> => {
    await loadTodos();
  };

  return {
    todos,
    loading,
    error,
    addTodo,
    updateTodo,
    deleteTodo,
    toggleTodo,
    refreshTodos
  };
};