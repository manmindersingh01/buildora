import React, { useState, useEffect } from 'react';
import { Plus, Filter, Search, Calendar, CheckCircle2, Circle, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TodoForm } from '@/components/TodoForm';
import { TodoItem } from '@/components/TodoItem';
import { TodoFilters } from '@/components/TodoFilters';
import { TodoStats } from '@/components/TodoStats';
import { useTodos } from '@/hooks/useTodos';
import { Todo, TodoFilters as TodoFiltersType } from '@/types';

const TodoApp: React.FC = () => {
  const {
    todos,
    loading,
    error,
    addTodo,
    updateTodo,
    deleteTodo,
    toggleTodo
  } = useTodos();

  const [showForm, setShowForm] = useState(false);
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);
  const [filters, setFilters] = useState<TodoFiltersType>({
    status: 'all',
    priority: 'all',
    category: 'all',
    search: ''
  });

  const filteredTodos = todos.filter(todo => {
    if (filters.status === 'active' && todo.completed) return false;
    if (filters.status === 'completed' && !todo.completed) return false;
    if (filters.priority !== 'all' && todo.priority !== filters.priority) return false;
    if (filters.category !== 'all' && todo.category !== filters.category) return false;
    if (filters.search && !todo.title.toLowerCase().includes(filters.search.toLowerCase())) return false;
    return true;
  });

  const handleAddTodo = async (todoData: any) => {
    try {
      await addTodo(todoData);
      setShowForm(false);
    } catch (error) {
      console.error('Failed to add todo:', error);
    }
  };

  const handleUpdateTodo = async (todoData: any) => {
    if (editingTodo) {
      try {
        await updateTodo(editingTodo.id, todoData);
        setEditingTodo(null);
        setShowForm(false);
      } catch (error) {
        console.error('Failed to update todo:', error);
      }
    }
  };

  const handleDeleteTodo = async (id: string) => {
    try {
      await deleteTodo(id);
    } catch (error) {
      console.error('Failed to delete todo:', error);
    }
  };

  const handleToggleTodo = async (id: string) => {
    try {
      await toggleTodo(id);
    } catch (error) {
      console.error('Failed to toggle todo:', error);
    }
  };

  const handleEditTodo = (todo: Todo) => {
    setEditingTodo(todo);
    setShowForm(true);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-2 rounded-lg">
                <CheckCircle2 className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                TodoMaster
              </h1>
            </div>
            <Button 
              onClick={() => {
                setEditingTodo(null);
                setShowForm(true);
              }}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Todo
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Stats */}
            <TodoStats todos={todos} />
            
            {/* Filters */}
            <TodoFilters 
              filters={filters}
              onFiltersChange={setFilters}
              todos={todos}
            />
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Search Bar */}
            <Card className="bg-white/60 backdrop-blur-sm border-white/20">
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search todos..."
                    value={filters.search}
                    onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                    className="pl-10 bg-white/50 border-white/30"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Todo List */}
            <div className="space-y-4">
              {filteredTodos.length === 0 ? (
                <Card className="bg-white/60 backdrop-blur-sm border-white/20">
                  <CardContent className="p-12 text-center">
                    <div className="bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                      <CheckCircle2 className="h-10 w-10 text-indigo-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {todos.length === 0 ? 'No todos yet' : 'No todos match your filters'}
                    </h3>
                    <p className="text-gray-600 mb-4">
                      {todos.length === 0 
                        ? 'Create your first todo to get started!' 
                        : 'Try adjusting your filters or search terms.'}
                    </p>
                    {todos.length === 0 && (
                      <Button 
                        onClick={() => {
                          setEditingTodo(null);
                          setShowForm(true);
                        }}
                        className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Your First Todo
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                filteredTodos.map((todo) => (
                  <TodoItem
                    key={todo.id}
                    todo={todo}
                    onToggle={() => handleToggleTodo(todo.id)}
                    onEdit={() => handleEditTodo(todo)}
                    onDelete={() => handleDeleteTodo(todo.id)}
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Todo Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <TodoForm
              todo={editingTodo}
              onSubmit={editingTodo ? handleUpdateTodo : handleAddTodo}
              onCancel={() => {
                setShowForm(false);
                setEditingTodo(null);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default TodoApp;